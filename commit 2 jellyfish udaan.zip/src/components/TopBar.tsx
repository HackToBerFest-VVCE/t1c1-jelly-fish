import React, { useState } from 'react';
import {
  Menu,
  MessageSquareText,
  Search,
  Store,
  UtensilsCrossed,
  ChevronDown,
  LogOut,
  User,
  Check,
  Bot,
} from 'lucide-react';
import { AppPage } from './Sidebar';
import { BusinessType, UserAccount } from '../data/db';

interface TopBarProps {
  businessType: BusinessType;
  storeName: string;
  ownerName: string;
  currentUser: UserAccount | null;
  onOpenMobileSidebar: () => void;
  onNavigate: (page: AppPage) => void;
  onSwitchProfile: (type: BusinessType) => void;
  onLogout: () => void;
  currentPage: AppPage;
}

export const TopBar: React.FC<TopBarProps> = ({
  businessType,
  storeName,
  ownerName,
  currentUser,
  onOpenMobileSidebar,
  onNavigate,
  onSwitchProfile,
  onLogout,
  currentPage,
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="sticky top-0 z-20 bg-[#0A192F]/95 backdrop-blur-md border-b border-[#F8F9FA]/[0.08] px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
      {/* Left: Mobile menu toggle + Store Greeting */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 text-[#F8F9FA]/70 hover:text-[#F8F9FA] hover:bg-[#112240] rounded-lg transition-colors cursor-pointer"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm sm:text-base font-semibold text-[#F8F9FA] tracking-tight">
              Good morning, {ownerName ? ownerName.split(' ')[0] : 'Owner'}
            </h1>
            <span className="hidden sm:inline-block text-[#F8F9FA]/30">|</span>
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-[#FFB703]">
              {businessType === 'restaurant' ? (
                <UtensilsCrossed className="w-3.5 h-3.5" />
              ) : (
                <Store className="w-3.5 h-3.5" />
              )}
              <span>{storeName}</span>
            </span>
          </div>
          <div className="text-[11px] text-[#F8F9FA]/55 flex items-center gap-2 mt-0.5">
            <span>Bengaluru Commercial Hub</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#64FFDA]">Live Operational Ledger</span>
          </div>
        </div>
      </div>

      {/* Right Controls: Profile Switcher, Ask Udaan button, Header Logout */}
      <div className="flex items-center gap-2.5 sm:gap-3.5">
        
        {/* Profile Switcher Dropdown (Judge Convenience) */}
        <div className="relative">
          <button
            onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#112240] border border-[#F8F9FA]/15 hover:border-[#FFB703]/60 transition-all text-xs text-[#F8F9FA] cursor-pointer"
            title="Switch business profile"
          >
            {businessType === 'restaurant' ? (
              <UtensilsCrossed className="w-3.5 h-3.5 text-[#64FFDA]" />
            ) : (
              <Store className="w-3.5 h-3.5 text-[#FFB703]" />
            )}
            <span className="hidden md:inline font-medium">
              {businessType === 'restaurant' ? 'Restaurant Profile' : 'Retail Profile'}
            </span>
            <ChevronDown className={`w-3.5 h-3.5 text-[#F8F9FA]/50 transition-transform ${profileDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {profileDropdownOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-[#112240] border border-[#FFB703]/30 rounded-xl shadow-2xl p-2 z-50 text-xs">
              <div className="px-2.5 py-1.5 text-[10px] uppercase font-mono text-[#F8F9FA]/40 border-b border-[#F8F9FA]/[0.08] mb-1">
                Switch Business Profile
              </div>

              {/* Option 1: Retail Store */}
              <button
                onClick={() => {
                  onSwitchProfile('retail');
                  setProfileDropdownOpen(false);
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left transition-colors cursor-pointer ${
                  businessType === 'retail'
                    ? 'bg-[#FFB703]/15 text-[#FFB703] font-semibold'
                    : 'text-[#F8F9FA]/80 hover:bg-[#0A192F]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Store className="w-4 h-4 text-[#FFB703]" />
                  <div>
                    <div className="font-semibold text-xs text-[#F8F9FA]">Retail Store Profile</div>
                    <div className="text-[10px] text-[#F8F9FA]/50">Lakshmi Retail Mart · Suresh Kumar</div>
                  </div>
                </div>
                {businessType === 'retail' && <Check className="w-4 h-4 text-[#FFB703]" />}
              </button>

              {/* Option 2: Restaurant Enterprise */}
              <button
                onClick={() => {
                  onSwitchProfile('restaurant');
                  setProfileDropdownOpen(false);
                }}
                className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left transition-colors cursor-pointer mt-1 ${
                  businessType === 'restaurant'
                    ? 'bg-[#64FFDA]/15 text-[#64FFDA] font-semibold'
                    : 'text-[#F8F9FA]/80 hover:bg-[#0A192F]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <UtensilsCrossed className="w-4 h-4 text-[#64FFDA]" />
                  <div>
                    <div className="font-semibold text-xs text-[#F8F9FA]">Restaurant Profile</div>
                    <div className="text-[10px] text-[#F8F9FA]/50">Royal Spice Kitchen · Rajesh Shetty</div>
                  </div>
                </div>
                {businessType === 'restaurant' && <Check className="w-4 h-4 text-[#64FFDA]" />}
              </button>
            </div>
          )}
        </div>

        {/* Quick Ask UDAAN Button */}
        {currentPage !== 'ask-udaan' && (
          <button
            onClick={() => onNavigate('ask-udaan')}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Ask UDAAN</span>
          </button>
        )}

        {/* User initials avatar */}
        <div
          className="w-8 h-8 rounded-full bg-[#112240] border border-[#FFB703]/40 text-[#FFB703] font-display font-semibold text-xs flex items-center justify-center shrink-0"
          title={`${ownerName} (${storeName})`}
        >
          {getInitials(ownerName || 'Business Owner')}
        </div>

        {/* Header Logout Button */}
        <button
          onClick={onLogout}
          className="p-2 rounded-lg bg-[#112240] border border-[#F8F9FA]/15 text-[#F8F9FA]/70 hover:text-red-300 hover:border-red-400/40 hover:bg-red-500/10 transition-colors cursor-pointer"
          title="Sign out of account"
          aria-label="Sign out"
        >
          <LogOut className="w-4 h-4" />
        </button>

      </div>
    </header>
  );
};
