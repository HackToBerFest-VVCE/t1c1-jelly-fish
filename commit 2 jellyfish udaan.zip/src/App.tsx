/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Login } from './pages/Login';
import { Overview } from './pages/Overview';
import { AskUdaan } from './pages/AskUdaan';
import { SalesAnalytics } from './pages/SalesAnalytics';
import { Inventory } from './pages/Inventory';
import { Suppliers } from './pages/Suppliers';
import { RestaurantMenuSales } from './pages/RestaurantMenuSales';
import { RestaurantPurchasesExpenses } from './pages/RestaurantPurchasesExpenses';
import { Settings } from './pages/Settings';
import { Sidebar, AppPage } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { ToastContainer, ToastMessage } from './components/Toast';
import {
  BusinessType,
  UserAccount,
  getStoredSession,
  setStoredSession,
  getStoredUsers,
  getRetailState,
  getRestaurantState,
  saveRetailState,
  saveRestaurantState,
  addRetailRestockEntry,
  addRestaurantRestockEntry,
  RestockEntry,
} from './data/db';
import { StoreProfile } from './data/sampleData';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => getStoredSession());
  const [currentPage, setCurrentPage] = useState<AppPage>('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Local database states
  const [retailState, setRetailState] = useState(() => getRetailState());
  const [restaurantState, setRestaurantState] = useState(() => getRestaurantState());

  // Active business type derived from current user account or default
  const activeBusinessType: BusinessType = currentUser?.businessType || 'retail';

  // Active business name & owner
  const activeBusinessName = useMemo(() => {
    if (currentUser?.businessName) return currentUser.businessName;
    return activeBusinessType === 'restaurant'
      ? restaurantState.profile.name
      : retailState.profile.name;
  }, [currentUser, activeBusinessType, restaurantState, retailState]);

  const activeOwnerName = useMemo(() => {
    if (currentUser?.name) return currentUser.name;
    return activeBusinessType === 'restaurant'
      ? restaurantState.profile.ownerName
      : retailState.profile.ownerName;
  }, [currentUser, activeBusinessType, restaurantState, retailState]);

  // Toast notification helper with auto-removal
  const showToast = (
    message: string,
    type: 'info' | 'success' | 'warning' = 'info',
    title?: string
  ) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    const newToast: ToastMessage = { id, type, title, message };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleLoginSuccess = (user: UserAccount) => {
    setCurrentUser(user);
    setStoredSession(user);
    setCurrentPage('overview');
    showToast(
      `Welcome back, ${user.name}. Signed into ${user.businessName}.`,
      'success',
      'Account Verified'
    );
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setStoredSession(null);
    setCurrentPage('overview');
    setMobileSidebarOpen(false);
    showToast('Signed out of business account.', 'info');
  };

  // Switch between Retail and Restaurant profiles
  const handleSwitchProfile = (type: BusinessType) => {
    const users = getStoredUsers();
    const targetUser = users.find((u) => u.businessType === type);

    if (targetUser) {
      setCurrentUser(targetUser);
      setStoredSession(targetUser);
      setCurrentPage('overview');
      showToast(
        `Switched to ${targetUser.businessName} (${type === 'restaurant' ? 'Restaurant' : 'Retail Store'}).`,
        'success',
        'Profile Changed'
      );
    }
  };

  // Reload database state after import or reset
  const handleReloadDatabase = () => {
    setRetailState(getRetailState());
    setRestaurantState(getRestaurantState());
  };

  // Handle restock entry additions
  const handleAddRestock = (entryData: Omit<RestockEntry, 'id' | 'receiptNumber'>) => {
    if (activeBusinessType === 'restaurant') {
      addRestaurantRestockEntry(entryData);
      setRestaurantState(getRestaurantState());
    } else {
      addRetailRestockEntry(entryData);
      setRetailState(getRetailState());
    }
  };

  // Update profile handler in Settings
  const handleUpdateStoreProfile = (updatedProfile: StoreProfile) => {
    if (activeBusinessType === 'retail') {
      const state = getRetailState();
      state.profile = updatedProfile;
      saveRetailState(state);
      setRetailState(state);
    }
  };

  // Packaged business data payload sent to ASK UDAAN Gemini Chatbot
  const askUdaanPayload = useMemo(() => {
    if (activeBusinessType === 'restaurant') {
      return {
        businessType: 'restaurant',
        profile: restaurantState.profile,
        dishes: restaurantState.dishes,
        rawMaterials: restaurantState.rawMaterials,
        salesSummary: {
          last30DaysTurnover: restaurantState.profile.monthSales,
          totalCovers: restaurantState.profile.monthOrders,
          todaySales: restaurantState.profile.todaySales,
          todayOrders: restaurantState.profile.todayOrders,
          grossMarginPercent: restaurantState.profile.grossMarginPercent,
          netProfit: restaurantState.profile.netProfitMonth,
        },
        purchasesLog: restaurantState.purchases,
        expenses: restaurantState.expenses,
        suppliers: restaurantState.suppliers,
        restockHistory: restaurantState.restockHistory,
        peakHours: restaurantState.peakHours,
      };
    }
    return {
      businessType: 'retail',
      profile: retailState.profile,
      products: retailState.products,
      sales30D: retailState.sales,
      recentTransactions: retailState.transactions,
      suppliers: retailState.suppliers,
      restockHistory: retailState.restockHistory,
    };
  }, [activeBusinessType, restaurantState, retailState]);

  // If not authenticated, render Login Page
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#0A192F] text-[#F8F9FA] selection:bg-[#FFB703]/30 selection:text-[#FFB703]">
        <Login onLoginSuccess={handleLoginSuccess} />
        <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
      </div>
    );
  }

  // Dashboard Shell
  return (
    <div className="min-h-screen bg-[#0A192F] text-[#F8F9FA] flex selection:bg-[#FFB703]/30 selection:text-[#FFB703]">
      {/* Sidebar (Desktop fixed & Mobile Drawer) */}
      <Sidebar
        businessType={activeBusinessType}
        businessName={activeBusinessName}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <TopBar
          businessType={activeBusinessType}
          storeName={activeBusinessName}
          ownerName={activeOwnerName}
          currentUser={currentUser}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
          onNavigate={setCurrentPage}
          onSwitchProfile={handleSwitchProfile}
          onLogout={handleLogout}
          currentPage={currentPage}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {currentPage === 'overview' && (
            <Overview
              businessType={activeBusinessType}
              businessName={activeBusinessName}
              retailProducts={retailState.products}
              restaurantMaterials={restaurantState.rawMaterials}
              restaurantDishes={restaurantState.dishes}
              onNavigate={setCurrentPage}
            />
          )}

          {currentPage === 'ask-udaan' && (
            <AskUdaan
              businessType={activeBusinessType}
              businessData={askUdaanPayload}
              onShowToast={showToast}
            />
          )}

          {currentPage === 'sales-analytics' && (
            <SalesAnalytics
              businessType={activeBusinessType}
              retailProducts={retailState.products}
              restaurantDishes={restaurantState.dishes}
            />
          )}

          {currentPage === 'restaurant-menu' && (
            <RestaurantMenuSales dishes={restaurantState.dishes} />
          )}

          {currentPage === 'restaurant-ops' && (
            <RestaurantPurchasesExpenses
              purchases={restaurantState.purchases}
              expenses={restaurantState.expenses}
              peakHours={restaurantState.peakHours}
              reviews={restaurantState.reviews}
            />
          )}

          {currentPage === 'inventory' && (
            <Inventory
              businessType={activeBusinessType}
              businessName={activeBusinessName}
              retailProducts={retailState.products}
              restaurantMaterials={restaurantState.rawMaterials}
              restockHistory={
                activeBusinessType === 'restaurant'
                  ? restaurantState.restockHistory
                  : retailState.restockHistory
              }
              onAddRestock={handleAddRestock}
              onShowToast={showToast}
            />
          )}

          {currentPage === 'suppliers' && (
            <Suppliers
              businessType={activeBusinessType}
              onShowToast={showToast}
            />
          )}

          {currentPage === 'settings' && (
            <Settings
              businessType={activeBusinessType}
              profile={retailState.profile}
              onUpdateProfile={handleUpdateStoreProfile}
              onReloadDatabase={handleReloadDatabase}
              onShowToast={showToast}
            />
          )}
        </main>

        {/* Global Footer */}
        <footer className="border-t border-[#F8F9FA]/[0.06] py-4 px-6 text-center text-xs text-[#F8F9FA]/40 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-[#F8F9FA]/70">UDAAN</span>
            <span aria-hidden="true">·</span>
            <span>Give Your Business Freedom.</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Powered by Gemini</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#64FFDA]">Business Ledger v2.4</span>
          </div>
        </footer>
      </div>

      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}
