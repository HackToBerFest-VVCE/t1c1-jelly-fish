import React, { useState, useMemo } from 'react';
import {
  STORE_HEADLINE_METRICS,
  DAILY_SALES_30D,
  DAILY_SALES_7D,
  SAMPLE_PRODUCTS,
  RECENT_TRANSACTIONS,
  SAMPLE_AI_INSIGHTS,
  Transaction,
  Product,
} from '../data/sampleData';
import {
  RESTAURANT_PROFILE,
  RESTAURANT_DISHES,
  RESTAURANT_RAW_MATERIALS,
  RESTAURANT_SALES_30D,
  RESTAURANT_SALES_7D,
  RESTAURANT_PEAK_HOURS,
  RESTAURANT_REVIEWS,
  Dish,
  RawMaterial,
} from '../data/restaurantData';
import { BusinessType } from '../data/db';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import { MetricCard } from '../components/MetricCard';
import { ChartCard } from '../components/ChartCard';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { AppPage } from '../components/Sidebar';
import {
  IndianRupee,
  ShoppingBag,
  Package,
  AlertTriangle,
  ArrowRight,
  Search,
  Filter,
  Bot,
  ArrowUpRight,
  UtensilsCrossed,
  Flame,
  Clock,
  Star,
  Receipt,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

interface OverviewProps {
  businessType?: BusinessType;
  businessName?: string;
  retailProducts?: Product[];
  restaurantMaterials?: RawMaterial[];
  restaurantDishes?: Dish[];
  onNavigate: (page: AppPage) => void;
}

export const Overview: React.FC<OverviewProps> = ({
  businessType = 'retail',
  businessName = 'My Business',
  retailProducts = SAMPLE_PRODUCTS,
  restaurantMaterials = RESTAURANT_RAW_MATERIALS,
  restaurantDishes = RESTAURANT_DISHES,
  onNavigate,
}) => {
  // Chart timeframe toggle: 7D vs 30D
  const [salesTimeframe, setSalesTimeframe] = useState<'7D' | '30D'>('30D');

  // Transaction filters (Retail)
  const [txnSearch, setTxnSearch] = useState('');
  const [txnStatusFilter, setTxnStatusFilter] = useState<'all' | 'Completed' | 'Pending' | 'Refunded'>('all');

  // Filtered transactions for Retail
  const filteredTransactions = useMemo(() => {
    return RECENT_TRANSACTIONS.filter((txn) => {
      const matchesSearch =
        txn.customerName.toLowerCase().includes(txnSearch.toLowerCase()) ||
        txn.id.toLowerCase().includes(txnSearch.toLowerCase()) ||
        txn.itemsSummary.toLowerCase().includes(txnSearch.toLowerCase());
      const matchesStatus = txnStatusFilter === 'all' || txn.status === txnStatusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [txnSearch, txnStatusFilter]);

  // Retail: low stock products
  const lowStockRetail = useMemo(() => {
    return retailProducts.filter((p) => p.stockQuantity < p.reorderLevel);
  }, [retailProducts]);

  // Restaurant: low stock raw materials
  const lowStockRestaurant = useMemo(() => {
    return restaurantMaterials.filter((m) => m.stockQuantity < m.reorderLevel);
  }, [restaurantMaterials]);

  // Retail: Top selling products by volume
  const topRetailProducts = useMemo(() => {
    return [...retailProducts]
      .sort((a, b) => b.unitsSoldMonth - a.unitsSoldMonth)
      .slice(0, 5)
      .map((p) => ({
        name: p.name.length > 16 ? p.name.slice(0, 14) + '...' : p.name,
        fullName: p.name,
        units: p.unitsSoldMonth,
        revenue: p.revenueMonth,
      }));
  }, [retailProducts]);

  // Restaurant: Top selling dishes by revenue
  const topRestaurantDishes = useMemo(() => {
    return [...restaurantDishes]
      .sort((a, b) => b.revenueMonth - a.revenueMonth)
      .slice(0, 5)
      .map((d) => ({
        name: d.name.length > 18 ? d.name.slice(0, 16) + '...' : d.name,
        fullName: d.name,
        units: d.unitsSoldMonth,
        revenue: d.revenueMonth,
      }));
  }, [restaurantDishes]);

  // Sales data depending on 7D vs 30D (Normalized to uniform shape)
  const chartSalesData = useMemo(() => {
    if (businessType === 'restaurant') {
      const source = salesTimeframe === '7D' ? RESTAURANT_SALES_7D : RESTAURANT_SALES_30D;
      return source.map((s) => ({
        date: s.date,
        sales: s.sales,
        orders: s.covers,
      }));
    }
    const source = salesTimeframe === '7D' ? DAILY_SALES_7D : DAILY_SALES_30D;
    return source.map((s) => ({
      date: s.date,
      sales: s.sales,
      orders: s.orders,
    }));
  }, [businessType, salesTimeframe]);

  const periodTotalSales = chartSalesData.reduce((acc, curr) => acc + curr.sales, 0);
  const periodTotalOrders = chartSalesData.reduce((acc, curr: any) => acc + (curr.orders || curr.covers || 0), 0);

  // Custom tooltips
  const CustomSalesTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#0A192F] border border-[#FFB703]/40 p-2.5 rounded-lg shadow-xl text-xs">
          <div className="font-semibold text-[#F8F9FA] mb-1">{label}</div>
          <div className="text-[#FFB703] font-medium">
            Sales: {formatCurrency(payload[0].value)}
          </div>
          {payload[1] && (
            <div className="text-[#64FFDA] mt-0.5">
              {businessType === 'restaurant' ? 'Dining Covers: ' : 'Orders: '}
              {payload[1].value}
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const CustomBarTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0A192F] border border-[#FFB703]/40 p-2.5 rounded-lg shadow-xl text-xs">
          <div className="font-semibold text-[#F8F9FA] mb-1">{data.fullName}</div>
          <div className="text-[#64FFDA]">Volume: {data.units} units sold</div>
          <div className="text-[#FFB703] mt-0.5">Revenue: {formatCurrency(data.revenue)}</div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header section with page title & quick ask prompt */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-[#FFB703]">
              {businessType === 'restaurant' ? 'Restaurant Executive Overview' : 'Retail Store Dashboard'}
            </span>
            <span className="text-[#F8F9FA]/30">·</span>
            <span className="text-xs text-[#F8F9FA]/60">{businessName}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Your Business at a Glance
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            {businessType === 'restaurant'
              ? "Today's sales, kitchen covers, best sellers, low-stock raw materials, and wastage control."
              : 'Turnover velocity, order frequency, stock replenishment alerts, and customer transactions.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('ask-udaan')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Ask Business Question</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4 HEADLINE METRIC CARDS (Tailored for Retail vs Restaurant)                */}
      {/* ========================================================================= */}
      {businessType === 'restaurant' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <MetricCard
            title="Today's Revenue"
            value={formatCurrency(RESTAURANT_PROFILE.todaySales)}
            icon={IndianRupee}
            trendText="+12.4% vs avg"
            trendDirection="up"
            subtext="Oct 26 billing total"
            accent="gold"
            onClick={() => onNavigate('sales-analytics')}
          />
          <MetricCard
            title="Today's Covers / Orders"
            value={`${RESTAURANT_PROFILE.todayOrders} Bills`}
            icon={ShoppingBag}
            trendText="Dine-in (60) · Delivery (34)"
            trendDirection="up"
            subtext="Avg ₹382 check size"
            accent="mint"
            onClick={() => onNavigate('sales-analytics')}
          />
          <MetricCard
            title="Top Selling Dish"
            value="Chicken Biryani"
            icon={UtensilsCrossed}
            trendText="580 orders this month"
            trendDirection="up"
            subtext="₹1,97,200 revenue"
            accent="gold"
            onClick={() => onNavigate('restaurant-menu' as any)}
          />
          <MetricCard
            title="Low-Stock Ingredients"
            value={`${lowStockRestaurant.length} Items`}
            icon={AlertTriangle}
            trendText="Poultry & Dairy below safe min"
            trendDirection="warning"
            subtext="Action needed before dinner rush"
            accent="gold"
            onClick={() => onNavigate('inventory')}
          />
          <MetricCard
            title="Monthly Wastage"
            value={formatCurrency(RESTAURANT_PROFILE.monthlyWastageTotal)}
            icon={Trash2}
            trendText="1.8% of gross revenue"
            trendDirection="neutral"
            subtext="Produce & Dairy spoilage"
            accent="default"
            onClick={() => onNavigate('inventory')}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Sales (30D)"
            value={formatCurrency(STORE_HEADLINE_METRICS.totalSales)}
            icon={IndianRupee}
            trendText="+8.4%"
            trendDirection="up"
            subtext="vs last month"
            accent="gold"
            onClick={() => onNavigate('sales-analytics')}
          />
          <MetricCard
            title="Customer Orders"
            value={formatIndianNumber(STORE_HEADLINE_METRICS.totalOrders)}
            icon={ShoppingBag}
            trendText="+12 orders"
            trendDirection="up"
            subtext="30-day verified volume"
            accent="mint"
            onClick={() => onNavigate('sales-analytics')}
          />
          <MetricCard
            title="Products in Stock"
            value={formatIndianNumber(retailProducts.reduce((acc, p) => acc + p.stockQuantity, 0))}
            icon={Package}
            trendText={`${retailProducts.length} Active SKUs`}
            trendDirection="neutral"
            subtext="across 6 store categories"
            accent="default"
            onClick={() => onNavigate('inventory')}
          />
          <MetricCard
            title="Low Stock Alerts"
            value={`${lowStockRetail.length} Items`}
            icon={AlertTriangle}
            trendText="Replenishment required"
            trendDirection="warning"
            subtext="below safe reorder level"
            accent="gold"
            onClick={() => onNavigate('inventory')}
          />
        </div>
      )}

      {/* ROW 2: Sales Progression Line Chart & Top Earners Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Sales Progression Chart */}
        <div className="lg:col-span-7">
          <ChartCard
            title="Sales Over Time"
            subtitle={`Showing ${salesTimeframe === '7D' ? 'last 7 days' : 'last 30 days'} · Total: ${formatCurrency(periodTotalSales)} (${periodTotalOrders} ${businessType === 'restaurant' ? 'covers' : 'orders'})`}
            actionSlot={
              <div className="flex items-center gap-1 bg-[#0A192F] p-1 rounded-lg border border-[#F8F9FA]/10">
                <button
                  onClick={() => setSalesTimeframe('7D')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                    salesTimeframe === '7D' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                  }`}
                >
                  7D
                </button>
                <button
                  onClick={() => setSalesTimeframe('30D')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                    salesTimeframe === '30D' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                  }`}
                >
                  30D
                </button>
              </div>
            }
            footerNote={`Synchronized with ${businessType === 'restaurant' ? 'dining bill receipts' : 'retail transactions'}.`}
          >
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={chartSalesData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.06)" vertical={false} />
                <XAxis
                  dataKey="date"
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  interval={salesTimeframe === '7D' ? 0 : 4}
                />
                <YAxis
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `₹${val >= 1000 ? `${val / 1000}k` : val}`}
                />
                <Tooltip content={<CustomSalesTooltip />} />
                <Line
                  type="monotone"
                  dataKey="sales"
                  stroke="#FFB703"
                  strokeWidth={2.5}
                  dot={salesTimeframe === '7D' ? { r: 3.5, fill: '#FFB703' } : false}
                  activeDot={{ r: 5, fill: '#64FFDA' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Top Products / Dishes by Revenue Bar Chart */}
        <div className="lg:col-span-5">
          <ChartCard
            title={businessType === 'restaurant' ? 'Top Revenue Dishes' : 'Top Selling Products'}
            subtitle={businessType === 'restaurant' ? 'Highest revenue earners this month' : 'Ranked by volume of units sold'}
            actionSlot={
              <button
                onClick={() => onNavigate(businessType === 'restaurant' ? ('restaurant-menu' as any) : 'sales-analytics')}
                className="text-xs text-[#FFB703] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Full breakdown</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            }
            footerNote={businessType === 'restaurant' ? 'Biryani & Butter Chicken drive 41% of menu sales.' : 'Parle-G leads by volume (75 units); Rice leads by revenue.'}
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart
                data={businessType === 'restaurant' ? topRestaurantDishes : topRetailProducts}
                layout="vertical"
                margin={{ top: 5, right: 15, left: 20, bottom: 5 }}
              >
                <CartesianGrid stroke="rgba(248, 249, 250, 0.06)" horizontal={false} />
                <XAxis
                  type="number"
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(v) => (businessType === 'restaurant' ? `₹${v / 1000}k` : `${v}u`)}
                />
                <YAxis
                  dataKey="name"
                  type="category"
                  stroke="rgba(248, 249, 250, 0.7)"
                  fontSize={10}
                  tickLine={false}
                  width={100}
                />
                <Tooltip content={<CustomBarTooltip />} />
                <Bar
                  dataKey={businessType === 'restaurant' ? 'revenue' : 'units'}
                  fill={businessType === 'restaurant' ? '#FFB703' : '#64FFDA'}
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

      </div>

      {/* ROW 3: Actionable Business Insights Panel */}
      <Card className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-[#FFB703]/15 text-[#FFB703] flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[#F8F9FA] tracking-tight">
                Live Business Insights & Alerts
              </h3>
              <p className="text-xs text-[#F8F9FA]/60">
                Actionable recommendations synthesized from your inventory audits and sales trends.
              </p>
            </div>
          </div>
          <Badge variant="mint" size="sm">
            Operational Intelligence
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {businessType === 'restaurant' ? (
            <>
              <div className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">Stock Alert</span>
                    <Badge variant="critical" size="sm">Critical</Badge>
                  </div>
                  <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                    Poultry & Malai Paneer below threshold
                  </h4>
                  <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                    Broiler Chicken has only 8 kg left against 30 kg safe level. Reorder needed before dinner service.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                  <span>Action:</span>
                  <span className="text-[#F8F9FA]/80 truncate">Contact Bengaluru Poultry Farms</span>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">Menu Growth</span>
                    <Badge variant="mint" size="sm">Growth</Badge>
                  </div>
                  <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                    Dum Biryani + Lassi Combo Upsell
                  </h4>
                  <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                    Dum Biryani (580 orders) paired with Sweet Lassi (₹130, 68% margin) can boost basket value by 24%.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                  <span>Action:</span>
                  <span className="text-[#F8F9FA]/80 truncate">Launch Set Lunch Offer</span>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">Wastage</span>
                    <Badge variant="low" size="sm">Attention</Badge>
                  </div>
                  <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                    Vegetable Mandi spoilage rate (6.8%)
                  </h4>
                  <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                    Tomatoes and fresh mushrooms incurred ₹2,300 in monthly trim loss. Switch to alternate-day supply.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                  <span>Action:</span>
                  <span className="text-[#F8F9FA]/80 truncate">Revise Mandi purchase frequency</span>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">Peak Rush</span>
                    <Badge variant="mint" size="sm">Operations</Badge>
                  </div>
                  <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                    Dinner Rush 20:30 - 22:30 at 98% occupancy
                  </h4>
                  <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                    Peak surge averages 58 covers/hr. Stage gravies and tandoor dough by 19:30 to cut ticket times.
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                  <span>Action:</span>
                  <span className="text-[#F8F9FA]/80 truncate">Optimize kitchen line station</span>
                </div>
              </div>
            </>
          ) : (
            SAMPLE_AI_INSIGHTS.map((insight) => (
              <div
                key={insight.id}
                className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] hover:border-[#FFB703]/30 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">
                      {insight.category}
                    </span>
                    <Badge
                      variant={insight.impact === 'High' ? 'critical' : insight.impact === 'Growth' ? 'mint' : 'low'}
                      size="sm"
                    >
                      {insight.impact}
                    </Badge>
                  </div>
                  <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                    {insight.title}
                  </h4>
                  <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                    {insight.description}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                  <span>Action:</span>
                  <span className="text-[#F8F9FA]/80 truncate">{insight.suggestedAction}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* ROW 4: Low Stock Alerts Panel & Recent Activity / Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Low Stock Alerts Panel */}
        <div className="lg:col-span-5">
          <Card className="p-5 h-full flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#FFB703]" />
                <h3 className="text-base font-semibold text-[#F8F9FA]">
                  Low Stock Items ({businessType === 'restaurant' ? lowStockRestaurant.length : lowStockRetail.length})
                </h3>
              </div>
              <button
                onClick={() => onNavigate('inventory')}
                className="text-xs text-[#FFB703] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Restock all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <p className="text-xs text-[#F8F9FA]/60 mb-3">
              Items currently at or below minimum threshold. Replenishment recommended.
            </p>

            <div className="space-y-2 flex-1 overflow-y-auto max-h-[380px] pr-1">
              {(businessType === 'restaurant' ? lowStockRestaurant : lowStockRetail).map((item: any) => {
                const isCritical = item.stockQuantity <= (businessType === 'restaurant' ? 8 : 5);
                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.06] flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-[#F8F9FA] truncate">{item.name}</div>
                      <div className="text-[11px] text-[#F8F9FA]/50 truncate mt-0.5">
                        Supplier: {item.supplier}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono tabular-nums text-[#F8F9FA]">
                        <strong className={isCritical ? 'text-red-400' : 'text-[#FFB703]'}>
                          {item.stockQuantity} {item.unit || 'units'}
                        </strong>{' '}
                        / {item.reorderLevel} min
                      </div>
                      <div className="mt-1">
                        <Badge variant={isCritical ? 'critical' : 'low'} size="sm">
                          {isCritical ? 'Critical' : 'Low'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 pt-3 border-t border-[#F8F9FA]/[0.08] flex items-center justify-between text-xs text-[#F8F9FA]/50">
              <span>Automated stock sensor monitoring</span>
              <button
                onClick={() => onNavigate('inventory')}
                className="text-[#64FFDA] hover:underline cursor-pointer"
              >
                Go to Inventory →
              </button>
            </div>
          </Card>
        </div>

        {/* Right column: Recent Transactions (Retail) OR Peak Hours & Reviews (Restaurant) */}
        <div className="lg:col-span-7">
          {businessType === 'restaurant' ? (
            <Card className="p-5 flex flex-col h-full justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#FFB703]" />
                    <h3 className="text-base font-semibold text-[#F8F9FA]">
                      Peak Service Hours Breakdown
                    </h3>
                  </div>
                  <Badge variant="gold" size="sm">
                    Live Restaurant Traffic
                  </Badge>
                </div>
                <p className="text-xs text-[#F8F9FA]/60 mb-4">
                  Kitchen order rush patterns across prime dining slots
                </p>

                <div className="space-y-3">
                  {RESTAURANT_PEAK_HOURS.slice(0, 4).map((slot) => (
                    <div key={slot.timeSlot} className="p-3 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/[0.06] text-xs">
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="font-semibold text-[#F8F9FA]">{slot.label} ({slot.timeSlot})</span>
                        <span className="font-mono font-bold text-[#FFB703]">{formatCurrency(slot.avgRevenue)}</span>
                      </div>
                      <div className="flex justify-between text-[11px] text-[#F8F9FA]/60">
                        <span>{slot.avgCovers} covers</span>
                        <span className="text-[#64FFDA] font-medium">{slot.occupancyPercent}% table occupancy</span>
                      </div>
                      <div className="h-1.5 w-full bg-[#112240] rounded-full overflow-hidden mt-2">
                        <div
                          className="h-full bg-[#FFB703] rounded-full"
                          style={{ width: `${slot.occupancyPercent}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-xs text-[#F8F9FA]/50">
                <span>View Full Menu & Operations</span>
                <button
                  onClick={() => onNavigate('restaurant-ops' as any)}
                  className="text-[#64FFDA] hover:underline cursor-pointer"
                >
                  P&L Operations →
                </button>
              </div>
            </Card>
          ) : (
            <Card className="p-5 flex flex-col h-full">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-base font-semibold text-[#F8F9FA]">
                    Recent Customer Transactions
                  </h3>
                  <p className="text-xs text-[#F8F9FA]/60 mt-0.5">
                    Latest customer billing across cash, UPI, and card
                  </p>
                </div>

                {/* Status filter buttons */}
                <div className="flex items-center gap-1 p-1 bg-[#0A192F] rounded-lg border border-[#F8F9FA]/10">
                  {(['all', 'Completed', 'Pending', 'Refunded'] as const).map((status) => (
                    <button
                      key={status}
                      onClick={() => setTxnStatusFilter(status)}
                      className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                        txnStatusFilter === status ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                      }`}
                    >
                      {status === 'all' ? 'All' : status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Search Input */}
              <div className="mb-3 relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={txnSearch}
                  onChange={(e) => setTxnSearch(e.target.value)}
                  placeholder="Search transaction ID, customer, or items..."
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
                />
              </div>

              {/* Transactions Table */}
              <div className="overflow-x-auto flex-1 min-h-[260px]">
                {filteredTransactions.length === 0 ? (
                  <EmptyState
                    title="No transactions found"
                    description="No records match your active search and status filter."
                    actionLabel="Clear Filters"
                    onAction={() => {
                      setTxnSearch('');
                      setTxnStatusFilter('all');
                    }}
                    className="py-8"
                  />
                ) : (
                  <table className="w-full text-left text-xs whitespace-nowrap">
                    <thead>
                      <tr className="border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                        <th className="py-2.5 px-3">Txn ID</th>
                        <th className="py-2.5 px-3">Customer</th>
                        <th className="py-2.5 px-3">Items Summary</th>
                        <th className="py-2.5 px-3">Payment</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                      {filteredTransactions.map((txn) => (
                        <tr key={txn.id} className="hover:bg-[#F8F9FA]/[0.02] transition-colors">
                          <td className="py-2.5 px-3 font-mono text-[#F8F9FA]/70">{txn.id}</td>
                          <td className="py-2.5 px-3 font-medium text-[#F8F9FA]">{txn.customerName}</td>
                          <td className="py-2.5 px-3 text-[#F8F9FA]/70 max-w-[180px] truncate" title={txn.itemsSummary}>
                            {txn.itemsSummary}
                          </td>
                          <td className="py-2.5 px-3 text-[#F8F9FA]/60">{txn.paymentMethod}</td>
                          <td className="py-2.5 px-3 text-right font-medium tabular-nums text-[#FFB703]">
                            {formatCurrency(txn.amount)}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <Badge
                              variant={
                                txn.status === 'Completed' ? 'success' : txn.status === 'Pending' ? 'pending' : 'refunded'
                              }
                              size="sm"
                            >
                              {txn.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              <div className="mt-3 pt-3 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-[11px] text-[#F8F9FA]/40">
                <span>Showing {filteredTransactions.length} of {RECENT_TRANSACTIONS.length} transactions</span>
                <span className="font-mono">Verified POS terminal receipts</span>
              </div>
            </Card>
          )}
        </div>

      </div>

    </div>
  );
};
