import React, { useState, useMemo } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { Product, SAMPLE_PRODUCTS } from '../data/sampleData';
import { RawMaterial, RESTAURANT_RAW_MATERIALS } from '../data/restaurantData';
import {
  RestockEntry,
  RestockLineItem,
  BusinessType,
  generateCSV,
} from '../data/db';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  Package,
  Search,
  Filter,
  AlertTriangle,
  ArrowUpDown,
  Truck,
  PlusCircle,
  X,
  CheckCircle,
  Plus,
  Trash2,
  Calendar,
  Clock,
  Printer,
  Download,
  FileText,
  User,
  CreditCard,
  IndianRupee,
  Layers,
  History,
  Eye,
} from 'lucide-react';

interface InventoryProps {
  businessType?: BusinessType;
  businessName?: string;
  retailProducts?: Product[];
  restaurantMaterials?: RawMaterial[];
  restockHistory?: RestockEntry[];
  onAddRestock?: (entry: Omit<RestockEntry, 'id' | 'receiptNumber'>) => void;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

type InventoryTab = 'stock' | 'restock-history';
type SortField = 'name' | 'stockQuantity' | 'reorderLevel' | 'cost' | 'supplier';
type SortOrder = 'asc' | 'desc';

export const Inventory: React.FC<InventoryProps> = ({
  businessType = 'retail',
  businessName = 'My Store',
  retailProducts = SAMPLE_PRODUCTS,
  restaurantMaterials = RESTAURANT_RAW_MATERIALS,
  restockHistory = [],
  onAddRestock,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<InventoryTab>('stock');
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lowStockOnly, setLowStockOnly] = useState<boolean>(false);
  const [sortField, setSortField] = useState<SortField>('stockQuantity');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  // Restock History filters
  const [historySearch, setHistorySearch] = useState('');
  const [historyPaymentFilter, setHistoryPaymentFilter] = useState<'all' | 'Cash' | 'Online'>('all');

  // Restock Modal Form State
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [restockStaff, setRestockStaff] = useState<string>(
    businessType === 'restaurant' ? 'Chef Vinod (Head Chef)' : 'Ramesh (Store Manager)'
  );
  const [customStaffInput, setCustomStaffInput] = useState<string>('');
  const [isAddingNewStaff, setIsAddingNewStaff] = useState(false);
  
  const [restockDate, setRestockDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [restockTime, setRestockTime] = useState<string>(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );
  const [restockSupplier, setRestockSupplier] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'Online'>('Online');
  const [onlineMethod, setOnlineMethod] = useState<'UPI' | 'Bank Transfer' | 'Card'>('UPI');
  const [transactionId, setTransactionId] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');

  // Restock line items
  const [lineItems, setLineItems] = useState<RestockLineItem[]>([
    {
      id: `line-${Date.now()}-1`,
      itemName: businessType === 'restaurant' ? 'Daawat Rozana Basmati Rice' : 'Basmati Rice 5kg',
      quantity: 10,
      unit: businessType === 'restaurant' ? 'kg' : 'bags',
      unitCost: businessType === 'restaurant' ? 92 : 380,
      lineTotal: businessType === 'restaurant' ? 920 : 3800,
    },
  ]);

  // Selected receipt for printable receipt modal
  const [selectedReceipt, setSelectedReceipt] = useState<RestockEntry | null>(null);

  // Available staff suggestions
  const staffList = useMemo(() => {
    return businessType === 'restaurant'
      ? ['Chef Vinod (Head Chef)', 'Anita (Kitchen Supervisor)', 'Sunil (Inventory Lead)', 'Rajesh Shetty (Owner)']
      : ['Ramesh (Store Manager)', 'Sunil (Inventory Assistant)', 'Pooja (Cashier)', 'Suresh Kumar (Owner)'];
  }, [businessType]);

  // Extract unique categories and suppliers
  const { categories, supplierList } = useMemo(() => {
    if (businessType === 'restaurant') {
      const cats = Array.from(new Set(restaurantMaterials.map((m) => m.category)));
      const sups = Array.from(new Set(restaurantMaterials.map((m) => m.supplier)));
      return { categories: ['all', ...cats], supplierList: sups };
    }
    const cats = Array.from(new Set(retailProducts.map((p) => p.category)));
    const sups = Array.from(new Set(retailProducts.map((p) => p.supplier)));
    return { categories: ['all', ...cats], supplierList: sups };
  }, [businessType, restaurantMaterials, retailProducts]);

  // Unified items list for stock control view
  const currentItems = useMemo(() => {
    if (businessType === 'restaurant') {
      return restaurantMaterials.map((m) => ({
        id: m.id,
        name: m.name,
        category: m.category,
        stockQuantity: m.stockQuantity,
        reorderLevel: m.reorderLevel,
        unit: m.unit,
        cost: m.costPerUnit,
        supplier: m.supplier,
        extraInfo: `Expiry: ${m.expiryDate} · Wastage: ${m.wastagePercent}%`,
        isLow: m.stockQuantity < m.reorderLevel,
        isCritical: m.stockQuantity <= Math.max(3, m.reorderLevel * 0.3),
      }));
    }
    return retailProducts.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      stockQuantity: p.stockQuantity,
      reorderLevel: p.reorderLevel,
      unit: 'units',
      cost: p.costPrice,
      supplier: p.supplier,
      extraInfo: `SKU: ${p.sku} · Price: ₹${p.price}`,
      isLow: p.stockQuantity < p.reorderLevel,
      isCritical: p.stockQuantity <= 5,
    }));
  }, [businessType, restaurantMaterials, retailProducts]);

  // Filtered & sorted items
  const filteredStock = useMemo(() => {
    return currentItems.filter((item) => {
      const matchesSearch =
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.category.toLowerCase().includes(search.toLowerCase()) ||
        item.supplier.toLowerCase().includes(search.toLowerCase());
      const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
      const matchesLow = !lowStockOnly || item.isLow;
      return matchesSearch && matchesCat && matchesLow;
    }).sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
      }
      return sortOrder === 'asc' ? valA - valB : valB - valA;
    });
  }, [currentItems, search, selectedCategory, lowStockOnly, sortField, sortOrder]);

  // Filtered Restock History
  const filteredHistory = useMemo(() => {
    return restockHistory.filter((entry) => {
      const q = historySearch.toLowerCase();
      const matchesQuery =
        entry.receiptNumber.toLowerCase().includes(q) ||
        entry.staffName.toLowerCase().includes(q) ||
        entry.supplierName.toLowerCase().includes(q) ||
        entry.items.some((i) => i.itemName.toLowerCase().includes(q));

      const matchesPayment = historyPaymentFilter === 'all' || entry.paymentMode === historyPaymentFilter;
      return matchesQuery && matchesPayment;
    });
  }, [restockHistory, historySearch, historyPaymentFilter]);

  // Restock calculation totals
  const totalBill = useMemo(() => {
    return lineItems.reduce((acc, curr) => acc + (curr.lineTotal || 0), 0);
  }, [lineItems]);

  const balanceDue = Math.max(0, totalBill - amountPaid);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Add line item in modal
  const handleAddLineItem = () => {
    const defaultItem = currentItems[0];
    const newItem: RestockLineItem = {
      id: `line-${Date.now()}-${lineItems.length + 1}`,
      itemName: defaultItem ? defaultItem.name : 'Raw Material Item',
      quantity: 10,
      unit: defaultItem ? defaultItem.unit : 'units',
      unitCost: defaultItem ? defaultItem.cost : 100,
      lineTotal: defaultItem ? defaultItem.cost * 10 : 1000,
    };
    setLineItems([...lineItems, newItem]);
  };

  // Update line item
  const handleUpdateLineItem = (id: string, field: keyof RestockLineItem, value: any) => {
    setLineItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updated = { ...item, [field]: value };
          if (field === 'quantity' || field === 'unitCost') {
            updated.lineTotal = (Number(updated.quantity) || 0) * (Number(updated.unitCost) || 0);
          }
          if (field === 'itemName') {
            const found = currentItems.find((c) => c.name.toLowerCase() === String(value).toLowerCase());
            if (found) {
              updated.unit = found.unit;
              updated.unitCost = found.cost;
              updated.lineTotal = (Number(updated.quantity) || 0) * found.cost;
            }
          }
          return updated;
        }
        return item;
      })
    );
  };

  // Remove line item
  const handleRemoveLineItem = (id: string) => {
    if (lineItems.length <= 1) {
      onShowToast('At least one restock line item is required.', 'warning');
      return;
    }
    setLineItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Quick open restock with selected product
  const handleQuickRestockItem = (item: typeof currentItems[0]) => {
    const suggestedQty = Math.max(10, item.reorderLevel - item.stockQuantity + 5);
    setLineItems([
      {
        id: `line-${Date.now()}`,
        itemName: item.name,
        quantity: suggestedQty,
        unit: item.unit,
        unitCost: item.cost,
        lineTotal: suggestedQty * item.cost,
      },
    ]);
    setRestockSupplier(item.supplier);
    setAmountPaid(suggestedQty * item.cost);
    setShowRestockModal(true);
  };

  // Save Restock Entry
  const handleSaveRestockEntry = (e: React.FormEvent) => {
    e.preventDefault();

    const effectiveStaff = isAddingNewStaff && customStaffInput.trim() ? customStaffInput.trim() : restockStaff;
    const effectiveSupplier = restockSupplier.trim() || (supplierList[0] || 'Primary Wholesale Supplier');

    if (!lineItems || lineItems.length === 0) {
      onShowToast('Please add at least one item to restock.', 'warning');
      return;
    }

    const newRestockData: Omit<RestockEntry, 'id' | 'receiptNumber'> = {
      date: restockDate,
      time: restockTime,
      businessType,
      businessName,
      staffName: effectiveStaff,
      supplierName: effectiveSupplier,
      items: lineItems,
      totalBill,
      amountPaid: Number(amountPaid) || 0,
      balanceDue,
      paymentMode,
      onlineMethod: paymentMode === 'Online' ? onlineMethod : undefined,
      transactionId: paymentMode === 'Online' && transactionId.trim() ? transactionId.trim() : undefined,
      notes: notes.trim(),
    };

    if (onAddRestock) {
      onAddRestock(newRestockData);
    }

    onShowToast(
      `Restocked ${lineItems.length} item(s) successfully. Stock counts updated in live database.`,
      'success',
      'Inventory Restocked'
    );

    setShowRestockModal(false);
    // Reset form
    setLineItems([
      {
        id: `line-${Date.now()}`,
        itemName: currentItems[0]?.name || 'Item',
        quantity: 10,
        unit: currentItems[0]?.unit || 'units',
        unitCost: currentItems[0]?.cost || 100,
        lineTotal: (currentItems[0]?.cost || 100) * 10,
      },
    ]);
    setNotes('');
    setTransactionId('');
  };

  // CSV Export
  const handleExportHistoryCSV = () => {
    const headers = [
      'Receipt #',
      'Date',
      'Time',
      'Staff Name',
      'Supplier',
      'Items Count',
      'Total Bill (INR)',
      'Amount Paid (INR)',
      'Balance Due (INR)',
      'Payment Mode',
      'Online Method',
      'Transaction ID',
      'Notes',
    ];

    const rows = restockHistory.map((entry) => [
      entry.receiptNumber,
      entry.date,
      entry.time,
      entry.staffName,
      entry.supplierName,
      entry.items.length,
      entry.totalBill,
      entry.amountPaid,
      entry.balanceDue,
      entry.paymentMode,
      entry.onlineMethod || '',
      entry.transactionId || '',
      entry.notes || '',
    ]);

    const csvContent = generateCSV(headers, rows);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `udaan-restock-history-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    onShowToast('Restock history exported to CSV.', 'success');
  };

  // Print Receipt handler
  const handlePrintReceipt = (receipt: RestockEntry) => {
    setSelectedReceipt(receipt);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  const lowStockCount = currentItems.filter((i) => i.isLow).length;
  const totalStockUnits = currentItems.reduce((acc, i) => acc + i.stockQuantity, 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            {businessType === 'restaurant' ? 'Raw Materials & Kitchen Inventory' : 'Inventory & Stock Control'}
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Real-time stock audits, threshold alerts, supplier procurement, and restocking receipts.
          </p>
        </div>

        {/* Primary Restock Button + Tab Navigation */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center p-1 bg-[#112240] rounded-xl border border-[#F8F9FA]/10">
            <button
              onClick={() => setActiveTab('stock')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                activeTab === 'stock' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
              }`}
            >
              Active Inventory ({currentItems.length})
            </button>
            <button
              onClick={() => setActiveTab('restock-history')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'restock-history' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Restock History ({restockHistory.length})</span>
            </button>
          </div>

          <button
            onClick={() => {
              setRestockSupplier(supplierList[0] || '');
              setShowRestockModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Restock Entry</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: ACTIVE INVENTORY LIST */}
      {/* ========================================================================= */}
      {activeTab === 'stock' && (
        <div className="space-y-5">
          {/* Headline stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="p-4 border-l-4 border-l-[#64FFDA]">
              <div className="text-xs text-[#F8F9FA]/60">Total Active SKUs / Materials</div>
              <div className="text-xl sm:text-2xl font-bold font-display text-[#64FFDA] mt-1 tabular-nums">
                {currentItems.length} Items
              </div>
              <div className="text-[11px] text-[#F8F9FA]/50 mt-1">
                {totalStockUnits} total units in stock
              </div>
            </Card>

            <Card className="p-4 border-l-4 border-l-[#FFB703]">
              <div className="text-xs text-[#F8F9FA]/60">Low Stock Reorder Alerts</div>
              <div className="text-xl sm:text-2xl font-bold font-display text-[#FFB703] mt-1 tabular-nums">
                {lowStockCount} Items
              </div>
              <div className="text-[11px] text-red-300 mt-1 font-medium">
                At or below minimum threshold
              </div>
            </Card>

            <Card className="p-4 border-l-4 border-l-[#38BDF8]">
              <div className="text-xs text-[#F8F9FA]/60">Restock Receipts Recorded</div>
              <div className="text-xl sm:text-2xl font-bold font-display text-[#38BDF8] mt-1 tabular-nums">
                {restockHistory.length} Batches
              </div>
              <div className="text-[11px] text-[#F8F9FA]/50 mt-1">
                Viewable in Restock History tab
              </div>
            </Card>
          </div>

          {/* Search & Filters */}
          <Card className="p-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              {/* Search Box */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={`Search by ${businessType === 'restaurant' ? 'raw material' : 'product name'}, supplier, or category...`}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
                />
                {search && (
                  <button
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40 hover:text-[#F8F9FA]"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Category Filter */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#F8F9FA]/60">Category:</span>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none cursor-pointer"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat} className="bg-[#112240] text-[#F8F9FA]">
                        {cat === 'all' ? 'All Categories' : cat}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Low stock only button */}
                <button
                  onClick={() => setLowStockOnly(!lowStockOnly)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                    lowStockOnly
                      ? 'bg-[#FFB703]/15 border-[#FFB703] text-[#FFB703]'
                      : 'bg-[#0A192F] border-[#F8F9FA]/15 text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-[#FFB703]" />
                  <span>Low stock only ({lowStockCount})</span>
                </button>
              </div>
            </div>
          </Card>

          {/* Inventory Table */}
          <Card className="p-0 overflow-hidden">
            <div className="overflow-x-auto">
              {filteredStock.length === 0 ? (
                <div className="p-8">
                  <EmptyState
                    title="No inventory records found"
                    description="Try resetting your active category or low-stock search filter."
                    actionLabel="Reset Search"
                    onAction={() => {
                      setSearch('');
                      setSelectedCategory('all');
                      setLowStockOnly(false);
                    }}
                  />
                </div>
              ) : (
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead>
                    <tr className="bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                      <th
                        onClick={() => toggleSort('name')}
                        className="py-3 px-4 cursor-pointer hover:text-[#F8F9FA]"
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Item & Details</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th className="py-3 px-4">Category</th>
                      <th
                        onClick={() => toggleSort('cost')}
                        className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                      >
                        <div className="flex items-center justify-end gap-1.5">
                          <span>Cost Rate</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th
                        onClick={() => toggleSort('stockQuantity')}
                        className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                      >
                        <div className="flex items-center justify-end gap-1.5">
                          <span>Current Stock / Reorder</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th
                        onClick={() => toggleSort('supplier')}
                        className="py-3 px-4 cursor-pointer hover:text-[#F8F9FA]"
                      >
                        <div className="flex items-center gap-1.5">
                          <span>Supplier</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Quick Restock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                    {filteredStock.map((item) => (
                      <tr
                        key={item.id}
                        className={`hover:bg-[#F8F9FA]/[0.02] transition-colors ${
                          item.isCritical ? 'bg-red-500/[0.03]' : item.isLow ? 'bg-[#FFB703]/[0.02]' : ''
                        }`}
                      >
                        <td className="py-3 px-4">
                          <div className="font-semibold text-[#F8F9FA]">{item.name}</div>
                          <div className="text-[10px] text-[#F8F9FA]/45">{item.extraInfo}</div>
                        </td>
                        <td className="py-3 px-4 text-[#F8F9FA]/70">{item.category}</td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]/80">
                          {formatCurrency(item.cost)}/{item.unit}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          <span
                            className={`font-bold ${
                              item.isCritical ? 'text-red-400' : item.isLow ? 'text-[#FFB703]' : 'text-[#64FFDA]'
                            }`}
                          >
                            {item.stockQuantity} {item.unit}
                          </span>{' '}
                          <span className="text-[#F8F9FA]/40">/ {item.reorderLevel} min</span>
                        </td>
                        <td className="py-3 px-4 text-[#F8F9FA]/65 max-w-[150px] truncate">
                          {item.supplier}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <Badge
                            variant={item.isCritical ? 'critical' : item.isLow ? 'low' : 'ok'}
                            size="sm"
                          >
                            {item.isCritical ? 'Critical' : item.isLow ? 'Low' : 'OK'}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleQuickRestockItem(item)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded transition-colors cursor-pointer"
                          >
                            Restock
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: RESTOCK HISTORY & RECEIPT LOG */}
      {/* ========================================================================= */}
      {activeTab === 'restock-history' && (
        <div className="space-y-4">
          <Card className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  placeholder="Search receipt #, staff receiver, supplier, or items..."
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2">
                {/* Payment mode filter */}
                <select
                  value={historyPaymentFilter}
                  onChange={(e) => setHistoryPaymentFilter(e.target.value as any)}
                  className="bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none cursor-pointer"
                >
                  <option value="all">All Payment Modes</option>
                  <option value="Cash">Cash Only</option>
                  <option value="Online">Online (UPI/Bank)</option>
                </select>

                <button
                  onClick={handleExportHistoryCSV}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#112240] border border-[#F8F9FA]/15 text-xs text-[#F8F9FA]/80 hover:text-[#64FFDA] hover:border-[#64FFDA]/40 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download CSV</span>
                </button>
              </div>
            </div>
          </Card>

          {/* History Records Table */}
          <Card className="p-0 overflow-hidden">
            <div className="overflow-x-auto">
              {filteredHistory.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#F8F9FA]/50">
                  No restock records found matching the active search.
                </div>
              ) : (
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead>
                    <tr className="bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                      <th className="py-3 px-4">Receipt # & Date</th>
                      <th className="py-3 px-4">Restocked By</th>
                      <th className="py-3 px-4">Supplier</th>
                      <th className="py-3 px-4">Items Summary</th>
                      <th className="py-3 px-4 text-right">Total Bill</th>
                      <th className="py-3 px-4 text-right">Amount Paid</th>
                      <th className="py-3 px-4 text-right">Balance Due</th>
                      <th className="py-3 px-4 text-center">Payment</th>
                      <th className="py-3 px-4 text-right">Receipt Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                    {filteredHistory.map((entry) => (
                      <tr key={entry.id} className="hover:bg-[#F8F9FA]/[0.02]">
                        <td className="py-3 px-4">
                          <div className="font-mono font-semibold text-[#FFB703]">{entry.receiptNumber}</div>
                          <div className="text-[10px] text-[#F8F9FA]/40">{entry.date} · {entry.time}</div>
                        </td>
                        <td className="py-3 px-4 font-medium text-[#F8F9FA]">{entry.staffName}</td>
                        <td className="py-3 px-4 text-[#F8F9FA]/70">{entry.supplierName}</td>
                        <td className="py-3 px-4 max-w-[180px] truncate text-[#F8F9FA]/80">
                          {entry.items.map((i) => `${i.quantity} ${i.unit} ${i.itemName}`).join(', ')}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]">
                          {formatCurrency(entry.totalBill)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-[#64FFDA] font-semibold">
                          {formatCurrency(entry.amountPaid)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {entry.balanceDue > 0 ? (
                            <span className="text-red-400 font-bold">{formatCurrency(entry.balanceDue)}</span>
                          ) : (
                            <span className="text-[#F8F9FA]/40">₹0 (Paid)</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <Badge variant={entry.paymentMode === 'Cash' ? 'gold' : 'mint'} size="sm">
                            {entry.paymentMode} {entry.onlineMethod ? `(${entry.onlineMethod})` : ''}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedReceipt(entry)}
                              className="px-2.5 py-1 text-[11px] rounded bg-[#112240] border border-[#F8F9FA]/15 text-[#F8F9FA] hover:border-[#FFB703] transition-colors cursor-pointer flex items-center gap-1"
                              title="View printable receipt"
                            >
                              <Eye className="w-3 h-3 text-[#FFB703]" />
                              <span>View Receipt</span>
                            </button>
                            <button
                              onClick={() => handlePrintReceipt(entry)}
                              className="p-1 rounded bg-[#0A192F] border border-[#F8F9FA]/15 text-[#64FFDA] hover:bg-[#64FFDA]/10 transition-colors cursor-pointer"
                              title="Print directly"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RESTOCK ENTRY MODAL FORM (Multi-line Items, Staff, Supplier, Payments)    */}
      {/* ========================================================================= */}
      {showRestockModal && (
        <div
          className="fixed inset-0 z-50 bg-[#0A192F]/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#112240] border border-[#FFB703]/30 rounded-2xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl relative text-[#F8F9FA] my-8">
            <button
              onClick={() => setShowRestockModal(false)}
              className="absolute top-5 right-5 text-[#F8F9FA]/50 hover:text-[#F8F9FA] p-1.5 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Title */}
            <div className="flex items-center gap-3 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
              <div className="w-10 h-10 rounded-xl bg-[#FFB703]/15 text-[#FFB703] flex items-center justify-center shrink-0">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold font-display text-[#F8F9FA]">
                  New Restock Entry
                </h3>
                <p className="text-xs text-[#F8F9FA]/60">
                  Log incoming delivery items, adjust inventory levels automatically, and generate vendor payment receipts.
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveRestockEntry} className="space-y-5 text-xs">
              
              {/* Header Details: Restocked by, Date, Time, Supplier */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#0A192F] p-3.5 rounded-xl border border-[#F8F9FA]/[0.08]">
                {/* Staff Name with Add New Option */}
                <div>
                  <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                    Restocked By (Staff)
                  </label>
                  {!isAddingNewStaff ? (
                    <div className="space-y-1">
                      <select
                        value={restockStaff}
                        onChange={(e) => {
                          if (e.target.value === 'NEW') {
                            setIsAddingNewStaff(true);
                          } else {
                            setRestockStaff(e.target.value);
                          }
                        }}
                        className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                      >
                        {staffList.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                        <option value="NEW">+ Add New Staff Name...</option>
                      </select>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        value={customStaffInput}
                        onChange={(e) => setCustomStaffInput(e.target.value)}
                        placeholder="Staff Name & Role"
                        className="w-full bg-[#112240] border border-[#FFB703] rounded-lg px-2 py-1 text-xs text-[#F8F9FA] focus:outline-none"
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => setIsAddingNewStaff(false)}
                        className="text-[#F8F9FA]/50 hover:text-[#F8F9FA] p-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Restock Date */}
                <div>
                  <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={restockDate}
                    onChange={(e) => setRestockDate(e.target.value)}
                    className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    required
                  />
                </div>

                {/* Restock Time */}
                <div>
                  <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                    Time
                  </label>
                  <input
                    type="text"
                    value={restockTime}
                    onChange={(e) => setRestockTime(e.target.value)}
                    placeholder="10:30 AM"
                    className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    required
                  />
                </div>

                {/* Supplier Name */}
                <div>
                  <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                    Supplier / Vendor
                  </label>
                  <input
                    type="text"
                    list="supplier-options"
                    value={restockSupplier}
                    onChange={(e) => setRestockSupplier(e.target.value)}
                    placeholder="Select or enter supplier..."
                    className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    required
                  />
                  <datalist id="supplier-options">
                    {supplierList.map((sup) => (
                      <option key={sup} value={sup} />
                    ))}
                  </datalist>
                </div>
              </div>

              {/* Multiple Line Items Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sm text-[#F8F9FA]">
                    Restocked Items & Quantities
                  </span>
                  <button
                    type="button"
                    onClick={handleAddLineItem}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#FFB703]/15 text-[#FFB703] hover:bg-[#FFB703]/25 font-medium text-xs transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Another Item</span>
                  </button>
                </div>

                <div className="bg-[#0A192F] rounded-xl border border-[#F8F9FA]/[0.08] overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-[#112240] border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                        <th className="p-2.5">Item Name</th>
                        <th className="p-2.5 w-24">Qty</th>
                        <th className="p-2.5 w-24">Unit</th>
                        <th className="p-2.5 w-28 text-right">Unit Rate (₹)</th>
                        <th className="p-2.5 w-28 text-right">Line Total</th>
                        <th className="p-2.5 w-10 text-center"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                      {lineItems.map((item, idx) => (
                        <tr key={item.id} className="hover:bg-[#F8F9FA]/[0.02]">
                          <td className="p-2">
                            <input
                              type="text"
                              list="items-autocomplete"
                              value={item.itemName}
                              onChange={(e) => handleUpdateLineItem(item.id, 'itemName', e.target.value)}
                              className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2 py-1 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                              placeholder="Search or enter item name"
                              required
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min={1}
                              value={item.quantity}
                              onChange={(e) => handleUpdateLineItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                              className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2 py-1 text-xs text-[#F8F9FA] text-right font-mono focus:border-[#FFB703] focus:outline-none"
                              required
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.unit}
                              onChange={(e) => handleUpdateLineItem(item.id, 'unit', e.target.value)}
                              className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2 py-1 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                              placeholder="kg / L / packs"
                            />
                          </td>
                          <td className="p-2 text-right">
                            <input
                              type="number"
                              min={0}
                              value={item.unitCost}
                              onChange={(e) => handleUpdateLineItem(item.id, 'unitCost', parseFloat(e.target.value) || 0)}
                              className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2 py-1 text-xs text-[#F8F9FA] text-right font-mono focus:border-[#FFB703] focus:outline-none"
                              required
                            />
                          </td>
                          <td className="p-2 text-right font-mono tabular-nums font-semibold text-[#FFB703]">
                            {formatCurrency(item.lineTotal)}
                          </td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveLineItem(item.id)}
                              className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                              title="Delete row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <datalist id="items-autocomplete">
                    {currentItems.map((c) => (
                      <option key={c.id} value={c.name} />
                    ))}
                  </datalist>
                </div>
              </div>

              {/* Payment Settlement & Financial Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#0A192F] p-4 rounded-xl border border-[#F8F9FA]/[0.08]">
                {/* Left: Payment Method Details */}
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1.5">
                      Payment Mode
                    </label>
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="paymentMode"
                          checked={paymentMode === 'Cash'}
                          onChange={() => setPaymentMode('Cash')}
                          className="accent-[#FFB703]"
                        />
                        <span className="text-xs text-[#F8F9FA]">Cash</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="paymentMode"
                          checked={paymentMode === 'Online'}
                          onChange={() => setPaymentMode('Online')}
                          className="accent-[#FFB703]"
                        />
                        <span className="text-xs text-[#F8F9FA]">Online Settlement</span>
                      </label>
                    </div>
                  </div>

                  {paymentMode === 'Online' && (
                    <div className="space-y-2 pt-1 border-t border-[#F8F9FA]/[0.06]">
                      <div className="flex gap-2">
                        {(['UPI', 'Bank Transfer', 'Card'] as const).map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setOnlineMethod(m)}
                            className={`px-2.5 py-1 rounded text-[11px] font-medium border transition-colors cursor-pointer ${
                              onlineMethod === m
                                ? 'bg-[#FFB703]/20 border-[#FFB703] text-[#FFB703]'
                                : 'bg-[#112240] border-[#F8F9FA]/15 text-[#F8F9FA]/70'
                            }`}
                          >
                            {m}
                          </button>
                        ))}
                      </div>

                      <div>
                        <label className="block text-[10px] text-[#F8F9FA]/60 mb-0.5">
                          Transaction Reference / UTR Number
                        </label>
                        <input
                          type="text"
                          value={transactionId}
                          onChange={(e) => setTransactionId(e.target.value)}
                          placeholder="e.g. UPI/71928014/HDFC or IMPS Ref"
                          className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2.5 py-1 text-xs font-mono text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-[10px] text-[#F8F9FA]/60 mb-0.5">
                      Notes & Observations
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Batch quality checked, bag condition, invoice remarks..."
                      className="w-full bg-[#112240] border border-[#F8F9FA]/15 rounded px-2.5 py-1 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Right: Financial Totals */}
                <div className="space-y-2 flex flex-col justify-between bg-[#112240] p-3.5 rounded-lg border border-[#F8F9FA]/[0.06]">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#F8F9FA]/70">Total Bill Amount:</span>
                      <span className="font-mono font-bold text-sm text-[#FFB703] tabular-nums">
                        {formatCurrency(totalBill)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-xs">
                      <span className="text-[#F8F9FA]/70">Amount Paid Now:</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[#F8F9FA]/50">₹</span>
                        <input
                          type="number"
                          min={0}
                          max={totalBill * 2}
                          value={amountPaid}
                          onChange={(e) => setAmountPaid(parseFloat(e.target.value) || 0)}
                          className="w-28 bg-[#0A192F] border border-[#64FFDA] rounded px-2 py-1 text-right font-mono font-bold text-[#64FFDA] text-xs focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex justify-between items-center text-xs pt-2 border-t border-[#F8F9FA]/[0.08]">
                      <span className="text-[#F8F9FA]/70">Balance Due to Supplier:</span>
                      <span className={`font-mono font-bold tabular-nums ${balanceDue > 0 ? 'text-red-400' : 'text-[#64FFDA]'}`}>
                        {formatCurrency(balanceDue)}
                      </span>
                    </div>
                  </div>

                  <div className="text-[10px] text-[#F8F9FA]/40 pt-2 border-t border-[#F8F9FA]/[0.04]">
                    * Automatically increments on-hand inventory counts and updates the Ask UDAAN live restock intelligence ledger.
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRestockModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-medium text-[#F8F9FA]/70 hover:text-[#F8F9FA] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
                >
                  Confirm & Update Stock
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PRINTABLE RECEIPT MODAL (Clean layout with business name & signature)     */}
      {/* ========================================================================= */}
      {selectedReceipt && (
        <div
          className="fixed inset-0 z-50 bg-[#0A192F]/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#112240] border border-[#FFB703]/30 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative text-[#F8F9FA] my-8">
            <button
              onClick={() => setSelectedReceipt(null)}
              className="absolute top-5 right-5 text-[#F8F9FA]/50 hover:text-[#F8F9FA] p-1.5 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Printable Receipt Canvas */}
            <div id="printable-receipt" className="space-y-5 bg-[#0A192F] p-6 rounded-xl border border-[#F8F9FA]/15">
              
              {/* Receipt Header */}
              <div className="text-center pb-4 border-b border-[#F8F9FA]/15">
                <div className="text-xl font-bold font-display text-[#FFB703] tracking-wide">
                  {selectedReceipt.businessName || businessName}
                </div>
                <div className="text-[11px] text-[#F8F9FA]/60 mt-0.5">
                  Official Goods Received & Procurement Voucher
                </div>
                <div className="text-xs font-mono font-semibold text-[#64FFDA] mt-2">
                  Receipt No: {selectedReceipt.receiptNumber}
                </div>
              </div>

              {/* Meta information */}
              <div className="grid grid-cols-2 gap-2 text-xs text-[#F8F9FA]/80">
                <div>
                  <span className="text-[#F8F9FA]/45">Date & Time: </span>
                  <span className="font-mono">{selectedReceipt.date} · {selectedReceipt.time}</span>
                </div>
                <div className="text-right">
                  <span className="text-[#F8F9FA]/45">Received by: </span>
                  <span className="font-medium text-[#F8F9FA]">{selectedReceipt.staffName}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-[#F8F9FA]/45">Vendor / Supplier: </span>
                  <span className="font-semibold text-[#F8F9FA]">{selectedReceipt.supplierName}</span>
                </div>
              </div>

              {/* Line items table */}
              <div className="border border-[#F8F9FA]/10 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#112240] border-b border-[#F8F9FA]/10 text-[#F8F9FA]/60 text-[10px] uppercase">
                      <th className="p-2">Item</th>
                      <th className="p-2 text-right">Qty</th>
                      <th className="p-2 text-right">Rate</th>
                      <th className="p-2 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F8F9FA]/[0.05]">
                    {selectedReceipt.items.map((line) => (
                      <tr key={line.id}>
                        <td className="p-2 font-medium text-[#F8F9FA]">{line.itemName}</td>
                        <td className="p-2 text-right font-mono">{line.quantity} {line.unit}</td>
                        <td className="p-2 text-right font-mono">₹{line.unitCost}</td>
                        <td className="p-2 text-right font-mono font-semibold text-[#FFB703]">
                          {formatCurrency(line.lineTotal)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Settlement summary */}
              <div className="space-y-1.5 text-xs pt-1">
                <div className="flex justify-between">
                  <span className="text-[#F8F9FA]/60">Total Bill Amount:</span>
                  <span className="font-mono font-bold text-[#F8F9FA]">{formatCurrency(selectedReceipt.totalBill)}</span>
                </div>
                <div className="flex justify-between text-[#64FFDA]">
                  <span>Amount Paid:</span>
                  <span className="font-mono font-bold">{formatCurrency(selectedReceipt.amountPaid)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#F8F9FA]/60">Payment Mode:</span>
                  <span className="font-medium text-[#F8F9FA]">
                    {selectedReceipt.paymentMode} {selectedReceipt.onlineMethod ? `(${selectedReceipt.onlineMethod})` : ''}
                  </span>
                </div>
                {selectedReceipt.transactionId && (
                  <div className="flex justify-between text-[11px] font-mono text-[#F8F9FA]/60">
                    <span>Txn Ref:</span>
                    <span>{selectedReceipt.transactionId}</span>
                  </div>
                )}
                <div className="flex justify-between pt-1 border-t border-[#F8F9FA]/10 font-bold">
                  <span>Balance Outstanding:</span>
                  <span className="font-mono text-red-400">{formatCurrency(selectedReceipt.balanceDue)}</span>
                </div>
              </div>

              {selectedReceipt.notes && (
                <div className="text-[11px] text-[#F8F9FA]/60 italic bg-[#112240] p-2.5 rounded">
                  Note: "{selectedReceipt.notes}"
                </div>
              )}

              {/* Signature line for authenticity */}
              <div className="pt-8 flex items-center justify-between text-xs text-[#F8F9FA]/70 border-t border-[#F8F9FA]/15">
                <div>
                  <div className="w-36 border-b border-dashed border-[#F8F9FA]/40 mb-1" />
                  <span className="text-[10px]">Supplier / Delivery Agent</span>
                </div>
                <div className="text-right">
                  <div className="w-36 border-b border-dashed border-[#F8F9FA]/40 mb-1 ml-auto" />
                  <span className="text-[10px]">Authorized Receiver Signature</span>
                </div>
              </div>

            </div>

            {/* Print & Close buttons */}
            <div className="flex items-center justify-end gap-3 mt-5">
              <button
                onClick={() => setSelectedReceipt(null)}
                className="px-4 py-2 text-xs font-medium text-[#F8F9FA]/70 hover:text-[#F8F9FA] transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
