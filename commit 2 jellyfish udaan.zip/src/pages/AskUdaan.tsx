import React, { useState, useRef, useEffect } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { BusinessType } from '../data/db';
import { formatCurrency } from '../utils/formatCurrency';
import {
  Bot,
  User,
  Send,
  Mic,
  MicOff,
  Trash2,
  Copy,
  Check,
  Sparkles,
  HelpCircle,
  AlertCircle,
  Volume2,
  Globe,
  RotateCcw,
  Cpu,
  ArrowRight,
  TrendingUp,
  Package,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'udaan';
  text: string;
  timestamp: string;
  isStreaming?: boolean;
}

interface AskUdaanProps {
  businessType?: BusinessType;
  businessData?: any;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

export const AskUdaan: React.FC<AskUdaanProps> = ({
  businessType = 'retail',
  businessData = {},
  onShowToast,
}) => {
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Voice speech state
  const [isListening, setIsListening] = useState(false);
  const [speechLanguage, setSpeechLanguage] = useState<'en-IN' | 'hi-IN'>('en-IN');
  const [autoSubmitOnSpeechEnd, setAutoSubmitOnSpeechEnd] = useState(true);
  const [speechSupportError, setSpeechSupportError] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory, isThinking]);

  // Suggested questions tailored to business type
  const suggestedChips = useMemoChips(businessType);

  function useMemoChips(type: BusinessType) {
    if (type === 'restaurant') {
      return [
        'Which dish is our #1 best seller by revenue?',
        'Which dishes are slow movers or not selling well?',
        'Which raw materials are below safe reorder levels?',
        'What was our net profit and operating margin this month?',
        'Who restocked poultry and vegetables last week and what was paid?',
        'What are our peak dining hours and average covers?',
      ];
    }
    return [
      'Which product sold the most units this month?',
      'Which products are currently running low on stock?',
      'Who handled the last restock and how much was paid in cash?',
      'Compare our sales this week against last week.',
      'What is our total gross revenue for October?',
      'Which suppliers have shipments due this week?',
    ];
  }

  // Handle Voice Microphone Recognition
  const handleToggleVoiceInput = async () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    setSpeechSupportError(null);

    // Check browser support
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupportError(
        'Speech Recognition is not supported by your browser. Please use Chrome, Edge, or Safari.'
      );
      onShowToast('Web Speech API is not supported in this browser.', 'warning');
      return;
    }

    // Step 1: Explicitly request microphone permission before recording
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        // Close audio track immediately after confirming permission
        stream.getTracks().forEach((track) => track.stop());
      }
    } catch (err: any) {
      console.warn('Microphone permission error:', err);
      const msg =
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Microphone access was denied. Please allow microphone permissions in your browser address bar.'
          : 'Could not access audio device: ' + (err.message || 'Check microphone connection.');
      setSpeechSupportError(msg);
      onShowToast(msg, 'warning', 'Permission Required');
      return;
    }

    // Step 2: Initialize SpeechRecognition instance
    try {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = speechLanguage;

      let finalTranscript = '';

      recognition.onstart = () => {
        setIsListening(true);
        onShowToast(
          `Listening in ${speechLanguage === 'hi-IN' ? 'Hindi (hi-IN)' : 'English (en-IN)'}... Speak now.`,
          'info'
        );
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        const currentText = finalTranscript || interimTranscript;
        setInputText(currentText);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error !== 'no-speech') {
          setSpeechSupportError(`Voice input error: ${event.error}`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        if (autoSubmitOnSpeechEnd && finalTranscript.trim()) {
          handleAsk(finalTranscript.trim());
        }
      };

      recognition.start();
    } catch (err: any) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
      setSpeechSupportError('Could not start speech recognition service.');
    }
  };

  // Submit Question to Gemini Backend
  const handleAsk = async (queryText: string) => {
    const query = queryText.trim();
    if (!query || isThinking) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatHistory((prev) => [...prev, userMessage]);
    setInputText('');
    setIsThinking(true);
    setSpeechSupportError(null);

    try {
      // Call server-side /api/chat endpoint with live business JSON data
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: chatHistory.map((h) => ({ sender: h.sender, text: h.text })),
          businessData,
          language: speechLanguage === 'hi-IN' ? 'hi' : 'en',
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      const replyText =
        data.reply ||
        'I have analyzed your business records but could not compile a response. Please try rephrasing.';

      const udaanMessage: ChatMessage = {
        id: `udaan-${Date.now()}`,
        sender: 'udaan',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatHistory((prev) => [...prev, udaanMessage]);
    } catch (err: any) {
      console.error('Failed to get answer from /api/chat:', err);

      // Graceful fallback grounded in provided business data
      const fallbackAnswer = generateClientSideFallbackAnswer(query, businessData, businessType);

      const fallbackMessage: ChatMessage = {
        id: `udaan-${Date.now()}`,
        sender: 'udaan',
        text: fallbackAnswer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatHistory((prev) => [...prev, fallbackMessage]);
    } finally {
      setIsThinking(false);
    }
  };

  // Copy answer to clipboard
  const handleCopyAnswer = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast('Answer copied to clipboard.', 'success');
    setTimeout(() => {
      setCopiedId(null);
    }, 2500);
  };

  // Clear chat
  const handleClearChat = () => {
    setChatHistory([]);
    setInputText('');
    onShowToast('Conversation cleared.', 'info');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F8F9FA]/[0.08]">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-[#FFB703]/10 text-[#FFB703] text-xs font-medium mb-1.5">
            <Cpu className="w-3.5 h-3.5" />
            <span>ASK UDAAN · Business Intelligence</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Ask Anything About Your Business
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-0.5">
            Grounded in your live sales, inventory, recipes, staff restock entries, and operating ledger.
          </p>
        </div>

        {chatHistory.length > 0 && (
          <button
            onClick={handleClearChat}
            className="self-start sm:self-center inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#F8F9FA]/15 text-xs text-[#F8F9FA]/70 hover:text-red-300 hover:border-red-400/40 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear conversation</span>
          </button>
        )}
      </div>

      {/* Suggested Question Chips */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-[#F8F9FA]/60 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-[#FFB703]" />
            <span>Suggested questions for {businessType === 'restaurant' ? 'Restaurant' : 'Retail Store'}:</span>
          </span>
          <span className="text-[11px] text-[#64FFDA]">Click to ask instantly</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {suggestedChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInputText(chip);
                handleAsk(chip);
              }}
              disabled={isThinking}
              className="text-xs px-3 py-2 rounded-xl bg-[#112240] border border-[#F8F9FA]/10 hover:border-[#FFB703]/60 hover:text-[#FFB703] text-[#F8F9FA]/80 transition-all text-left shadow-sm cursor-pointer disabled:opacity-50"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Primary Input Container with Voice Speech Recognition */}
      <Card className="p-3.5 sm:p-4 border-[#FFB703]/30 shadow-xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleAsk(inputText);
          }}
          className="space-y-3"
        >
          {/* Text Area */}
          <div className="relative">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleAsk(inputText);
                }
              }}
              rows={3}
              placeholder={
                isListening
                  ? 'Listening to speech... Speak clearly in your selected language...'
                  : businessType === 'restaurant'
                  ? 'Type or speak: e.g. Which dish is our top seller? or Who restocked chicken last week?...'
                  : 'Type or speak: e.g. Which product sold the most? or How much cash was paid to suppliers?...'
              }
              className={`w-full bg-[#0A192F] border rounded-xl p-3.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:outline-none resize-none transition-colors ${
                isListening ? 'border-[#64FFDA] ring-2 ring-[#64FFDA]/30' : 'border-[#F8F9FA]/10 focus:border-[#FFB703]'
              }`}
            />

            {/* Live listening pulsing indicator */}
            {isListening && (
              <div className="absolute top-3 right-3 flex items-center gap-2 bg-[#112240] px-2.5 py-1 rounded-full border border-[#64FFDA]/40 text-[11px] text-[#64FFDA]">
                <span className="w-2 h-2 rounded-full bg-[#64FFDA] animate-ping" />
                <span>Recording voice...</span>
              </div>
            )}
          </div>

          {/* Speech Error Notice if any */}
          {speechSupportError && (
            <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{speechSupportError}</span>
            </div>
          )}

          {/* Controls Bar: Mic, Language, Auto-submit toggle, and Send button */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-[#F8F9FA]/[0.06]">
            
            {/* Left Controls: Voice and Language */}
            <div className="flex items-center flex-wrap gap-2">
              {/* Mic Button */}
              <button
                type="button"
                onClick={handleToggleVoiceInput}
                className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                  isListening
                    ? 'bg-red-500/20 border-red-500 text-red-300 animate-pulse'
                    : 'bg-[#0A192F] border-[#F8F9FA]/15 text-[#64FFDA] hover:border-[#64FFDA]/50'
                }`}
                title={isListening ? 'Stop recording' : 'Click to speak question'}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>{isListening ? 'Stop Listening' : 'Voice Input'}</span>
              </button>

              {/* Language Selector */}
              <div className="flex items-center gap-1 bg-[#0A192F] px-2 py-1.5 rounded-lg border border-[#F8F9FA]/15 text-xs">
                <Globe className="w-3.5 h-3.5 text-[#FFB703]" />
                <select
                  value={speechLanguage}
                  onChange={(e) => setSpeechLanguage(e.target.value as any)}
                  className="bg-transparent text-[#F8F9FA] focus:outline-none cursor-pointer"
                >
                  <option value="en-IN" className="bg-[#112240]">English (en-IN)</option>
                  <option value="hi-IN" className="bg-[#112240]">हिंदी (hi-IN)</option>
                </select>
              </div>

              {/* Auto-submit on speech end toggle */}
              <label className="hidden sm:flex items-center gap-1.5 text-[11px] text-[#F8F9FA]/60 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoSubmitOnSpeechEnd}
                  onChange={(e) => setAutoSubmitOnSpeechEnd(e.target.checked)}
                  className="w-3.5 h-3.5 rounded border-[#F8F9FA]/20 bg-[#0A192F] text-[#FFB703] cursor-pointer"
                />
                <span>Auto-send on pause</span>
              </label>
            </div>

            {/* Right: Ask Button */}
            <button
              type="submit"
              disabled={!inputText.trim() || isThinking}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isThinking ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-[#0A192F]" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Thinking...</span>
                </>
              ) : (
                <>
                  <Bot className="w-4 h-4" />
                  <span>Ask UDAAN</span>
                  <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>

          </div>
        </form>
      </Card>

      {/* Chat Conversation Stream */}
      <div className="space-y-5 pt-2">
        {chatHistory.length === 0 ? (
          <EmptyState
            icon={Bot}
            title="Ask your first business question"
            description="Select any prompt above or type or speak in plain language to analyze sales, discover top earners, check low stock, or compare weekly revenue."
            className="py-12"
          />
        ) : (
          chatHistory.map((msg) => {
            const isUser = msg.sender === 'user';

            if (isUser) {
              return (
                <div key={msg.id} className="flex justify-end gap-3">
                  <div className="max-w-xl bg-[#1B2D4F] border border-[#F8F9FA]/10 text-[#F8F9FA] rounded-2xl rounded-tr-sm p-4 text-sm shadow-sm">
                    <div className="flex items-center justify-between gap-3 text-[11px] text-[#F8F9FA]/50 mb-1">
                      <span className="font-semibold text-[#FFB703]">You</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <div className="whitespace-pre-wrap leading-relaxed">{msg.text}</div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-[#1B2D4F] border border-[#FFB703]/30 text-[#FFB703] flex items-center justify-center shrink-0 text-xs font-semibold">
                    <User className="w-4 h-4" />
                  </div>
                </div>
              );
            }

            // UDAAN AI Assistant Response
            return (
              <div key={msg.id} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-[#FFB703] text-[#0A192F] flex items-center justify-center shrink-0 shadow-md">
                  <Bot className="w-4 h-4" />
                </div>

                <div className="flex-1 bg-[#112240] border border-[#FFB703]/25 rounded-2xl rounded-tl-sm p-5 space-y-3 shadow-xl">
                  {/* Top bar with copy button and assistant title */}
                  <div className="flex items-center justify-between border-b border-[#F8F9FA]/[0.08] pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-display font-semibold text-sm text-[#F8F9FA]">
                        ASK UDAAN Assistant
                      </span>
                      <span className="text-[10px] text-[#F8F9FA]/40 font-mono">
                        {msg.timestamp}
                      </span>
                    </div>

                    <button
                      onClick={() => handleCopyAnswer(msg.id, msg.text)}
                      className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-[11px] text-[#F8F9FA]/70 hover:text-[#64FFDA] hover:bg-[#F8F9FA]/[0.05] transition-colors cursor-pointer"
                      title="Copy answer"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-[#64FFDA]" />
                          <span className="text-[#64FFDA]">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Rendered answer text with formatted paragraphs */}
                  <div className="text-sm text-[#F8F9FA] leading-relaxed whitespace-pre-wrap space-y-2">
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* Live Thinking indicator */}
        {isThinking && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#FFB703] text-[#0A192F] flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="bg-[#112240] border border-[#FFB703]/30 rounded-2xl rounded-tl-sm p-4 text-xs text-[#FFB703] flex items-center gap-2">
              <span className="animate-pulse">Analyzing live store records with Gemini...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Tasteful subtle footer note */}
      <div className="pt-4 text-center text-[11px] text-[#F8F9FA]/40 flex items-center justify-center gap-2">
        <span>Powered by Gemini</span>
        <span>·</span>
        <span>Grounded in your real store data</span>
      </div>

    </div>
  );
};

// Client-side grounded fallback calculator in case server / API is unavailable
function generateClientSideFallbackAnswer(query: string, data: any, type: BusinessType): string {
  const q = query.toLowerCase();

  if (type === 'restaurant') {
    if (q.includes('best') || q.includes('top') || q.includes('most sold')) {
      return `Based on October dining receipts, **Hyderabadi Dum Biryani (Chicken)** is your #1 top seller with **580 orders** generating **₹1,97,200** in revenue. Butter Chicken follows closely with 510 plates (₹1,93,800).`;
    }
    if (q.includes('slow') || q.includes('worst') || q.includes('not selling')) {
      return `Your slowest-moving dishes this month are **Tandoori Broccoli (18 plates)**, **Kashmiri Saffron Pulao (22 plates)**, and **Kadai Mushroom (24 plates)**. Recommendation: Group them into set meals or adjust procurement to prevent vegetable wastage.`;
    }
    if (q.includes('low') || q.includes('stock') || q.includes('reorder')) {
      return `You have **7 raw materials below safe reorder levels**: Broiler Chicken (8 kg left / 30 kg min), Fresh Mutton (4 kg left / 20 kg min), Malai Paneer (6 kg left / 25 kg min), and Commercial LPG Cylinders (2 cylinders left / 5 min). Immediate vendor order recommended.`;
    }
    if (q.includes('restock') || q.includes('who') || q.includes('paid')) {
      return `Recent Restock: **Chef Vinod** received 40 kg Broiler Chicken & 15 kg Boneless Fillets from **Bengaluru Fresh Poultry Farms** (Receipt REC-RST-2026-441). ₹11,100 was settled via UPI.`;
    }
    if (q.includes('profit') || q.includes('p&l') || q.includes('margin') || q.includes('revenue')) {
      return `October Turnover: **₹9,48,600** across 2,480 dining covers. Cost of Goods Sold is ~₹3,40,000 (35.8% food cost ratio). Fixed operating expenses (Rent ₹65k, Payroll ₹1.1L, LPG & Power ₹28k, Packaging ₹14k) total ₹2,28,000. Estimated Net Profit: **₹3,79,960** (~40% operating margin).`;
    }
  } else {
    if (q.includes('most') || q.includes('top') || q.includes('best')) {
      return `**Parle-G Biscuits** is your highest-volume product with **75 units sold**, while **Basmati Rice 5kg** produced the highest gross revenue at **₹10,800** across 24 bags.`;
    }
    if (q.includes('low') || q.includes('stock') || q.includes('reorder')) {
      return `**8 products are currently below safe reorder levels**. Amul Butter (3 units left) and Basmati Rice (4 units left) are at critical emergency thresholds. Total estimated replenishment cost is ₹14,240 across 4 suppliers.`;
    }
    if (q.includes('sales') || q.includes('month') || q.includes('revenue')) {
      return `October recorded sales stand at **₹48,250** across **126 verified customer receipts**, an **8.4% increase** over September turnover (₹44,500).`;
    }
    if (q.includes('restock') || q.includes('who') || q.includes('paid')) {
      return `Last restock was logged by **Ramesh (Store Manager)** on Oct 24: 20 bags Basmati Rice 5kg & 50 packs Parle-G from **Sri Lakshmi Traders**. ₹8,800 was settled via UPI.`;
    }
  }

  return `I have reviewed your current ${type === 'restaurant' ? 'restaurant' : 'retail store'} database. You can ask me about best-selling dishes, slow-moving items, low-stock alerts, staff restock entries, supplier payments, or profit margins.`;
}
