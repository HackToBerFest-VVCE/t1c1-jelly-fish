import React, { useState } from 'react';
import { Logo } from '../components/Logo';
import { UserAccount, getStoredUsers, registerNewUser, setStoredSession, BusinessType } from '../data/db';
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  ArrowRight,
  ShieldCheck,
  Store,
  UtensilsCrossed,
  User,
  Phone,
  MapPin,
  Building2,
  CheckCircle2,
  Info,
} from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (user: UserAccount) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');

  // Sign In form fields
  const [identifier, setIdentifier] = useState('retail@udaan.in');
  const [password, setPassword] = useState('Udaan@Retail2026');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Sign Up form fields
  const [signupType, setSignupType] = useState<BusinessType>('retail');
  const [signupBusinessName, setSignupBusinessName] = useState('');
  const [signupOwnerName, setSignupOwnerName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupPhone, setSignupPhone] = useState('+91 ');
  const [signupCity, setSignupCity] = useState('Bengaluru');

  // Quick fill preset credentials for judges
  const handleAutofill = (type: 'retail' | 'restaurant') => {
    setMode('signin');
    if (type === 'retail') {
      setIdentifier('retail@udaan.in');
      setPassword('Udaan@Retail2026');
    } else {
      setIdentifier('restaurant@udaan.in');
      setPassword('Udaan@Resto2026');
    }
    setErrorMessage('');
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const trimmedId = identifier.trim().toLowerCase();
    if (!trimmedId) {
      setErrorMessage('Please enter your business email address.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your account password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const users = getStoredUsers();
      const matchedUser = users.find(
        (u) =>
          u.email.toLowerCase() === trimmedId &&
          u.password === password
      );

      if (matchedUser) {
        setIsLoading(false);
        if (rememberMe) {
          setStoredSession(matchedUser);
        }
        onLoginSuccess(matchedUser);
      } else {
        setIsLoading(false);
        setErrorMessage(
          'Incorrect email or password. Use the access credentials provided below.'
        );
      }
    }, 400);
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!signupBusinessName.trim() || !signupOwnerName.trim() || !signupEmail.trim() || !signupPassword.trim()) {
      setErrorMessage('Please fill in all required fields to create your business account.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(signupEmail.trim())) {
      setErrorMessage('Please provide a valid email format.');
      return;
    }

    if (signupPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    const users = getStoredUsers();
    if (users.some((u) => u.email.toLowerCase() === signupEmail.trim().toLowerCase())) {
      setErrorMessage('An account with this email already exists. Please sign in instead.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const newAccount = registerNewUser({
        email: signupEmail.trim().toLowerCase(),
        password: signupPassword,
        name: signupOwnerName.trim(),
        businessName: signupBusinessName.trim(),
        businessType: signupType,
        phone: signupPhone.trim(),
        city: signupCity.trim(),
      });

      setIsLoading(false);
      if (rememberMe) {
        setStoredSession(newAccount);
      }
      onLoginSuccess(newAccount);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-[#0A192F] flex flex-col justify-center px-4 sm:px-6 lg:px-8 py-10 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#112240] rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-[#FFB703]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10">
        
        {/* LEFT COLUMN: Brand identity, tagline & soaring visual */}
        <div className="lg:col-span-6 flex flex-col justify-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#112240] border border-[#F8F9FA]/10 text-xs text-[#64FFDA] w-fit mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-[#64FFDA]" />
            <span>Business Intelligence & Ledger Platform</span>
          </div>

          <Logo size={46} showWordmark={true} className="mb-6" />

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-[#F8F9FA] tracking-tight leading-[1.15] mb-4">
            Give Your Business <br />
            <span className="text-[#FFB703] italic">Freedom.</span>
          </h1>

          <p className="text-sm sm:text-base text-[#F8F9FA]/70 leading-relaxed max-w-lg mb-8">
            UDAAN empowers Kirana stores and Restaurant owners to make confident, profitable decisions with clear sales analytics, real-time stock control, and plain-language intelligence.
          </p>

          {/* Business Types preview cards */}
          <div className="grid grid-cols-2 gap-3 max-w-md">
            <div className="p-3.5 rounded-xl bg-[#112240]/60 border border-[#F8F9FA]/[0.08]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#FFB703] mb-1">
                <Store className="w-4 h-4" />
                <span>Retail Stores</span>
              </div>
              <p className="text-[11px] text-[#F8F9FA]/60 leading-relaxed">
                Stock alerts, fast billing analysis, supplier procurement, and margin tracking.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#112240]/60 border border-[#F8F9FA]/[0.08]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#64FFDA] mb-1">
                <UtensilsCrossed className="w-4 h-4" />
                <span>Restaurants</span>
              </div>
              <p className="text-[11px] text-[#F8F9FA]/60 leading-relaxed">
                Menu engineering, best sellers & slow movers, raw materials, wastage, and P&L.
              </p>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Clean Login & Signup Card */}
        <div className="lg:col-span-6">
          <div className="bg-[#112240] border border-[#F8F9FA]/[0.1] rounded-2xl p-6 sm:p-8 shadow-2xl relative">
            
            {/* Mode Switcher Tabs */}
            <div className="flex items-center p-1 bg-[#0A192F] rounded-xl border border-[#F8F9FA]/10 mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setErrorMessage('');
                }}
                className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                  mode === 'signin' ? 'bg-[#FFB703] text-[#0A192F] shadow-sm' : 'text-[#F8F9FA]/65 hover:text-[#F8F9FA]'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setErrorMessage('');
                }}
                className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                  mode === 'signup' ? 'bg-[#FFB703] text-[#0A192F] shadow-sm' : 'text-[#F8F9FA]/65 hover:text-[#F8F9FA]'
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Error Message banner */}
            {errorMessage && (
              <div
                role="alert"
                className="mb-5 p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 leading-relaxed flex items-start gap-2.5"
              >
                <Info className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* ----------------------------------------------------------------- */}
            {/* SIGN IN FORM                                                      */}
            {/* ----------------------------------------------------------------- */}
            {mode === 'signin' ? (
              <form onSubmit={handleSignIn} className="space-y-4">
                <div>
                  <label
                    htmlFor="signin-identifier"
                    className="block text-xs font-medium text-[#F8F9FA]/80 mb-1.5"
                  >
                    Business Email
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#F8F9FA]/40">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      id="signin-identifier"
                      type="email"
                      autoComplete="username"
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="retail@udaan.in or restaurant@udaan.in"
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-10 pr-4 py-2.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/30 focus:border-[#FFB703] focus:ring-1 focus:ring-[#FFB703] transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="signin-password"
                    className="block text-xs font-medium text-[#F8F9FA]/80 mb-1.5"
                  >
                    Password
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#F8F9FA]/40">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="signin-password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-10 pr-11 py-2.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/30 focus:border-[#FFB703] focus:ring-1 focus:ring-[#FFB703] transition-colors font-mono"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#F8F9FA]/50 hover:text-[#F8F9FA] transition-colors cursor-pointer"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center">
                  <input
                    id="signin-remember"
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-[#F8F9FA]/20 bg-[#0A192F] text-[#FFB703] focus:ring-[#FFB703] cursor-pointer"
                  />
                  <label
                    htmlFor="signin-remember"
                    className="ml-2 text-xs text-[#F8F9FA]/70 cursor-pointer select-none"
                  >
                    Keep me signed in on this device
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-70"
                >
                  {isLoading ? (
                    <span>Opening Business Profile...</span>
                  ) : (
                    <>
                      <span>Sign In to Dashboard</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            ) : (
              /* ----------------------------------------------------------------- */
              /* SIGN UP FORM (Retail vs Restaurant Two Independent Businesses)    */
              /* ----------------------------------------------------------------- */
              <form onSubmit={handleSignUp} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-[#F8F9FA]/80 mb-1.5">
                    Select Your Business Domain
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSignupType('retail')}
                      className={`p-2.5 rounded-lg border text-left flex items-center gap-2 transition-all cursor-pointer ${
                        signupType === 'retail'
                          ? 'bg-[#FFB703]/15 border-[#FFB703] text-[#FFB703]'
                          : 'bg-[#0A192F] border-[#F8F9FA]/15 text-[#F8F9FA]/65'
                      }`}
                    >
                      <Store className="w-4 h-4 shrink-0" />
                      <div>
                        <div className="font-semibold text-xs text-[#F8F9FA]">Retail Store</div>
                        <div className="text-[10px] text-[#F8F9FA]/50">Kirana, FMCG, Mart</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSignupType('restaurant')}
                      className={`p-2.5 rounded-lg border text-left flex items-center gap-2 transition-all cursor-pointer ${
                        signupType === 'restaurant'
                          ? 'bg-[#64FFDA]/15 border-[#64FFDA] text-[#64FFDA]'
                          : 'bg-[#0A192F] border-[#F8F9FA]/15 text-[#F8F9FA]/65'
                      }`}
                    >
                      <UtensilsCrossed className="w-4 h-4 shrink-0" />
                      <div>
                        <div className="font-semibold text-xs text-[#F8F9FA]">Restaurant</div>
                        <div className="text-[10px] text-[#F8F9FA]/50">Kitchen, Cafe, Food</div>
                      </div>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                      Business Name
                    </label>
                    <input
                      type="text"
                      value={signupBusinessName}
                      onChange={(e) => setSignupBusinessName(e.target.value)}
                      placeholder={signupType === 'retail' ? 'e.g. Kaveri Provision Mart' : 'e.g. Spice Route Biryani'}
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                      Owner / Manager Name
                    </label>
                    <input
                      type="text"
                      value={signupOwnerName}
                      onChange={(e) => setSignupOwnerName(e.target.value)}
                      placeholder="e.g. Ramesh Hegde"
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                    Business Email
                  </label>
                  <input
                    type="email"
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="owner@mybusiness.in"
                    className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                      Create Password
                    </label>
                    <input
                      type="password"
                      value={signupPassword}
                      onChange={(e) => setSignupPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none font-mono"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-[#F8F9FA]/70 mb-1">
                      City
                    </label>
                    <input
                      type="text"
                      value={signupCity}
                      onChange={(e) => setSignupCity(e.target.value)}
                      placeholder="Bengaluru"
                      className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-70 mt-2"
                >
                  {isLoading ? 'Creating Business Ledger...' : 'Create Account & Enter'}
                </button>
              </form>
            )}

            {/* Access Credentials Note for Judges */}
            <div className="mt-6 p-3.5 rounded-xl bg-[#0A192F] border border-[#FFB703]/25 text-xs">
              <div className="flex items-center justify-between text-[#FFB703] font-semibold mb-2">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#64FFDA]" />
                  <span>Access Credentials (Evaluators & Judges)</span>
                </span>
              </div>

              <div className="space-y-2 text-[11px] font-mono">
                {/* Retail Credential Box */}
                <div className="p-2.5 rounded-lg bg-[#112240] border border-[#F8F9FA]/[0.08] flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[#FFB703] font-sans font-semibold">Retail Store Profile</div>
                    <div className="text-[#F8F9FA]/80">retail@udaan.in</div>
                    <div className="text-[#F8F9FA]/50">Udaan@Retail2026</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleAutofill('retail')}
                    className="px-2.5 py-1 rounded bg-[#FFB703]/15 text-[#FFB703] hover:bg-[#FFB703]/30 font-sans font-medium text-[11px] transition-colors cursor-pointer"
                  >
                    Autofill
                  </button>
                </div>

                {/* Restaurant Credential Box */}
                <div className="p-2.5 rounded-lg bg-[#112240] border border-[#F8F9FA]/[0.08] flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[#64FFDA] font-sans font-semibold">Restaurant Profile</div>
                    <div className="text-[#F8F9FA]/80">restaurant@udaan.in</div>
                    <div className="text-[#F8F9FA]/50">Udaan@Resto2026</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleAutofill('restaurant')}
                    className="px-2.5 py-1 rounded bg-[#64FFDA]/15 text-[#64FFDA] hover:bg-[#64FFDA]/30 font-sans font-medium text-[11px] transition-colors cursor-pointer"
                  >
                    Autofill
                  </button>
                </div>
              </div>

              <div className="text-[10px] text-[#F8F9FA]/45 mt-2.5">
                Each profile operates an independent business ledger with specialized metrics.
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
