import React, { useState } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { ChartCard } from '../components/ChartCard';
import { MetricCard } from '../components/MetricCard';
import {
  MaterialPurchase,
  RestaurantExpense,
  PeakHourSlot,
  CustomerReview,
  RESTAURANT_PURCHASES,
  RESTAURANT_EXPENSES,
  RESTAURANT_PEAK_HOURS,
  RESTAURANT_REVIEWS,
  RESTAURANT_PROFILE,
} from '../data/restaurantData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  Receipt,
  DollarSign,
  TrendingUp,
  Clock,
  Star,
  MessageSquare,
  Truck,
  Building2,
  Users,
  Flame,
  Package,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

interface RestaurantPurchasesExpensesProps {
  purchases?: MaterialPurchase[];
  expenses?: RestaurantExpense[];
  peakHours?: PeakHourSlot[];
  reviews?: CustomerReview[];
}

export const RestaurantPurchasesExpenses: React.FC<RestaurantPurchasesExpensesProps> = ({
  purchases = RESTAURANT_PURCHASES,
  expenses = RESTAURANT_EXPENSES,
  peakHours = RESTAURANT_PEAK_HOURS,
  reviews = RESTAURANT_REVIEWS,
}) => {
  const [activeTab, setActiveTab] = useState<'purchases' | 'expenses' | 'pnl' | 'peakhours' | 'feedback'>('pnl');

  // P&L Metrics
  const grossRevenue = RESTAURANT_PROFILE.monthSales; // ₹9,48,600
  const rawMaterialProcurement = 340000; // ~₹3.40L (food cost ~35.8%)
  const fixedOperatingExpenses = expenses.reduce((acc, e) => acc + e.amount, 0); // ₹2,28,640
  const totalCost = rawMaterialProcurement + fixedOperatingExpenses;
  const netProfit = grossRevenue - totalCost; // ₹3,79,960
  const netProfitMargin = Math.round((netProfit / grossRevenue) * 100);

  // Expense categories breakdown for chart
  const expenseChartData = expenses.map((e) => ({
    name: e.category,
    amount: e.amount,
  }));

  const EXPENSE_COLORS = ['#FFB703', '#64FFDA', '#38BDF8', '#F87171', '#A78BFA', '#FBBF24'];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Procurement, P&L & Kitchen Operations
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Raw material purchases, operating expenses, peak-hour traffic, and customer sentiment.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center flex-wrap gap-1 p-1 bg-[#112240] rounded-xl border border-[#F8F9FA]/10">
          {[
            { id: 'pnl', label: 'P&L Summary' },
            { id: 'purchases', label: 'Purchases Log' },
            { id: 'expenses', label: 'Expenses' },
            { id: 'peakhours', label: 'Peak Hours' },
            { id: 'feedback', label: 'Customer Reviews' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#FFB703] text-[#0A192F] font-semibold shadow-sm'
                  : 'text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: P&L SUMMARY */}
      {activeTab === 'pnl' && (
        <div className="space-y-6">
          {/* Top KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard
              title="Gross Monthly Revenue"
              value={formatCurrency(grossRevenue)}
              icon={TrendingUp}
              trendText="+14.2% vs Sept"
              trendDirection="up"
              subtext="2,480 dining & delivery covers"
              accent="gold"
            />
            <MetricCard
              title="Total Operating Cost"
              value={formatCurrency(totalCost)}
              icon={Receipt}
              trendText="COGS + Overheads"
              trendDirection="neutral"
              subtext="Raw materials, rent, salaries"
              accent="default"
            />
            <MetricCard
              title="Net Operating Profit"
              value={formatCurrency(netProfit)}
              icon={DollarSign}
              trendText={`+${netProfitMargin}% net profit margin`}
              trendDirection="up"
              subtext="After all monthly obligations"
              accent="mint"
            />
            <MetricCard
              title="Food Cost Ratio"
              value="35.8%"
              icon={Flame}
              trendText="Industry benchmark: 32-38%"
              trendDirection="up"
              subtext="Within optimal restaurant range"
              accent="gold"
            />
          </div>

          {/* P&L Statement Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Detailed Statement Table */}
            <div className="lg:col-span-7">
              <Card className="p-5">
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#F8F9FA]/[0.08]">
                  <h3 className="text-base font-semibold text-[#F8F9FA]">
                    October 2026 Profit & Loss Statement
                  </h3>
                  <Badge variant="mint" size="sm">
                    Audited Ledger
                  </Badge>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between items-center py-2 border-b border-[#F8F9FA]/[0.04]">
                    <span className="font-semibold text-[#F8F9FA]">Gross Sales Revenue</span>
                    <span className="font-mono font-bold text-[#FFB703] tabular-nums text-sm">
                      {formatCurrency(grossRevenue)}
                    </span>
                  </div>

                  <div className="pl-3 space-y-1.5 text-[#F8F9FA]/70">
                    <div className="flex justify-between">
                      <span>• Dine-in Sales (62% covers)</span>
                      <span className="font-mono text-[#F8F9FA]/90">₹5,88,100</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Delivery & Takeaway Sales (38% covers)</span>
                      <span className="font-mono text-[#F8F9FA]/90">₹3,60,500</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-[#F8F9FA]/[0.04] text-red-300 font-semibold">
                    <span>Less: Cost of Goods Sold (Raw Materials & Spices)</span>
                    <span className="font-mono tabular-nums">-{formatCurrency(rawMaterialProcurement)}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 bg-[#0A192F] p-2.5 rounded-lg border border-[#64FFDA]/30 font-semibold text-[#64FFDA]">
                    <span>Gross Operating Margin (64.2%)</span>
                    <span className="font-mono tabular-nums text-sm">
                      {formatCurrency(grossRevenue - rawMaterialProcurement)}
                    </span>
                  </div>

                  <div className="pt-2 text-[11px] font-semibold text-[#F8F9FA]/80 uppercase tracking-wider">
                    Operating Overheads & Fixed Expenses
                  </div>

                  <div className="pl-3 space-y-1.5 text-[#F8F9FA]/70">
                    <div className="flex justify-between">
                      <span>• Staff Salaries & Kitchen Payroll</span>
                      <span className="font-mono text-red-400">-₹1,10,000</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Commercial Restaurant Rent (Indiranagar)</span>
                      <span className="font-mono text-red-400">-₹65,000</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Fuel (LPG Cylinders) & High-load Electricity</span>
                      <span className="font-mono text-red-400">-₹28,940</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Food Packaging, Cutlery & Disposables</span>
                      <span className="font-mono text-red-400">-₹14,200</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• Maintenance & Deep Cleaning</span>
                      <span className="font-mono text-red-400">-₹4,500</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-[#112240] rounded-xl border border-[#FFB703] font-bold text-base mt-4">
                    <span className="text-[#F8F9FA]">Net Restaurant Profit</span>
                    <span className="font-mono text-[#FFB703] tabular-nums">
                      {formatCurrency(netProfit)}
                    </span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Expenses Breakdown Bar Chart */}
            <div className="lg:col-span-5">
              <ChartCard
                title="Fixed Overhead Breakdown"
                subtitle="Excluding raw materials (Total: ₹2,22,640/month)"
                footerNote="Payroll and prime location rent comprise 78% of fixed costs."
              >
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={expenseChartData} layout="vertical" margin={{ top: 5, right: 10, left: 20, bottom: 5 }}>
                    <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" horizontal={false} />
                    <XAxis type="number" stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                    <YAxis dataKey="name" type="category" stroke="rgba(248, 249, 250, 0.7)" fontSize={10} tickLine={false} width={100} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                      formatter={(val: any) => [formatCurrency(val), 'Monthly Cost']}
                    />
                    <Bar dataKey="amount" radius={[0, 4, 4, 0]}>
                      {expenseChartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={EXPENSE_COLORS[index % EXPENSE_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </ChartCard>
            </div>

          </div>
        </div>
      )}

      {/* TAB 2: PURCHASES LOG */}
      {activeTab === 'purchases' && (
        <Card className="p-0 overflow-hidden">
          <div className="p-4 border-b border-[#F8F9FA]/[0.08] flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-[#F8F9FA]">
                Raw Material Procurement & Invoices
              </h3>
              <p className="text-xs text-[#F8F9FA]/60 mt-0.5">
                Verified delivery receipts from poultry, dairy, produce, and gas vendors.
              </p>
            </div>
            <Badge variant="mint" size="sm">
              {purchases.length} Recent Invoices
            </Badge>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead>
                <tr className="bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">Invoice # & Date</th>
                  <th className="py-3 px-4">Raw Material</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4 text-right">Quantity</th>
                  <th className="py-3 px-4 text-right">Rate</th>
                  <th className="py-3 px-4 text-right">Total Billed</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                {purchases.map((po) => (
                  <tr key={po.id} className="hover:bg-[#F8F9FA]/[0.02]">
                    <td className="py-3 px-4">
                      <div className="font-mono text-[#F8F9FA] font-medium">{po.invoiceNo}</div>
                      <div className="text-[10px] text-[#F8F9FA]/40">{po.date}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-[#F8F9FA]">{po.materialName}</td>
                    <td className="py-3 px-4 text-[#F8F9FA]/70">{po.supplier}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#64FFDA]">
                      {po.quantity} {po.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]/80">
                      ₹{po.unitPrice}/{po.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#FFB703] font-bold">
                      {formatCurrency(po.totalAmount)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Badge variant={po.paymentStatus === 'Paid' ? 'success' : 'pending'} size="sm">
                        {po.paymentStatus}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* TAB 3: EXPENSES LIST */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {expenses.map((exp) => (
              <Card key={exp.id} className="p-4 hover:border-[#FFB703]/30 transition-all">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#FFB703]">
                    {exp.category}
                  </span>
                  <Badge variant="neutral" size="sm">
                    {exp.frequency}
                  </Badge>
                </div>
                <h4 className="text-sm font-semibold text-[#F8F9FA] mb-1">{exp.description}</h4>
                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-xs">
                  <span className="text-[#F8F9FA]/50">Bill Date: {exp.date}</span>
                  <span className="font-mono font-bold text-[#FFB703] tabular-nums text-sm">
                    {formatCurrency(exp.amount)}
                  </span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PEAK HOURS */}
      {activeTab === 'peakhours' && (
        <div className="space-y-6">
          <ChartCard
            title="Dining & Delivery Peak-Hour Volume"
            subtitle="Hourly traffic distribution: Prime Lunch (13:30 - 15:30) and Prime Dinner (20:30 - 22:30)"
            footerNote="Prepare batch prep for Dum Biryani and Gravies 45 minutes prior to peak surges."
          >
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={peakHours} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
                <XAxis dataKey="timeSlot" stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} />
                <YAxis stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                  formatter={(val: any, name: any) => [
                    name === 'avgRevenue' ? formatCurrency(val) : `${val} covers`,
                    name === 'avgRevenue' ? 'Avg Slot Revenue' : 'Avg Orders',
                  ]}
                />
                <Bar dataKey="avgRevenue" name="avgRevenue" fill="#FFB703" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {peakHours.map((slot) => (
              <Card key={slot.timeSlot} className="p-4">
                <div className="flex items-center justify-between text-xs text-[#FFB703] font-semibold mb-1">
                  <span>{slot.label}</span>
                  <span>{slot.timeSlot}</span>
                </div>
                <div className="text-xl font-bold font-display text-[#F8F9FA] my-1">
                  {formatCurrency(slot.avgRevenue)}
                </div>
                <div className="flex items-center justify-between text-xs text-[#F8F9FA]/60 mt-2 pt-2 border-t border-[#F8F9FA]/[0.06]">
                  <span>{slot.avgCovers} average covers</span>
                  <span className="text-[#64FFDA] font-medium">{slot.occupancyPercent}% occupancy</span>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: CUSTOMER REVIEWS */}
      {activeTab === 'feedback' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Recent Guest Feedback & Dish Ratings
            </h3>
            <Badge variant="gold" size="sm">
              4.8 ★ Overall Rating
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reviews.map((rev) => (
              <Card key={rev.id} className="p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="font-semibold text-sm text-[#F8F9FA]">{rev.customerName}</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 text-[#FFB703] fill-[#FFB703]" />
                      ))}
                    </div>
                  </div>

                  <div className="text-xs text-[#FFB703] font-medium mb-2 flex items-center gap-2">
                    <span>Dish: {rev.dishMentioned}</span>
                    <span className="text-[#F8F9FA]/40">·</span>
                    <span className="text-[#F8F9FA]/60">{rev.type}</span>
                  </div>

                  <p className="text-xs text-[#F8F9FA]/75 leading-relaxed italic">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-[11px] text-[#F8F9FA]/40">
                  <span>{rev.date}</span>
                  <Badge variant={rev.sentiment === 'Positive' ? 'mint' : 'pending'} size="sm">
                    {rev.sentiment}
                  </Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
