import React, { useState, useRef } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { StoreProfile } from '../data/sampleData';
import {
  exportFullDatabaseJSON,
  importFullDatabaseJSON,
  resetFullDatabase,
  generateCSV,
  BusinessType,
  getRetailState,
  getRestaurantState,
} from '../data/db';
import { formatCurrency } from '../utils/formatCurrency';
import {
  Settings as SettingsIcon,
  Store,
  User,
  Phone,
  MapPin,
  FileText,
  IndianRupee,
  Bell,
  Save,
  Download,
  Upload,
  RotateCcw,
  Database,
  CheckCircle,
  AlertTriangle,
  Table,
} from 'lucide-react';

interface SettingsProps {
  businessType?: BusinessType;
  profile: StoreProfile;
  onUpdateProfile: (updated: StoreProfile) => void;
  onReloadDatabase: () => void;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

export const Settings: React.FC<SettingsProps> = ({
  businessType = 'retail',
  profile,
  onUpdateProfile,
  onReloadDatabase,
  onShowToast,
}) => {
  const [formData, setFormData] = useState<StoreProfile>(profile);
  const [isSaving, setIsSaving] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    setTimeout(() => {
      setIsSaving(false);
      onUpdateProfile(formData);
      onShowToast('Store profile & preferences saved.', 'success', 'Settings Updated');
    }, 400);
  };

  // Export full JSON database
  const handleDownloadDatabaseJSON = () => {
    const jsonStr = exportFullDatabaseJSON();
    const todayStr = new Date().toISOString().split('T')[0];
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `udaan-database-${todayStr}.json`;
    link.click();
    URL.revokeObjectURL(url);
    onShowToast('Full database exported successfully.', 'success', 'Backup Generated');
  };

  // Import JSON database from file
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const success = importFullDatabaseJSON(content);
        if (success) {
          onReloadDatabase();
          onShowToast('Database imported and synchronized successfully.', 'success', 'Restore Complete');
        } else {
          onShowToast('Could not import database: Invalid format.', 'warning');
        }
      } catch (err) {
        onShowToast('Error reading backup file.', 'warning');
      }
    };
    reader.readAsText(file);
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Export Table CSV
  const handleExportTableCSV = (tableName: 'products' | 'sales' | 'restock' | 'suppliers' | 'expenses') => {
    let headers: string[] = [];
    let rows: (string | number)[][] = [];

    if (tableName === 'products') {
      if (businessType === 'restaurant') {
        const state = getRestaurantState();
        headers = ['ID', 'Dish Name', 'Category', 'Price (INR)', 'Food Cost (INR)', 'Units Sold', 'Revenue (INR)', 'Rating'];
        rows = state.dishes.map((d) => [d.id, d.name, d.category, d.price, d.costPrice, d.unitsSoldMonth, d.revenueMonth, d.rating]);
      } else {
        const state = getRetailState();
        headers = ['ID', 'SKU', 'Product Name', 'Category', 'Price', 'Cost', 'Stock Qty', 'Units Sold', 'Revenue (INR)'];
        rows = state.products.map((p) => [p.id, p.sku, p.name, p.category, p.price, p.costPrice, p.stockQuantity, p.unitsSoldMonth, p.revenueMonth]);
      }
    } else if (tableName === 'sales') {
      if (businessType === 'restaurant') {
        const state = getRestaurantState();
        headers = ['Date', 'Full Date', 'Sales (INR)', 'Covers', 'Dine-In', 'Delivery', 'Top Dish', 'Wastage (INR)'];
        rows = state.sales.map((s) => [s.date, s.fullDate, s.sales, s.covers, s.dineInOrders, s.deliveryOrders, s.topDish, s.wastageAmount]);
      } else {
        const state = getRetailState();
        headers = ['Date', 'Full Date', 'Sales (INR)', 'Orders Count'];
        rows = state.sales.map((s) => [s.date, s.fullDate, s.sales, s.orders]);
      }
    } else if (tableName === 'restock') {
      const state = businessType === 'restaurant' ? getRestaurantState() : getRetailState();
      headers = ['Receipt No', 'Date', 'Staff Name', 'Supplier', 'Items Count', 'Total Bill', 'Paid', 'Balance Due', 'Payment Mode'];
      rows = state.restockHistory.map((r) => [r.receiptNumber, r.date, r.staffName, r.supplierName, r.items.length, r.totalBill, r.amountPaid, r.balanceDue, r.paymentMode]);
    } else if (tableName === 'suppliers') {
      const state = businessType === 'restaurant' ? getRestaurantState() : getRetailState();
      headers = ['Name', 'Contact Person', 'Phone', 'City', 'Products Supplied', 'Last Delivery', 'Next ETA', 'Status'];
      rows = state.suppliers.map((s) => [s.name, s.contactPerson, s.phone, s.city, s.productsSupplied, s.lastDeliveryDate, s.nextDeliveryDate, s.status]);
    } else if (tableName === 'expenses') {
      const state = getRestaurantState();
      headers = ['Category', 'Description', 'Amount (INR)', 'Date', 'Frequency'];
      rows = state.expenses.map((e) => [e.category, e.description, e.amount, e.date, e.frequency]);
    }

    const csvStr = generateCSV(headers, rows);
    const blob = new Blob([csvStr], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `udaan-${tableName}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    onShowToast(`Exported ${tableName} to CSV.`, 'success');
  };

  // Reset database confirmation
  const handleConfirmReset = () => {
    resetFullDatabase();
    setShowResetConfirm(false);
    onReloadDatabase();
    onShowToast('Database reset to clean verified store records.', 'info', 'Reset Completed');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Business Settings & Data Backup
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Configure your enterprise identity, alert thresholds, and export/import persistent records.
          </p>
        </div>

        <Badge variant="mint" size="md">
          Persistent Storage Active
        </Badge>
      </div>

      {/* ========================================================================= */}
      {/* 8. DATA & BACKUP SECTION                                                  */}
      {/* ========================================================================= */}
      <Card className="p-6 border-[#FFB703]/30 shadow-xl">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-[#F8F9FA]/[0.08]">
          <Database className="w-5 h-5 text-[#FFB703]" />
          <div>
            <h3 className="text-base font-bold text-[#F8F9FA]">
              Data Backup, Export & Restore
            </h3>
            <p className="text-xs text-[#F8F9FA]/60">
              Manage your local browser database, generate JSON backups, or download table-level CSV exports.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Download JSON Button */}
          <div className="p-4 rounded-xl bg-[#0A192F] border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-[#FFB703] mb-1">
                Full Database (JSON)
              </div>
              <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed mb-3">
                Exports all sales, inventory, restock receipts, recipes, and expenses into a single portable backup file.
              </p>
            </div>
            <button
              onClick={handleDownloadDatabaseJSON}
              className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs transition-colors shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download JSON Backup</span>
            </button>
          </div>

          {/* Import JSON Button */}
          <div className="p-4 rounded-xl bg-[#0A192F] border border-[#F8F9FA]/[0.08] flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-[#64FFDA] mb-1">
                Restore from Backup
              </div>
              <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed mb-3">
                Upload a previously exported JSON database to restore your exact historical ledger.
              </p>
            </div>
            <div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".json"
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-[#112240] border border-[#64FFDA]/40 text-[#64FFDA] hover:bg-[#64FFDA]/10 font-semibold text-xs transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import JSON File</span>
              </button>
            </div>
          </div>

          {/* Reset Database */}
          <div className="p-4 rounded-xl bg-[#0A192F] border border-red-500/20 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-red-300 mb-1">
                Reset All Records
              </div>
              <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed mb-3">
                Clears all custom additions and resets the local database back to default verified figures.
              </p>
            </div>
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300 font-semibold text-xs transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Database</span>
            </button>
          </div>
        </div>

        {/* CSV Export Table Buttons */}
        <div>
          <div className="text-xs font-semibold text-[#F8F9FA]/80 mb-2.5 flex items-center gap-1.5">
            <Table className="w-3.5 h-3.5 text-[#FFB703]" />
            <span>Export Individual Table to CSV (Excel Compatible):</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => handleExportTableCSV('products')}
              className="px-3 py-1.5 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/10 hover:border-[#FFB703]/50 text-xs text-[#F8F9FA]/80 transition-colors cursor-pointer"
            >
              {businessType === 'restaurant' ? 'Dishes & Recipes CSV' : 'Products & SKUs CSV'}
            </button>
            <button
              onClick={() => handleExportTableCSV('sales')}
              className="px-3 py-1.5 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/10 hover:border-[#FFB703]/50 text-xs text-[#F8F9FA]/80 transition-colors cursor-pointer"
            >
              Daily Sales Records CSV
            </button>
            <button
              onClick={() => handleExportTableCSV('restock')}
              className="px-3 py-1.5 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/10 hover:border-[#FFB703]/50 text-xs text-[#F8F9FA]/80 transition-colors cursor-pointer"
            >
              Restock History & Receipts CSV
            </button>
            <button
              onClick={() => handleExportTableCSV('suppliers')}
              className="px-3 py-1.5 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/10 hover:border-[#FFB703]/50 text-xs text-[#F8F9FA]/80 transition-colors cursor-pointer"
            >
              Suppliers Directory CSV
            </button>
            {businessType === 'restaurant' && (
              <button
                onClick={() => handleExportTableCSV('expenses')}
                className="px-3 py-1.5 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/10 hover:border-[#FFB703]/50 text-xs text-[#F8F9FA]/80 transition-colors cursor-pointer"
              >
                Monthly Operating Expenses CSV
              </button>
            )}
          </div>
        </div>
      </Card>

      {/* Profile Configuration Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Business Profile Details */}
        <Card className="p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
            <Store className="w-5 h-5 text-[#FFB703]" />
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Business Identity
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Business Name
              </label>
              <div className="relative">
                <Store className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Owner / Manager Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.ownerName}
                  onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Contact Phone
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Location City & State
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={`${formData.city}, ${formData.state}`}
                  onChange={(e) => {
                    const parts = e.target.value.split(',');
                    setFormData({
                      ...formData,
                      city: parts[0]?.trim() || '',
                      state: parts[1]?.trim() || 'Karnataka',
                    });
                  }}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                GSTIN / Trade Registration Number
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  placeholder="29AAAAA0000A1Z5"
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Low-Stock Safety Margin */}
        <Card className="p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
            <IndianRupee className="w-5 h-5 text-[#64FFDA]" />
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Inventory Safety Buffers
            </h3>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-[#F8F9FA]/70">
                Low Stock Threshold Buffer
              </label>
              <span className="text-xs font-mono font-bold text-[#FFB703]">
                {formData.lowStockThresholdPercent}% margin
              </span>
            </div>
            <input
              type="range"
              min="10"
              max="50"
              step="5"
              value={formData.lowStockThresholdPercent}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  lowStockThresholdPercent: parseInt(e.target.value),
                })
              }
              className="w-full accent-[#FFB703] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#F8F9FA]/40 mt-1">
              <span>10% (Tight)</span>
              <span>20% (Recommended)</span>
              <span>50% (High Safety Buffer)</span>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <span>Saving...</span>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save Store Preferences</span>
              </>
            )}
          </button>
        </div>

      </form>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div
          className="fixed inset-0 z-50 bg-[#0A192F]/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#112240] border border-red-500/40 rounded-xl p-6 max-w-md w-full shadow-2xl relative text-[#F8F9FA]">
            <div className="w-10 h-10 rounded-lg bg-red-500/15 text-red-400 flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold font-display text-[#F8F9FA] mb-2">
              Confirm Database Reset
            </h3>
            <p className="text-xs text-[#F8F9FA]/70 leading-relaxed mb-5">
              This will restore all sales, inventory items, recipes, suppliers, and restock records back to original verified state. Any newly logged items will be cleared.
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs text-[#F8F9FA]/70 hover:text-[#F8F9FA] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-semibold text-xs transition-colors shadow-md cursor-pointer"
              >
                Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
