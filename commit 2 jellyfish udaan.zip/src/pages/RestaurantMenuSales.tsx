import React, { useState, useMemo } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { ChartCard } from '../components/ChartCard';
import { Dish, RESTAURANT_DISHES } from '../data/restaurantData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  Utensils,
  Search,
  Filter,
  TrendingUp,
  AlertCircle,
  Clock,
  Star,
  Award,
  ArrowUpDown,
  Sparkles,
  Layers,
  IndianRupee,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  Cell,
} from 'recharts';

interface RestaurantMenuSalesProps {
  dishes?: Dish[];
}

export const RestaurantMenuSales: React.FC<RestaurantMenuSalesProps> = ({ dishes = RESTAURANT_DISHES }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewFilter, setViewFilter] = useState<'all' | 'best-sellers' | 'slow-movers'>('all');
  const [sortField, setSortField] = useState<'revenueMonth' | 'unitsSoldMonth' | 'margin' | 'rating'>('revenueMonth');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Categories list
  const categories = useMemo(() => {
    const cats = new Set(dishes.map((d) => d.category));
    return ['all', ...Array.from(cats)];
  }, [dishes]);

  // Best sellers (units sold > 300) and slow movers (units sold < 50)
  const bestSellers = useMemo(() => {
    return [...dishes].filter((d) => d.isBestSeller || d.unitsSoldMonth >= 350).sort((a, b) => b.unitsSoldMonth - a.unitsSoldMonth);
  }, [dishes]);

  const slowMovers = useMemo(() => {
    return [...dishes].filter((d) => d.isSlowMover || d.unitsSoldMonth <= 50).sort((a, b) => a.unitsSoldMonth - b.unitsSoldMonth);
  }, [dishes]);

  // Chart comparison data (Top 5 Best vs Bottom 5 Slow Movers)
  const comparativeChartData = useMemo(() => {
    const top = bestSellers.slice(0, 5).map((d) => ({
      name: d.name.length > 18 ? d.name.slice(0, 16) + '...' : d.name,
      fullName: d.name,
      units: d.unitsSoldMonth,
      revenue: d.revenueMonth,
      type: 'Best Seller',
    }));

    const bottom = slowMovers.slice(0, 5).map((d) => ({
      name: d.name.length > 18 ? d.name.slice(0, 16) + '...' : d.name,
      fullName: d.name,
      units: d.unitsSoldMonth,
      revenue: d.revenueMonth,
      type: 'Slow Mover',
    }));

    return { top, bottom };
  }, [bestSellers, slowMovers]);

  // Filtered dishes
  const filteredDishes = useMemo(() => {
    return dishes.filter((dish) => {
      const matchesCategory = selectedCategory === 'all' || dish.category === selectedCategory;
      const matchesSearch = dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dish.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesView =
        viewFilter === 'all' ||
        (viewFilter === 'best-sellers' && (dish.isBestSeller || dish.unitsSoldMonth >= 350)) ||
        (viewFilter === 'slow-movers' && (dish.isSlowMover || dish.unitsSoldMonth <= 50));

      return matchesCategory && matchesSearch && matchesView;
    }).sort((a, b) => {
      let valA: number;
      let valB: number;

      if (sortField === 'margin') {
        valA = ((a.price - a.costPrice) / a.price) * 100;
        valB = ((b.price - b.costPrice) / b.price) * 100;
      } else {
        valA = a[sortField];
        valB = b[sortField];
      }

      return sortOrder === 'asc' ? valA - valB : valB - valA;
    });
  }, [dishes, selectedCategory, searchQuery, viewFilter, sortField, sortOrder]);

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const totalRevenue = dishes.reduce((acc, d) => acc + d.revenueMonth, 0);
  const totalUnits = dishes.reduce((acc, d) => acc + d.unitsSoldMonth, 0);
  const avgMargin = Math.round(
    dishes.reduce((acc, d) => acc + ((d.price - d.costPrice) / d.price) * 100, 0) / dishes.length
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Menu Engineering & Dish Sales
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Analyze customer preferences, dish margins, high-volume drivers, and slow-moving items.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="mint" size="md">
            {dishes.length} Active Recipes
          </Badge>
          <Badge variant="gold" size="md">
            {avgMargin}% Average Margin
          </Badge>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4 border-l-4 border-l-[#FFB703]">
          <div className="text-xs text-[#F8F9FA]/60">Total Food Revenue (30D)</div>
          <div className="text-xl sm:text-2xl font-bold font-display text-[#FFB703] mt-1 tabular-nums">
            {formatCurrency(totalRevenue)}
          </div>
          <div className="text-[11px] text-[#64FFDA] mt-1 font-medium">Across 26 recipe cards</div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#64FFDA]">
          <div className="text-xs text-[#F8F9FA]/60">Dishes Served (Units)</div>
          <div className="text-xl sm:text-2xl font-bold font-display text-[#64FFDA] mt-1 tabular-nums">
            {formatIndianNumber(totalUnits)} plates
          </div>
          <div className="text-[11px] text-[#F8F9FA]/50 mt-1">Dine-in and Delivery</div>
        </Card>

        <Card className="p-4 border-l-4 border-l-[#FFB703]">
          <div className="text-xs text-[#F8F9FA]/60">Top Performing Dish</div>
          <div className="text-sm sm:text-base font-bold text-[#F8F9FA] mt-1 truncate">
            {bestSellers[0]?.name || 'Hyderabadi Dum Biryani'}
          </div>
          <div className="text-[11px] text-[#FFB703] mt-1 font-mono">
            {bestSellers[0]?.unitsSoldMonth} orders (₹{bestSellers[0]?.revenueMonth?.toLocaleString('en-IN')})
          </div>
        </Card>

        <Card className="p-4 border-l-4 border-l-red-400">
          <div className="text-xs text-[#F8F9FA]/60">Slow Moving Items</div>
          <div className="text-xl sm:text-2xl font-bold font-display text-red-300 mt-1 tabular-nums">
            {slowMovers.length} Recipes
          </div>
          <div className="text-[11px] text-[#F8F9FA]/50 mt-1">Under 50 orders/month</div>
        </Card>
      </div>

      {/* BEST SELLERS VS SLOW MOVERS VISUAL CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Top 5 Best Sellers Chart */}
        <div className="lg:col-span-6">
          <ChartCard
            title="Top 5 Best Sellers (High Volume)"
            subtitle="The backbone of kitchen revenue and daily guest dining"
            footerNote="Chicken Biryani and Butter Chicken lead monthly turnover."
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={comparativeChartData.top} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" horizontal={false} />
                <XAxis type="number" stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} />
                <YAxis dataKey="name" type="category" stroke="rgba(248, 249, 250, 0.7)" fontSize={11} tickLine={false} width={110} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                  formatter={(val: any, name: any) => [
                    name === 'units' ? `${val} plates` : formatCurrency(val),
                    name === 'units' ? 'Units Sold' : 'Revenue',
                  ]}
                />
                <Bar dataKey="units" name="units" fill="#FFB703" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Slow Movers / Low Demand Chart */}
        <div className="lg:col-span-6">
          <ChartCard
            title="Slow Movers / Low Volume (<50 Plates)"
            subtitle="Candidate recipes for menu revision, combo pairing, or phase-out"
            footerNote="Low sales can tie up perishables like fresh mushrooms and saffron."
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={comparativeChartData.bottom} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" horizontal={false} />
                <XAxis type="number" stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} />
                <YAxis dataKey="name" type="category" stroke="rgba(248, 249, 250, 0.7)" fontSize={11} tickLine={false} width={110} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#112240', borderColor: '#F87171', borderRadius: 8 }}
                  formatter={(val: any, name: any) => [
                    name === 'units' ? `${val} plates` : formatCurrency(val),
                    name === 'units' ? 'Units Sold' : 'Revenue',
                  ]}
                />
                <Bar dataKey="units" name="units" fill="#F87171" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

      </div>

      {/* FILTER & SEARCH BAR */}
      <Card className="p-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dish by name or category (e.g., Biryani, Tikka, Naan)..."
              className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* View Filter Toggle */}
            <div className="flex items-center gap-1 bg-[#0A192F] p-1 rounded-lg border border-[#F8F9FA]/10">
              <button
                onClick={() => setViewFilter('all')}
                className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                  viewFilter === 'all' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                }`}
              >
                All Menu
              </button>
              <button
                onClick={() => setViewFilter('best-sellers')}
                className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                  viewFilter === 'best-sellers' ? 'bg-[#FFB703] text-[#0A192F] font-semibold' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                }`}
              >
                Best Sellers ({bestSellers.length})
              </button>
              <button
                onClick={() => setViewFilter('slow-movers')}
                className={`px-2.5 py-1 text-xs rounded transition-colors cursor-pointer ${
                  viewFilter === 'slow-movers' ? 'bg-red-500/20 text-red-300 font-semibold border border-red-500/40' : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                }`}
              >
                Slow Movers ({slowMovers.length})
              </button>
            </div>

            {/* Category Dropdown */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none cursor-pointer"
            >
              {categories.map((c) => (
                <option key={c} value={c} className="bg-[#112240]">
                  {c === 'all' ? 'All Categories' : c}
                </option>
              ))}
            </select>
          </div>

        </div>
      </Card>

      {/* FULL RECIPE / DISH SALES TABLE */}
      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead>
              <tr className="bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Dish & Category</th>
                <th
                  onClick={() => toggleSort('revenueMonth')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Menu Price</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right">Food Cost</th>
                <th
                  onClick={() => toggleSort('margin')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Gross Margin %</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => toggleSort('unitsSoldMonth')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Plates Sold</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => toggleSort('revenueMonth')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Total Revenue</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Status Tag</th>
                <th
                  onClick={() => toggleSort('rating')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Rating</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
              {filteredDishes.map((dish) => {
                const marginPercent = Math.round(((dish.price - dish.costPrice) / dish.price) * 100);
                const isBest = dish.isBestSeller || dish.unitsSoldMonth >= 350;
                const isSlow = dish.isSlowMover || dish.unitsSoldMonth <= 50;

                return (
                  <tr
                    key={dish.id}
                    className={`hover:bg-[#F8F9FA]/[0.02] transition-colors ${
                      isSlow ? 'bg-red-500/[0.03]' : isBest ? 'bg-[#FFB703]/[0.02]' : ''
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-semibold text-[#F8F9FA] flex items-center gap-2">
                        <span>{dish.name}</span>
                        {isBest && <Award className="w-3.5 h-3.5 text-[#FFB703] shrink-0" />}
                      </div>
                      <div className="text-[11px] text-[#F8F9FA]/50">{dish.category} · {dish.prepTimeMinutes}m prep</div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]">
                      {formatCurrency(dish.price)}
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]/60">
                      {formatCurrency(dish.costPrice)}
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      <span className={`font-semibold ${marginPercent >= 60 ? 'text-[#64FFDA]' : 'text-[#FFB703]'}`}>
                        {marginPercent}%
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#64FFDA] font-semibold">
                      {dish.unitsSoldMonth} plates
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#FFB703] font-bold">
                      {formatCurrency(dish.revenueMonth)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      {isBest ? (
                        <Badge variant="gold" size="sm">
                          Best Seller
                        </Badge>
                      ) : isSlow ? (
                        <Badge variant="critical" size="sm">
                          Slow Mover
                        </Badge>
                      ) : (
                        <Badge variant="neutral" size="sm">
                          Steady
                        </Badge>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]">
                      <span className="inline-flex items-center gap-1">
                        <Star className="w-3 h-3 text-[#FFB703] fill-[#FFB703]" />
                        <span>{dish.rating}</span>
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-[#0A192F]/40 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-[11px] text-[#F8F9FA]/50">
          <span>Showing {filteredDishes.length} of {dishes.length} menu items</span>
          <span className="font-mono">Live kitchen order aggregation</span>
        </div>
      </Card>
    </div>
  );
};
