/**
 * UDAAN Local Database & Persistence Engine
 * Supports multiple business profiles (Retail Kirana & Restaurant Enterprise)
 * Persists data to localStorage with automatic initialization and export/import.
 */

import {
  SAMPLE_PRODUCTS,
  DAILY_SALES_30D,
  RECENT_TRANSACTIONS,
  SAMPLE_SUPPLIERS,
  Product,
  DailySalesRecord,
  Transaction,
  Supplier,
  StoreProfile,
} from './sampleData';

import {
  RESTAURANT_DISHES,
  RESTAURANT_RAW_MATERIALS,
  RESTAURANT_SALES_60D,
  RESTAURANT_PURCHASES,
  RESTAURANT_EXPENSES,
  RESTAURANT_PEAK_HOURS,
  RESTAURANT_REVIEWS,
  RESTAURANT_PROFILE,
  Dish,
  RawMaterial,
  MaterialPurchase,
  RestaurantExpense,
  RestaurantDailySales,
  CustomerReview,
  PeakHourSlot,
} from './restaurantData';

export type BusinessType = 'retail' | 'restaurant';

export interface UserAccount {
  id: string;
  email: string;
  password: string;
  name: string;
  businessName: string;
  businessType: BusinessType;
  phone: string;
  city: string;
  createdAt: string;
}

export interface RestockLineItem {
  id: string;
  itemName: string;
  quantity: number;
  unit: string;
  unitCost: number;
  lineTotal: number;
}

export interface RestockEntry {
  id: string;
  receiptNumber: string;
  date: string;
  time: string;
  businessType: BusinessType;
  businessName: string;
  staffName: string;
  supplierName: string;
  items: RestockLineItem[];
  totalBill: number;
  amountPaid: number;
  balanceDue: number;
  paymentMode: 'Cash' | 'Online';
  onlineMethod?: 'UPI' | 'Bank Transfer' | 'Card';
  transactionId?: string;
  notes?: string;
}

export interface RetailDatabaseState {
  profile: StoreProfile;
  products: Product[];
  sales: DailySalesRecord[];
  transactions: Transaction[];
  suppliers: Supplier[];
  restockHistory: RestockEntry[];
}

export interface RestaurantDatabaseState {
  profile: typeof RESTAURANT_PROFILE;
  dishes: Dish[];
  rawMaterials: RawMaterial[];
  sales: RestaurantDailySales[];
  purchases: MaterialPurchase[];
  expenses: RestaurantExpense[];
  suppliers: Supplier[];
  peakHours: PeakHourSlot[];
  reviews: CustomerReview[];
  restockHistory: RestockEntry[];
}

export interface FullDatabaseBackup {
  version: string;
  exportedAt: string;
  retail: RetailDatabaseState;
  restaurant: RestaurantDatabaseState;
  customAccounts: UserAccount[];
}

// STORAGE KEYS
const STORAGE_PREFIX = 'udaan_db_v2_';
const KEY_SESSION = `${STORAGE_PREFIX}session`;
const KEY_USERS = `${STORAGE_PREFIX}accounts`;
const KEY_RETAIL = `${STORAGE_PREFIX}retail_data`;
const KEY_RESTAURANT = `${STORAGE_PREFIX}restaurant_data`;

// INITIAL DEFAULT ACCOUNTS
export const DEFAULT_ACCOUNTS: UserAccount[] = [
  {
    id: 'acc-retail-01',
    email: 'retail@udaan.in',
    password: 'Udaan@Retail2026',
    name: 'Suresh Kumar',
    businessName: 'Lakshmi Retail Mart',
    businessType: 'retail',
    phone: '+91 98450 12345',
    city: 'Bengaluru',
    createdAt: '2026-01-15T09:00:00Z',
  },
  {
    id: 'acc-resto-02',
    email: 'restaurant@udaan.in',
    password: 'Udaan@Resto2026',
    name: 'Rajesh Shetty',
    businessName: 'Royal Spice Kitchen & Biryani House',
    businessType: 'restaurant',
    phone: '+91 98860 77123',
    city: 'Bengaluru',
    createdAt: '2026-02-01T10:30:00Z',
  },
];

// INITIAL RESTOCK HISTORY FOR RETAIL
const INITIAL_RETAIL_RESTOCK: RestockEntry[] = [
  {
    id: 'rst-ret-001',
    receiptNumber: 'REC-RET-2026-102',
    date: '2026-10-24',
    time: '10:30 AM',
    businessType: 'retail',
    businessName: 'Lakshmi Retail Mart',
    staffName: 'Ramesh (Store Manager)',
    supplierName: 'Sri Lakshmi Traders',
    items: [
      { id: 'item-1', itemName: 'Basmati Rice 5kg', quantity: 20, unit: 'bags', unitCost: 380, lineTotal: 7600 },
      { id: 'item-2', itemName: 'Parle-G Biscuits (pack)', quantity: 50, unit: 'packs', unitCost: 24, lineTotal: 1200 },
    ],
    totalBill: 8800,
    amountPaid: 8800,
    balanceDue: 0,
    paymentMode: 'Online',
    onlineMethod: 'UPI',
    transactionId: 'UPI/6298104421/ICICI',
    notes: 'Restocked before festive weekend demand.',
  },
  {
    id: 'rst-ret-002',
    receiptNumber: 'REC-RET-2026-098',
    date: '2026-10-18',
    time: '04:15 PM',
    businessType: 'retail',
    businessName: 'Lakshmi Retail Mart',
    staffName: 'Sunil (Inventory Assistant)',
    supplierName: 'Kaveri Dairy & Provisions',
    items: [
      { id: 'item-1', itemName: 'Amul Butter 500g', quantity: 15, unit: 'packs', unitCost: 240, lineTotal: 3600 },
      { id: 'item-2', itemName: 'Sunflower Oil 1L', quantity: 25, unit: 'pouches', unitCost: 115, lineTotal: 2875 },
    ],
    totalBill: 6475,
    amountPaid: 5000,
    balanceDue: 1475,
    paymentMode: 'Cash',
    notes: 'Partial payment settled in cash; remaining balance on invoice Net-15.',
  },
];

// INITIAL RESTOCK HISTORY FOR RESTAURANT
const INITIAL_RESTAURANT_RESTOCK: RestockEntry[] = [
  {
    id: 'rst-res-001',
    receiptNumber: 'REC-RST-2026-441',
    date: '2026-10-25',
    time: '08:15 AM',
    businessType: 'restaurant',
    businessName: 'Royal Spice Kitchen & Biryani House',
    staffName: 'Chef Vinod (Head Chef)',
    supplierName: 'Bengaluru Fresh Poultry Farms',
    items: [
      { id: 'item-1', itemName: 'Broiler Chicken (Dressed)', quantity: 40, unit: 'kg', unitCost: 180, lineTotal: 7200 },
      { id: 'item-2', itemName: 'Boneless Chicken Breast Fillets', quantity: 15, unit: 'kg', unitCost: 260, lineTotal: 3900 },
    ],
    totalBill: 11100,
    amountPaid: 11100,
    balanceDue: 0,
    paymentMode: 'Online',
    onlineMethod: 'UPI',
    transactionId: 'UPI/7029188410/HDFC',
    notes: 'Morning fresh poultry delivery verified for evening service.',
  },
  {
    id: 'rst-res-002',
    receiptNumber: 'REC-RST-2026-438',
    date: '2026-10-23',
    time: '11:00 AM',
    businessType: 'restaurant',
    businessName: 'Royal Spice Kitchen & Biryani House',
    staffName: 'Anita (Kitchen Supervisor)',
    supplierName: 'Cauvery Wholesale Vegetable Mandi',
    items: [
      { id: 'item-1', itemName: 'Nashik Red Onions', quantity: 80, unit: 'kg', unitCost: 34, lineTotal: 2720 },
      { id: 'item-2', itemName: 'Bangalore Farm Tomatoes', quantity: 50, unit: 'kg', unitCost: 28, lineTotal: 1400 },
      { id: 'item-3', itemName: 'Hot Green Chillies & Mint', quantity: 10, unit: 'kg', unitCost: 65, lineTotal: 650 },
    ],
    totalBill: 4770,
    amountPaid: 4770,
    balanceDue: 0,
    paymentMode: 'Cash',
    notes: 'Direct Mandi delivery received and weighed at service entrance.',
  },
  {
    id: 'rst-res-003',
    receiptNumber: 'REC-RST-2026-435',
    date: '2026-10-22',
    time: '03:45 PM',
    businessType: 'restaurant',
    businessName: 'Royal Spice Kitchen & Biryani House',
    staffName: 'Chef Vinod (Head Chef)',
    supplierName: 'Sri Lakshmi Agro & Grains',
    items: [
      { id: 'item-1', itemName: 'Daawat Rozana Basmati Rice', quantity: 100, unit: 'kg', unitCost: 92, lineTotal: 9200 },
    ],
    totalBill: 9200,
    amountPaid: 9200,
    balanceDue: 0,
    paymentMode: 'Online',
    onlineMethod: 'Bank Transfer',
    transactionId: 'NEFT/5548190223/SBI',
    notes: 'Rice restock for biryani bulk batches.',
  },
];

// INITIAL RETAIL RESTAURANT SUPPLIERS
const RESTAURANT_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-res-01',
    name: 'Bengaluru Fresh Poultry Farms',
    contactPerson: 'Kishore Reddy',
    phone: '+91 98451 88204',
    city: 'Bengaluru',
    productsSupplied: 'Broiler Chicken, Boneless Breast, Farm Eggs',
    lastDeliveryDate: '25 Oct 2026',
    nextDeliveryDate: '28 Oct 2026',
    status: 'Scheduled',
    rating: 4.9,
  },
  {
    id: 'sup-res-02',
    name: 'KMF Nandini Dairy Depot',
    contactPerson: 'Prabhakar Hegde',
    phone: '+91 94480 33190',
    city: 'Bengaluru',
    productsSupplied: 'Malai Paneer, Milk, Curd, Desi Cow Ghee',
    lastDeliveryDate: '25 Oct 2026',
    nextDeliveryDate: '27 Oct 2026',
    status: 'Scheduled',
    rating: 4.9,
  },
  {
    id: 'sup-res-03',
    name: 'Cauvery Wholesale Vegetable Mandi',
    contactPerson: 'Siddaraju M',
    phone: '+91 97410 44211',
    city: 'K.R. Market, Bengaluru',
    productsSupplied: 'Onions, Tomatoes, Potatoes, Ginger, Garlic, Fresh Herbs',
    lastDeliveryDate: '24 Oct 2026',
    nextDeliveryDate: '27 Oct 2026',
    status: 'In Transit',
    rating: 4.6,
  },
  {
    id: 'sup-res-04',
    name: 'Indane Commercial Gas Agency',
    contactPerson: 'Gopala Krishna',
    phone: '+91 93410 77650',
    city: 'Indiranagar, Bengaluru',
    productsSupplied: 'Commercial 19kg Blue LPG Gas Cylinders',
    lastDeliveryDate: '23 Oct 2026',
    nextDeliveryDate: '30 Oct 2026',
    status: 'Delivered',
    rating: 4.8,
  },
  {
    id: 'sup-res-05',
    name: 'EcoPack Solutions Bengaluru',
    contactPerson: 'Varun Somani',
    phone: '+91 99001 22845',
    city: 'Peenya, Bengaluru',
    productsSupplied: '750ml Handi Containers, Kraft Bags, Cutlery',
    lastDeliveryDate: '20 Oct 2026',
    nextDeliveryDate: '29 Oct 2026',
    status: 'Scheduled',
    rating: 4.7,
  },
  {
    id: 'sup-res-06',
    name: 'Metro Wholesale Traders',
    contactPerson: 'Sunil Chawla',
    phone: '+91 98800 11470',
    city: 'Yeshwanthpur, Bengaluru',
    productsSupplied: 'Fortune Sunflower Oil 15L Tins, Cashews, Dry Spices',
    lastDeliveryDate: '15 Oct 2026',
    nextDeliveryDate: '28 Oct 2026',
    status: 'In Transit',
    rating: 4.8,
  },
];

// Helper to safe parse JSON
function safeGet<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (err) {
    console.warn(`Error reading localStorage key "${key}":`, err);
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving localStorage key "${key}":`, err);
  }
}

// ------------------------------------------------------------------
// AUTHENTICATION & USERS
// ------------------------------------------------------------------
export const getStoredUsers = (): UserAccount[] => {
  const users = safeGet<UserAccount[]>(KEY_USERS, []);
  if (users.length === 0) {
    safeSet(KEY_USERS, DEFAULT_ACCOUNTS);
    return DEFAULT_ACCOUNTS;
  }
  return users;
};

export const registerNewUser = (account: Omit<UserAccount, 'id' | 'createdAt'>): UserAccount => {
  const users = getStoredUsers();
  const newAccount: UserAccount = {
    ...account,
    id: `acc-custom-${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
  users.push(newAccount);
  safeSet(KEY_USERS, users);
  return newAccount;
};

export const getStoredSession = (): UserAccount | null => {
  return safeGet<UserAccount | null>(KEY_SESSION, null);
};

export const setStoredSession = (user: UserAccount | null): void => {
  if (!user) {
    localStorage.removeItem(KEY_SESSION);
  } else {
    safeSet(KEY_SESSION, user);
  }
};

// ------------------------------------------------------------------
// RETAIL STORE DATABASE ACCESS
// ------------------------------------------------------------------
export const getRetailState = (): RetailDatabaseState => {
  const defaultState: RetailDatabaseState = {
    profile: {
      name: 'Lakshmi Retail Mart',
      ownerName: 'Suresh Kumar',
      email: 'retail@udaan.in',
      phone: '+91 98450 12345',
      city: 'Bengaluru',
      state: 'Karnataka',
      gstin: '29AAAAA0000A1Z5',
      currency: 'INR (₹)',
      lowStockThresholdPercent: 20,
      dailySummaryNotifications: true,
      smsAlerts: false,
    },
    products: SAMPLE_PRODUCTS,
    sales: DAILY_SALES_30D,
    transactions: RECENT_TRANSACTIONS,
    suppliers: SAMPLE_SUPPLIERS,
    restockHistory: INITIAL_RETAIL_RESTOCK,
  };

  const stored = safeGet<RetailDatabaseState | null>(KEY_RETAIL, null);
  if (!stored) {
    safeSet(KEY_RETAIL, defaultState);
    return defaultState;
  }
  return stored;
};

export const saveRetailState = (state: RetailDatabaseState): void => {
  safeSet(KEY_RETAIL, state);
};

export const addRetailRestockEntry = (entry: Omit<RestockEntry, 'id' | 'receiptNumber'>): RestockEntry => {
  const state = getRetailState();
  const nextNumber = state.restockHistory.length + 103;
  const newEntry: RestockEntry = {
    ...entry,
    id: `rst-ret-${Date.now()}`,
    receiptNumber: `REC-RET-2026-${nextNumber}`,
  };

  // Automatically update product stock in inventory
  const updatedProducts = state.products.map((prod) => {
    const matchingRestock = entry.items.find(
      (item) => item.itemName.toLowerCase() === prod.name.toLowerCase()
    );
    if (matchingRestock) {
      return {
        ...prod,
        stockQuantity: prod.stockQuantity + matchingRestock.quantity,
      };
    }
    return prod;
  });

  state.products = updatedProducts;
  state.restockHistory.unshift(newEntry);
  saveRetailState(state);
  return newEntry;
};

// ------------------------------------------------------------------
// RESTAURANT BUSINESS DATABASE ACCESS
// ------------------------------------------------------------------
export const getRestaurantState = (): RestaurantDatabaseState => {
  const defaultState: RestaurantDatabaseState = {
    profile: RESTAURANT_PROFILE,
    dishes: RESTAURANT_DISHES,
    rawMaterials: RESTAURANT_RAW_MATERIALS,
    sales: RESTAURANT_SALES_60D,
    purchases: RESTAURANT_PURCHASES,
    expenses: RESTAURANT_EXPENSES,
    suppliers: RESTAURANT_SUPPLIERS,
    peakHours: RESTAURANT_PEAK_HOURS,
    reviews: RESTAURANT_REVIEWS,
    restockHistory: INITIAL_RESTAURANT_RESTOCK,
  };

  const stored = safeGet<RestaurantDatabaseState | null>(KEY_RESTAURANT, null);
  if (!stored) {
    safeSet(KEY_RESTAURANT, defaultState);
    return defaultState;
  }
  return stored;
};

export const saveRestaurantState = (state: RestaurantDatabaseState): void => {
  safeSet(KEY_RESTAURANT, state);
};

export const addRestaurantRestockEntry = (entry: Omit<RestockEntry, 'id' | 'receiptNumber'>): RestockEntry => {
  const state = getRestaurantState();
  const nextNumber = state.restockHistory.length + 442;
  const newEntry: RestockEntry = {
    ...entry,
    id: `rst-res-${Date.now()}`,
    receiptNumber: `REC-RST-2026-${nextNumber}`,
  };

  // Automatically update raw material stock in restaurant inventory
  const updatedMaterials = state.rawMaterials.map((mat) => {
    const matchingRestock = entry.items.find(
      (item) => item.itemName.toLowerCase().trim() === mat.name.toLowerCase().trim()
    );
    if (matchingRestock) {
      return {
        ...mat,
        stockQuantity: mat.stockQuantity + matchingRestock.quantity,
        lastPurchaseDate: entry.date,
      };
    }
    return mat;
  });

  state.rawMaterials = updatedMaterials;
  state.restockHistory.unshift(newEntry);
  saveRestaurantState(state);
  return newEntry;
};

// ------------------------------------------------------------------
// DATABASE BACKUP, IMPORT, EXPORT & RESET
// ------------------------------------------------------------------
export const exportFullDatabaseJSON = (): string => {
  const backup: FullDatabaseBackup = {
    version: '2.0.0',
    exportedAt: new Date().toISOString(),
    retail: getRetailState(),
    restaurant: getRestaurantState(),
    customAccounts: getStoredUsers().filter(
      (u) => !DEFAULT_ACCOUNTS.some((d) => d.email === u.email)
    ),
  };
  return JSON.stringify(backup, null, 2);
};

export const importFullDatabaseJSON = (jsonString: string): boolean => {
  try {
    const parsed = JSON.parse(jsonString) as FullDatabaseBackup;
    if (!parsed || !parsed.retail || !parsed.restaurant) {
      throw new Error('Invalid UDAAN backup structure');
    }

    if (parsed.retail) saveRetailState(parsed.retail);
    if (parsed.restaurant) saveRestaurantState(parsed.restaurant);

    if (Array.isArray(parsed.customAccounts)) {
      const mergedUsers = [...DEFAULT_ACCOUNTS];
      parsed.customAccounts.forEach((acc) => {
        if (!mergedUsers.some((u) => u.email === acc.email)) {
          mergedUsers.push(acc);
        }
      });
      safeSet(KEY_USERS, mergedUsers);
    }

    return true;
  } catch (err) {
    console.error('Failed to import database:', err);
    return false;
  }
};

export const resetFullDatabase = (): void => {
  localStorage.removeItem(KEY_RETAIL);
  localStorage.removeItem(KEY_RESTAURANT);
  safeSet(KEY_USERS, DEFAULT_ACCOUNTS);
  // Re-seed freshly
  getRetailState();
  getRestaurantState();
};

// CSV Export Generator
export const generateCSV = (headers: string[], rows: (string | number)[][]): string => {
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const headerLine = headers.map(escapeCell).join(',');
  const rowLines = rows.map((r) => r.map(escapeCell).join(','));
  return [headerLine, ...rowLines].join('\n');
};
