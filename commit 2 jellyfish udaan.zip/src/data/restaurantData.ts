/**
 * UDAAN Restaurant Business Dataset
 * Profile B: "Royal Spice Kitchen & Biryani House"
 * Indiranagar 100ft Road, Bengaluru
 * Managed by Rajesh Shetty
 * Note: Realistic operational and financial figures for live small business analytics.
 */

export interface Dish {
  id: string;
  name: string;
  category: 'Biryani & Rice' | 'Starters' | 'Curries & Gravies' | 'Tandoor & Breads' | 'Beverages' | 'Desserts';
  price: number; // in ₹
  costPrice: number; // in ₹
  unitsSoldMonth: number;
  revenueMonth: number;
  isBestSeller?: boolean;
  isSlowMover?: boolean;
  prepTimeMinutes: number;
  rating: number;
}

export interface RawMaterial {
  id: string;
  name: string;
  category: 'Grains & Flour' | 'Poultry & Meat' | 'Dairy' | 'Vegetables' | 'Oils & Ghee' | 'Spices & Condiments' | 'Fuel & Utilities' | 'Packaging';
  stockQuantity: number;
  unit: 'kg' | 'L' | 'crates' | 'cylinders' | 'sleeves' | 'packs' | 'cases';
  reorderLevel: number;
  costPerUnit: number; // in ₹
  supplier: string;
  lastPurchaseDate: string;
  expiryDate: string;
  wastagePercent: number; // monthly wastage rate %
  wastageCostMonth: number; // in ₹
}

export interface MaterialPurchase {
  id: string;
  date: string;
  materialName: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalAmount: number;
  supplier: string;
  invoiceNo: string;
  paymentStatus: 'Paid' | 'Credit Pending';
}

export interface RestaurantDailySales {
  dayIndex: number;
  date: string; // e.g. "Oct 01"
  fullDate: string; // "2026-10-01"
  sales: number; // in ₹
  covers: number; // customer orders / dining covers
  dineInOrders: number;
  deliveryOrders: number;
  topDish: string;
  wastageAmount: number; // in ₹
}

export interface RestaurantExpense {
  id: string;
  category: 'Rent' | 'Staff Salaries' | 'Utilities & Fuel' | 'Raw Material Supplies' | 'Packaging & Delivery' | 'Maintenance';
  description: string;
  amount: number;
  date: string;
  frequency: 'Monthly' | 'Weekly' | 'Ad-hoc';
}

export interface PeakHourSlot {
  timeSlot: string;
  label: string;
  avgCovers: number;
  avgRevenue: number;
  occupancyPercent: number;
}

export interface CustomerReview {
  id: string;
  customerName: string;
  rating: number; // 1 to 5
  type: 'Dine-In' | 'Delivery';
  date: string;
  dishMentioned: string;
  comment: string;
  sentiment: 'Positive' | 'Neutral' | 'Constructive';
}

// ------------------------------------------------------------------
// 26 DISHES (Full Menu with Best Sellers & Slow Movers)
// ------------------------------------------------------------------
export const RESTAURANT_DISHES: Dish[] = [
  // Biryani & Rice
  {
    id: 'dish-01',
    name: 'Hyderabadi Dum Biryani (Chicken)',
    category: 'Biryani & Rice',
    price: 340,
    costPrice: 145,
    unitsSoldMonth: 580,
    revenueMonth: 197200,
    isBestSeller: true,
    prepTimeMinutes: 15,
    rating: 4.9,
  },
  {
    id: 'dish-02',
    name: 'Royal Mutton Biryani',
    category: 'Biryani & Rice',
    price: 460,
    costPrice: 220,
    unitsSoldMonth: 290,
    revenueMonth: 133400,
    isBestSeller: true,
    prepTimeMinutes: 18,
    rating: 4.8,
  },
  {
    id: 'dish-03',
    name: 'Subz Paneer Dum Biryani',
    category: 'Biryani & Rice',
    price: 280,
    costPrice: 110,
    unitsSoldMonth: 195,
    revenueMonth: 54600,
    prepTimeMinutes: 15,
    rating: 4.6,
  },
  {
    id: 'dish-04',
    name: 'Jeera Rice with Brown Onions',
    category: 'Biryani & Rice',
    price: 180,
    costPrice: 55,
    unitsSoldMonth: 240,
    revenueMonth: 43200,
    prepTimeMinutes: 10,
    rating: 4.5,
  },
  {
    id: 'dish-05',
    name: 'Kashmiri Saffron Pulao',
    category: 'Biryani & Rice',
    price: 240,
    costPrice: 125,
    unitsSoldMonth: 22,
    revenueMonth: 5280,
    isSlowMover: true,
    prepTimeMinutes: 20,
    rating: 3.9,
  },

  // Starters
  {
    id: 'dish-06',
    name: 'Murgh Malai Tikka (6 pcs)',
    category: 'Starters',
    price: 320,
    costPrice: 130,
    unitsSoldMonth: 410,
    revenueMonth: 131200,
    isBestSeller: true,
    prepTimeMinutes: 18,
    rating: 4.9,
  },
  {
    id: 'dish-07',
    name: 'Paneer Angara Tikka (6 pcs)',
    category: 'Starters',
    price: 290,
    costPrice: 115,
    unitsSoldMonth: 320,
    revenueMonth: 92800,
    isBestSeller: true,
    prepTimeMinutes: 16,
    rating: 4.7,
  },
  {
    id: 'dish-08',
    name: 'Guntur Andhra Chilli Chicken',
    category: 'Starters',
    price: 310,
    costPrice: 125,
    unitsSoldMonth: 380,
    revenueMonth: 117800,
    isBestSeller: true,
    prepTimeMinutes: 14,
    rating: 4.8,
  },
  {
    id: 'dish-09',
    name: 'Crispy Corn & Waterchestnut Pepper Salt',
    category: 'Starters',
    price: 240,
    costPrice: 85,
    unitsSoldMonth: 185,
    revenueMonth: 44400,
    prepTimeMinutes: 12,
    rating: 4.5,
  },
  {
    id: 'dish-10',
    name: 'Mutton Galouti Kebab with Paratha',
    category: 'Starters',
    price: 420,
    costPrice: 210,
    unitsSoldMonth: 140,
    revenueMonth: 58800,
    prepTimeMinutes: 22,
    rating: 4.7,
  },
  {
    id: 'dish-11',
    name: 'Tandoori Broccoli Florets',
    category: 'Starters',
    price: 270,
    costPrice: 140,
    unitsSoldMonth: 18,
    revenueMonth: 4860,
    isSlowMover: true,
    prepTimeMinutes: 16,
    rating: 3.8,
  },

  // Curries & Gravies
  {
    id: 'dish-12',
    name: 'Old Delhi Butter Chicken',
    category: 'Curries & Gravies',
    price: 380,
    costPrice: 155,
    unitsSoldMonth: 510,
    revenueMonth: 193800,
    isBestSeller: true,
    prepTimeMinutes: 15,
    rating: 4.9,
  },
  {
    id: 'dish-13',
    name: 'Paneer Butter Masala',
    category: 'Curries & Gravies',
    price: 320,
    costPrice: 120,
    unitsSoldMonth: 440,
    revenueMonth: 140800,
    isBestSeller: true,
    prepTimeMinutes: 14,
    rating: 4.8,
  },
  {
    id: 'dish-14',
    name: 'Dal Makhani (Slow-Cooked 18h)',
    category: 'Curries & Gravies',
    price: 260,
    costPrice: 80,
    unitsSoldMonth: 490,
    revenueMonth: 127400,
    isBestSeller: true,
    prepTimeMinutes: 8,
    rating: 4.9,
  },
  {
    id: 'dish-15',
    name: 'Mutton Rogan Josh',
    category: 'Curries & Gravies',
    price: 450,
    costPrice: 230,
    unitsSoldMonth: 210,
    revenueMonth: 94500,
    prepTimeMinutes: 20,
    rating: 4.7,
  },
  {
    id: 'dish-16',
    name: 'Kadai Paneer Masaledar',
    category: 'Curries & Gravies',
    price: 310,
    costPrice: 125,
    unitsSoldMonth: 190,
    revenueMonth: 58900,
    prepTimeMinutes: 15,
    rating: 4.6,
  },
  {
    id: 'dish-17',
    name: 'Dhaba Style Kadai Mushroom',
    category: 'Curries & Gravies',
    price: 290,
    costPrice: 145,
    unitsSoldMonth: 24,
    revenueMonth: 6960,
    isSlowMover: true,
    prepTimeMinutes: 18,
    rating: 3.7,
  },

  // Tandoor & Breads
  {
    id: 'dish-18',
    name: 'Garlic Butter Naan',
    category: 'Tandoor & Breads',
    price: 75,
    costPrice: 20,
    unitsSoldMonth: 1450,
    revenueMonth: 108750,
    isBestSeller: true,
    prepTimeMinutes: 6,
    rating: 4.9,
  },
  {
    id: 'dish-19',
    name: 'Butter Roti (Tandoor)',
    category: 'Tandoor & Breads',
    price: 45,
    costPrice: 12,
    unitsSoldMonth: 1820,
    revenueMonth: 81900,
    isBestSeller: true,
    prepTimeMinutes: 5,
    rating: 4.8,
  },
  {
    id: 'dish-20',
    name: 'Chur Chur Laccha Paratha',
    category: 'Tandoor & Breads',
    price: 85,
    costPrice: 25,
    unitsSoldMonth: 620,
    revenueMonth: 52700,
    prepTimeMinutes: 7,
    rating: 4.7,
  },
  {
    id: 'dish-21',
    name: 'Missi Roti with Fenugreek',
    category: 'Tandoor & Breads',
    price: 60,
    costPrice: 22,
    unitsSoldMonth: 45,
    revenueMonth: 2700,
    isSlowMover: true,
    prepTimeMinutes: 8,
    rating: 4.0,
  },

  // Beverages
  {
    id: 'dish-22',
    name: 'Punjab Sweet Lassi with Malai Pedha',
    category: 'Beverages',
    price: 130,
    costPrice: 42,
    unitsSoldMonth: 380,
    revenueMonth: 49400,
    prepTimeMinutes: 5,
    rating: 4.8,
  },
  {
    id: 'dish-23',
    name: 'Fresh Mint Lime Soda',
    category: 'Beverages',
    price: 90,
    costPrice: 22,
    unitsSoldMonth: 460,
    revenueMonth: 41400,
    prepTimeMinutes: 4,
    rating: 4.7,
  },
  {
    id: 'dish-24',
    name: 'Cold Coffee with Vanilla Ice Cream',
    category: 'Beverages',
    price: 150,
    costPrice: 65,
    unitsSoldMonth: 32,
    revenueMonth: 4800,
    isSlowMover: true,
    prepTimeMinutes: 8,
    rating: 3.9,
  },

  // Desserts
  {
    id: 'dish-25',
    name: 'Gulab Jamun Flambé (2 pcs)',
    category: 'Desserts',
    price: 120,
    costPrice: 38,
    unitsSoldMonth: 540,
    revenueMonth: 64800,
    isBestSeller: true,
    prepTimeMinutes: 5,
    rating: 4.9,
  },
  {
    id: 'dish-26',
    name: 'Kesariya Malai Rasmalai (2 pcs)',
    category: 'Desserts',
    price: 140,
    costPrice: 50,
    unitsSoldMonth: 390,
    revenueMonth: 54600,
    prepTimeMinutes: 5,
    rating: 4.8,
  },
];

// ------------------------------------------------------------------
// 32 RAW MATERIALS (Kitchen Ingredients & Inventory with Wastage)
// ------------------------------------------------------------------
export const RESTAURANT_RAW_MATERIALS: RawMaterial[] = [
  {
    id: 'rm-01',
    name: 'Daawat Rozana Basmati Rice',
    category: 'Grains & Flour',
    stockQuantity: 14,
    unit: 'kg',
    reorderLevel: 50,
    costPerUnit: 92,
    supplier: 'Sri Lakshmi Agro & Grains',
    lastPurchaseDate: '2026-10-22',
    expiryDate: '2027-04-30',
    wastagePercent: 1.2,
    wastageCostMonth: 380,
  },
  {
    id: 'rm-02',
    name: 'Aashirvaad Sharbati Atta',
    category: 'Grains & Flour',
    stockQuantity: 28,
    unit: 'kg',
    reorderLevel: 60,
    costPerUnit: 44,
    supplier: 'Sri Lakshmi Agro & Grains',
    lastPurchaseDate: '2026-10-20',
    expiryDate: '2027-01-15',
    wastagePercent: 0.8,
    wastageCostMonth: 180,
  },
  {
    id: 'rm-03',
    name: 'Refined Maida (Naan Grade)',
    category: 'Grains & Flour',
    stockQuantity: 35,
    unit: 'kg',
    reorderLevel: 50,
    costPerUnit: 38,
    supplier: 'Sri Lakshmi Agro & Grains',
    lastPurchaseDate: '2026-10-21',
    expiryDate: '2027-02-10',
    wastagePercent: 1.5,
    wastageCostMonth: 210,
  },
  {
    id: 'rm-04',
    name: 'Broiler Chicken (Dressed & Bone-in)',
    category: 'Poultry & Meat',
    stockQuantity: 8,
    unit: 'kg',
    reorderLevel: 30,
    costPerUnit: 180,
    supplier: 'Bengaluru Fresh Poultry Farms',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-28',
    wastagePercent: 3.5,
    wastageCostMonth: 2450,
  },
  {
    id: 'rm-05',
    name: 'Boneless Chicken Breast Fillets',
    category: 'Poultry & Meat',
    stockQuantity: 5,
    unit: 'kg',
    reorderLevel: 25,
    costPerUnit: 260,
    supplier: 'Bengaluru Fresh Poultry Farms',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-28',
    wastagePercent: 2.8,
    wastageCostMonth: 1820,
  },
  {
    id: 'rm-06',
    name: 'Fresh Curry Cut Mutton',
    category: 'Poultry & Meat',
    stockQuantity: 4,
    unit: 'kg',
    reorderLevel: 20,
    costPerUnit: 680,
    supplier: 'City Halal Meat Merchants',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-27',
    wastagePercent: 4.0,
    wastageCostMonth: 3800,
  },
  {
    id: 'rm-07',
    name: 'Farm Fresh Brown Eggs',
    category: 'Poultry & Meat',
    stockQuantity: 6,
    unit: 'crates',
    reorderLevel: 10,
    costPerUnit: 195,
    supplier: 'Bengaluru Fresh Poultry Farms',
    lastPurchaseDate: '2026-10-23',
    expiryDate: '2026-11-08',
    wastagePercent: 2.0,
    wastageCostMonth: 240,
  },
  {
    id: 'rm-08',
    name: 'Nandini Malai Paneer Blocks',
    category: 'Dairy',
    stockQuantity: 6,
    unit: 'kg',
    reorderLevel: 25,
    costPerUnit: 340,
    supplier: 'KMF Nandini Dairy Depot',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-29',
    wastagePercent: 2.5,
    wastageCostMonth: 1250,
  },
  {
    id: 'rm-09',
    name: 'Amul Fresh Cooking Cream',
    category: 'Dairy',
    stockQuantity: 8,
    unit: 'L',
    reorderLevel: 20,
    costPerUnit: 210,
    supplier: 'Kaveri Provisions & Dairy',
    lastPurchaseDate: '2026-10-24',
    expiryDate: '2026-11-20',
    wastagePercent: 1.8,
    wastageCostMonth: 640,
  },
  {
    id: 'rm-10',
    name: 'Full Cream Milk (500ml pouches)',
    category: 'Dairy',
    stockQuantity: 12,
    unit: 'L',
    reorderLevel: 30,
    costPerUnit: 56,
    supplier: 'KMF Nandini Dairy Depot',
    lastPurchaseDate: '2026-10-26',
    expiryDate: '2026-10-28',
    wastagePercent: 1.0,
    wastageCostMonth: 160,
  },
  {
    id: 'rm-11',
    name: 'Thick Hanging Curd (Dahi)',
    category: 'Dairy',
    stockQuantity: 7,
    unit: 'kg',
    reorderLevel: 20,
    costPerUnit: 70,
    supplier: 'KMF Nandini Dairy Depot',
    lastPurchaseDate: '2026-10-24',
    expiryDate: '2026-10-29',
    wastagePercent: 3.0,
    wastageCostMonth: 420,
  },
  {
    id: 'rm-12',
    name: 'Amul Table Butter (Unsalted)',
    category: 'Dairy',
    stockQuantity: 9,
    unit: 'kg',
    reorderLevel: 20,
    costPerUnit: 490,
    supplier: 'Kaveri Provisions & Dairy',
    lastPurchaseDate: '2026-10-22',
    expiryDate: '2027-02-15',
    wastagePercent: 0.5,
    wastageCostMonth: 280,
  },
  {
    id: 'rm-13',
    name: 'Pure Desi Cow Ghee',
    category: 'Oils & Ghee',
    stockQuantity: 11,
    unit: 'L',
    reorderLevel: 20,
    costPerUnit: 640,
    supplier: 'KMF Nandini Dairy Depot',
    lastPurchaseDate: '2026-10-18',
    expiryDate: '2027-04-20',
    wastagePercent: 0.2,
    wastageCostMonth: 140,
  },
  {
    id: 'rm-14',
    name: 'Fortune Sunlite Sunflower Oil (15L Tin)',
    category: 'Oils & Ghee',
    stockQuantity: 3,
    unit: 'crates',
    reorderLevel: 8,
    costPerUnit: 2150,
    supplier: 'Metro Wholesale Traders',
    lastPurchaseDate: '2026-10-15',
    expiryDate: '2027-08-30',
    wastagePercent: 0.3,
    wastageCostMonth: 320,
  },
  {
    id: 'rm-15',
    name: 'Mustard Oil (Kachi Ghani 5L)',
    category: 'Oils & Ghee',
    stockQuantity: 8,
    unit: 'L',
    reorderLevel: 15,
    costPerUnit: 165,
    supplier: 'Metro Wholesale Traders',
    lastPurchaseDate: '2026-10-12',
    expiryDate: '2027-06-15',
    wastagePercent: 0.5,
    wastageCostMonth: 120,
  },
  {
    id: 'rm-16',
    name: 'Nashik Red Onions',
    category: 'Vegetables',
    stockQuantity: 42,
    unit: 'kg',
    reorderLevel: 100,
    costPerUnit: 34,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-24',
    expiryDate: '2026-11-10',
    wastagePercent: 5.2,
    wastageCostMonth: 1850,
  },
  {
    id: 'rm-17',
    name: 'Bangalore Farm Tomatoes',
    category: 'Vegetables',
    stockQuantity: 18,
    unit: 'kg',
    reorderLevel: 60,
    costPerUnit: 28,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-31',
    wastagePercent: 6.8,
    wastageCostMonth: 1480,
  },
  {
    id: 'rm-18',
    name: 'Fresh Ginger & Garlic (Whole Roots)',
    category: 'Vegetables',
    stockQuantity: 12,
    unit: 'kg',
    reorderLevel: 30,
    costPerUnit: 140,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-24',
    expiryDate: '2026-11-05',
    wastagePercent: 4.5,
    wastageCostMonth: 1100,
  },
  {
    id: 'rm-19',
    name: 'Hassan Potatoes (A-Grade)',
    category: 'Vegetables',
    stockQuantity: 38,
    unit: 'kg',
    reorderLevel: 60,
    costPerUnit: 24,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-21',
    expiryDate: '2026-11-15',
    wastagePercent: 2.1,
    wastageCostMonth: 380,
  },
  {
    id: 'rm-20',
    name: 'Hot Green Chillies & Mint Bunches',
    category: 'Vegetables',
    stockQuantity: 4,
    unit: 'kg',
    reorderLevel: 15,
    costPerUnit: 65,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-25',
    expiryDate: '2026-10-29',
    wastagePercent: 7.5,
    wastageCostMonth: 540,
  },
  {
    id: 'rm-21',
    name: 'Fresh Button Mushrooms',
    category: 'Vegetables',
    stockQuantity: 3,
    unit: 'kg',
    reorderLevel: 10,
    costPerUnit: 160,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    lastPurchaseDate: '2026-10-24',
    expiryDate: '2026-10-28',
    wastagePercent: 8.0,
    wastageCostMonth: 820,
  },
  {
    id: 'rm-22',
    name: 'Everest Shahi Biryani Masala',
    category: 'Spices & Condiments',
    stockQuantity: 8,
    unit: 'kg',
    reorderLevel: 15,
    costPerUnit: 480,
    supplier: 'Malnad Spices & Commodities',
    lastPurchaseDate: '2026-10-15',
    expiryDate: '2027-10-15',
    wastagePercent: 0.1,
    wastageCostMonth: 60,
  },
  {
    id: 'rm-23',
    name: 'Kashmiri Deggi Mirch Powder',
    category: 'Spices & Condiments',
    stockQuantity: 12,
    unit: 'kg',
    reorderLevel: 20,
    costPerUnit: 420,
    supplier: 'Malnad Spices & Commodities',
    lastPurchaseDate: '2026-10-15',
    expiryDate: '2027-10-15',
    wastagePercent: 0.1,
    wastageCostMonth: 50,
  },
  {
    id: 'rm-24',
    name: 'Green Cardamom (8mm Bold Grade)',
    category: 'Spices & Condiments',
    stockQuantity: 3,
    unit: 'kg',
    reorderLevel: 5,
    costPerUnit: 2800,
    supplier: 'Malnad Spices & Commodities',
    lastPurchaseDate: '2026-10-05',
    expiryDate: '2027-12-31',
    wastagePercent: 0.05,
    wastageCostMonth: 90,
  },
  {
    id: 'rm-25',
    name: 'Split Cashew Nuts (Kaju Tukda)',
    category: 'Spices & Condiments',
    stockQuantity: 7,
    unit: 'kg',
    reorderLevel: 15,
    costPerUnit: 740,
    supplier: 'Metro Wholesale Traders',
    lastPurchaseDate: '2026-10-14',
    expiryDate: '2027-05-15',
    wastagePercent: 0.5,
    wastageCostMonth: 180,
  },
  {
    id: 'rm-26',
    name: 'Kewra & Rose Water Essence',
    category: 'Spices & Condiments',
    stockQuantity: 5,
    unit: 'L',
    reorderLevel: 8,
    costPerUnit: 180,
    supplier: 'Malnad Spices & Commodities',
    lastPurchaseDate: '2026-09-28',
    expiryDate: '2028-01-01',
    wastagePercent: 0.1,
    wastageCostMonth: 20,
  },
  {
    id: 'rm-27',
    name: 'Commercial LPG Cylinder 19kg',
    category: 'Fuel & Utilities',
    stockQuantity: 2,
    unit: 'cylinders',
    reorderLevel: 5,
    costPerUnit: 1740,
    supplier: 'Indane Commercial Gas Agency',
    lastPurchaseDate: '2026-10-23',
    expiryDate: '2030-01-01',
    wastagePercent: 0.0,
    wastageCostMonth: 0,
  },
  {
    id: 'rm-28',
    name: 'Food-Grade Tandoor Charcoal Wood',
    category: 'Fuel & Utilities',
    stockQuantity: 40,
    unit: 'kg',
    reorderLevel: 80,
    costPerUnit: 35,
    supplier: 'Karnataka Fuel & Charcoal Works',
    lastPurchaseDate: '2026-10-19',
    expiryDate: '2030-01-01',
    wastagePercent: 2.0,
    wastageCostMonth: 140,
  },
  {
    id: 'rm-29',
    name: 'Microwaveable Meal Containers 750ml (50s)',
    category: 'Packaging',
    stockQuantity: 12,
    unit: 'sleeves',
    reorderLevel: 25,
    costPerUnit: 280,
    supplier: 'EcoPack Solutions Bengaluru',
    lastPurchaseDate: '2026-10-20',
    expiryDate: '2030-01-01',
    wastagePercent: 1.0,
    wastageCostMonth: 85,
  },
  {
    id: 'rm-30',
    name: 'Aluminium Biryani Handi Containers (50s)',
    category: 'Packaging',
    stockQuantity: 6,
    unit: 'sleeves',
    reorderLevel: 20,
    costPerUnit: 420,
    supplier: 'EcoPack Solutions Bengaluru',
    lastPurchaseDate: '2026-10-20',
    expiryDate: '2030-01-01',
    wastagePercent: 0.8,
    wastageCostMonth: 65,
  },
  {
    id: 'rm-31',
    name: 'Kraft Paper Takeaway Bags (Pack of 100)',
    category: 'Packaging',
    stockQuantity: 8,
    unit: 'packs',
    reorderLevel: 15,
    costPerUnit: 390,
    supplier: 'EcoPack Solutions Bengaluru',
    lastPurchaseDate: '2026-10-18',
    expiryDate: '2030-01-01',
    wastagePercent: 0.5,
    wastageCostMonth: 40,
  },
  {
    id: 'rm-32',
    name: 'Paper Napkins & Wooden Cutlery (500 sets)',
    category: 'Packaging',
    stockQuantity: 4,
    unit: 'cases',
    reorderLevel: 10,
    costPerUnit: 650,
    supplier: 'EcoPack Solutions Bengaluru',
    lastPurchaseDate: '2026-10-18',
    expiryDate: '2030-01-01',
    wastagePercent: 0.2,
    wastageCostMonth: 25,
  },
];

// ------------------------------------------------------------------
// 60 DAYS OF SALES RECORDS (Realistic restaurant fluctuations)
// ------------------------------------------------------------------
const generate60DaysSales = (): RestaurantDailySales[] => {
  const records: RestaurantDailySales[] = [];
  const topDishesPool = [
    'Hyderabadi Dum Biryani',
    'Butter Chicken',
    'Murgh Malai Tikka',
    'Paneer Butter Masala',
    'Royal Mutton Biryani',
    'Dal Makhani',
  ];

  // Starting from Sept 1, 2026 to Oct 30, 2026
  for (let i = 1; i <= 60; i++) {
    const isOct = i > 30;
    const day = isOct ? i - 30 : i;
    const month = isOct ? 'Oct' : 'Sep';
    const monthNum = isOct ? '10' : '09';
    const dayStr = day < 10 ? `0${day}` : `${day}`;
    const dateLabel = `${month} ${dayStr}`;
    const fullDate = `2026-${monthNum}-${dayStr}`;

    // Weekend boost (Fridays, Saturdays, Sundays)
    const dayOfWeek = (i + 1) % 7;
    const isWeekend = dayOfWeek === 5 || dayOfWeek === 6 || dayOfWeek === 0;

    const baseSales = isWeekend ? 36000 : 26000;
    const variance = (Math.sin(i * 1.5) * 4500) + ((i % 5) * 800);
    const sales = Math.round(baseSales + variance);
    const avgCheck = 340 + (i % 30);
    const covers = Math.round(sales / avgCheck);
    const dineInOrders = Math.round(covers * (isWeekend ? 0.65 : 0.52));
    const deliveryOrders = covers - dineInOrders;
    const topDish = topDishesPool[i % topDishesPool.length];
    const wastageAmount = Math.round(450 + (sales * 0.016));

    records.push({
      dayIndex: i,
      date: dateLabel,
      fullDate,
      sales,
      covers,
      dineInOrders,
      deliveryOrders,
      topDish,
      wastageAmount,
    });
  }
  return records;
};

export const RESTAURANT_SALES_60D: RestaurantDailySales[] = generate60DaysSales();

// Slices for fast filtering
export const RESTAURANT_SALES_30D = RESTAURANT_SALES_60D.slice(-30);
export const RESTAURANT_SALES_7D = RESTAURANT_SALES_60D.slice(-7);

// ------------------------------------------------------------------
// RAW MATERIAL PURCHASES LOG
// ------------------------------------------------------------------
export const RESTAURANT_PURCHASES: MaterialPurchase[] = [
  {
    id: 'PO-701',
    date: '2026-10-25',
    materialName: 'Fresh Chicken & Boneless Fillets',
    quantity: 40,
    unit: 'kg',
    unitPrice: 210,
    totalAmount: 8400,
    supplier: 'Bengaluru Fresh Poultry Farms',
    invoiceNo: 'BFP-9942',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-702',
    date: '2026-10-25',
    materialName: 'Nandini Malai Paneer',
    quantity: 30,
    unit: 'kg',
    unitPrice: 340,
    totalAmount: 10200,
    supplier: 'KMF Nandini Dairy Depot',
    invoiceNo: 'KMF-8812',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-703',
    date: '2026-10-24',
    materialName: 'Red Onions & Farm Tomatoes',
    quantity: 120,
    unit: 'kg',
    unitPrice: 31,
    totalAmount: 3720,
    supplier: 'Cauvery Wholesale Vegetable Mandi',
    invoiceNo: 'CAU-4410',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-704',
    date: '2026-10-23',
    materialName: 'Commercial LPG Cylinder 19kg (3 units)',
    quantity: 3,
    unit: 'cylinders',
    unitPrice: 1740,
    totalAmount: 5220,
    supplier: 'Indane Commercial Gas Agency',
    invoiceNo: 'IND-1029',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-705',
    date: '2026-10-22',
    materialName: 'Daawat Rozana Basmati Rice',
    quantity: 100,
    unit: 'kg',
    unitPrice: 92,
    totalAmount: 9200,
    supplier: 'Sri Lakshmi Agro & Grains',
    invoiceNo: 'SLA-6120',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-706',
    date: '2026-10-20',
    materialName: 'Meal Takeaway Containers & Bags',
    quantity: 20,
    unit: 'sleeves',
    unitPrice: 350,
    totalAmount: 7000,
    supplier: 'EcoPack Solutions Bengaluru',
    invoiceNo: 'ECO-2911',
    paymentStatus: 'Credit Pending',
  },
  {
    id: 'PO-707',
    date: '2026-10-18',
    materialName: 'Amul Butter & Desi Cow Ghee',
    quantity: 30,
    unit: 'kg',
    unitPrice: 560,
    totalAmount: 16800,
    supplier: 'Kaveri Provisions & Dairy',
    invoiceNo: 'KAV-3041',
    paymentStatus: 'Paid',
  },
  {
    id: 'PO-708',
    date: '2026-10-15',
    materialName: 'Fortune Sunflower Oil (4 Tins)',
    quantity: 4,
    unit: 'crates',
    unitPrice: 2150,
    totalAmount: 8600,
    supplier: 'Metro Wholesale Traders',
    invoiceNo: 'MET-8901',
    paymentStatus: 'Paid',
  },
];

// ------------------------------------------------------------------
// OPERATING EXPENSES (Monthly P&L inputs)
// ------------------------------------------------------------------
export const RESTAURANT_EXPENSES: RestaurantExpense[] = [
  {
    id: 'exp-01',
    category: 'Rent',
    description: 'Commercial Prime Space (Indiranagar 100ft Road)',
    amount: 65000,
    date: '2026-10-01',
    frequency: 'Monthly',
  },
  {
    id: 'exp-02',
    category: 'Staff Salaries',
    description: 'Executive Chef (1), Tandoor Master (1), Stewards (3), Kitchen Cleaners (2)',
    amount: 110000,
    date: '2026-10-05',
    frequency: 'Monthly',
  },
  {
    id: 'exp-03',
    category: 'Utilities & Fuel',
    description: 'BESCOM Electricity (High-load refrigeration & AC)',
    amount: 18500,
    date: '2026-10-10',
    frequency: 'Monthly',
  },
  {
    id: 'exp-04',
    category: 'Utilities & Fuel',
    description: 'Commercial 19kg LPG Cylinders refills (6 cylinders/month)',
    amount: 10440,
    date: '2026-10-23',
    frequency: 'Monthly',
  },
  {
    id: 'exp-05',
    category: 'Packaging & Delivery',
    description: 'Food-grade leak-proof delivery containers, cutlery and paper bags',
    amount: 14200,
    date: '2026-10-20',
    frequency: 'Monthly',
  },
  {
    id: 'exp-06',
    category: 'Maintenance',
    description: 'Deep kitchen exhaust chimney cleaning and grease trap service',
    amount: 4500,
    date: '2026-10-15',
    frequency: 'Monthly',
  },
];

// ------------------------------------------------------------------
// PEAK HOUR ANALYSIS (Hour-by-hour dining pattern)
// ------------------------------------------------------------------
export const RESTAURANT_PEAK_HOURS: PeakHourSlot[] = [
  { timeSlot: '12:00 - 13:30', label: 'Early Lunch', avgCovers: 24, avgRevenue: 8200, occupancyPercent: 55 },
  { timeSlot: '13:30 - 15:30', label: 'Prime Lunch Rush', avgCovers: 46, avgRevenue: 16800, occupancyPercent: 92 },
  { timeSlot: '16:00 - 18:30', label: 'Tea & Snacks / Prep', avgCovers: 8, avgRevenue: 2400, occupancyPercent: 20 },
  { timeSlot: '19:00 - 20:30', label: 'Early Dinner', avgCovers: 32, avgRevenue: 11400, occupancyPercent: 70 },
  { timeSlot: '20:30 - 22:30', label: 'Prime Dinner Rush', avgCovers: 58, avgRevenue: 21800, occupancyPercent: 98 },
  { timeSlot: '22:30 - 23:30', label: 'Late Night Delivery', avgCovers: 18, avgRevenue: 6400, occupancyPercent: 40 },
];

// ------------------------------------------------------------------
// CUSTOMER FEEDBACK
// ------------------------------------------------------------------
export const RESTAURANT_REVIEWS: CustomerReview[] = [
  {
    id: 'rev-01',
    customerName: 'Aditya Rao',
    rating: 5,
    type: 'Dine-In',
    date: '2026-10-26',
    dishMentioned: 'Hyderabadi Dum Biryani',
    comment: 'Authentic saffron fragrance, succulent chicken pieces, and perfect grain separation. The salan was rich without being greasy.',
    sentiment: 'Positive',
  },
  {
    id: 'rev-02',
    customerName: 'Shalini Nambiar',
    rating: 5,
    type: 'Delivery',
    date: '2026-10-25',
    dishMentioned: 'Butter Chicken & Garlic Naan',
    comment: 'The gravy arrived piping hot in sealed handi container. Garlic naan stayed soft. Excellent packaging quality!',
    sentiment: 'Positive',
  },
  {
    id: 'rev-03',
    customerName: 'Karthik Shenoy',
    rating: 4,
    type: 'Dine-In',
    date: '2026-10-24',
    dishMentioned: 'Murgh Malai Tikka',
    comment: 'Tikka melts in the mouth. Weekend rush had about 15 mins wait time for a table, but food made up for it.',
    sentiment: 'Positive',
  },
  {
    id: 'rev-04',
    customerName: 'Meenakshi Iyer',
    rating: 3,
    type: 'Delivery',
    date: '2026-10-22',
    dishMentioned: 'Kadai Mushroom',
    comment: 'Mushroom quantity felt slightly less compared to the gravy volume. Gravy taste was good though.',
    sentiment: 'Constructive',
  },
  {
    id: 'rev-05',
    customerName: 'Gaurav Bansal',
    rating: 5,
    type: 'Dine-In',
    date: '2026-10-20',
    dishMentioned: 'Dal Makhani',
    comment: 'You can taste the slow charcoal simmer. Paired with Chur Chur Paratha it was perfection.',
    sentiment: 'Positive',
  },
];

// ------------------------------------------------------------------
// RESTAURANT PROFILE HEADLINE METRICS (October 2026)
// ------------------------------------------------------------------
export const RESTAURANT_PROFILE = {
  name: 'Royal Spice Kitchen & Biryani House',
  ownerName: 'Rajesh Shetty',
  email: 'restaurant@udaan.in',
  phone: '+91 98860 77123',
  address: 'No. 428, 100 Feet Road, Indiranagar',
  city: 'Bengaluru',
  state: 'Karnataka',
  pincode: '560038',
  gstin: '29AAACR4419K1ZS',
  fssaiLicense: '11224333000892',
  cuisine: 'North Indian & Awadhi Biryani',
  seatingCapacity: 64,
  currency: 'INR (₹)',

  // 30-Day Aggregates
  monthSales: 948600, // ₹9.48 Lakhs
  monthOrders: 2480, // Total covers/bills
  todaySales: 34850,
  todayOrders: 94,
  avgOrderValue: 382,
  topDishMonth: 'Hyderabadi Dum Biryani (Chicken)',
  topDishUnits: 580,
  lowStockItemsCount: 7, // 7 raw materials below reorder level
  monthlyWastageTotal: 17825, // ₹17,825 total food waste
  totalRawMaterialsCount: 32,
  totalDishesCount: 26,
  grossMarginPercent: 62.4, // Restaurant gross margin
  netProfitMonth: 218560, // ₹2.18 Lakhs net after rent, salaries, utilities
};
