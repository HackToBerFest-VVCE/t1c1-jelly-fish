import React, { useState, useMemo } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { SAMPLE_PRODUCTS, Product } from '../data/sampleData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  Package,
  Search,
  Filter,
  AlertTriangle,
  ArrowUpDown,
  Truck,
  PlusCircle,
  X,
  CheckCircle,
} from 'lucide-react';

interface InventoryProps {
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

type SortField = 'name' | 'category' | 'price' | 'stockQuantity' | 'reorderLevel' | 'unitsSoldMonth';
type SortOrder = 'asc' | 'desc';

export const Inventory: React.FC<InventoryProps> = ({ onShowToast }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lowStockOnly, setLowStockOnly] = useState<boolean>(false);
  const [sortField, setSortField] = useState<SortField>('stockQuantity');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  // Restock modal state
  const [restockProduct, setRestockProduct] = useState<Product | null>(null);
  const [restockQty, setRestockQty] = useState<number>(10);

  // Extract unique categories
  const categories = useMemo(() => {
    const set = new Set(SAMPLE_PRODUCTS.map((p) => p.category));
    return ['all', ...Array.from(set)];
  }, []);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return SAMPLE_PRODUCTS.filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(search.toLowerCase()) ||
        product.sku.toLowerCase().includes(search.toLowerCase()) ||
        product.supplier.toLowerCase().includes(search.toLowerCase());

      const matchesCat =
        selectedCategory === 'all' || product.category === selectedCategory;

      const matchesLow = !lowStockOnly || product.stockQuantity < product.reorderLevel;

      return matchesSearch && matchesCat && matchesLow;
    }).sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortOrder === 'asc'
          ? valA.localeCompare(valB)
          : valB.localeCompare(valA);
      }

      return sortOrder === 'asc'
        ? (valA as number) - (valB as number)
        : (valB as number) - (valA as number);
    });
  }, [search, selectedCategory, lowStockOnly, sortField, sortOrder]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleOpenRestock = (product: Product) => {
    const suggestedUnits = Math.max(10, (product.reorderLevel - product.stockQuantity) + 5);
    setRestockQty(suggestedUnits);
    setRestockProduct(product);
  };

  const handleConfirmRestock = () => {
    if (!restockProduct) return;
    onShowToast(
      `Restock order drafted for ${restockQty} units of ${restockProduct.name} with ${restockProduct.supplier}. (Demo simulation - no real order sent)`,
      'success',
      'Order Drafted'
    );
    setRestockProduct(null);
  };

  // Aggregated summaries
  const totalStockCount = SAMPLE_PRODUCTS.reduce((acc, p) => acc + p.stockQuantity, 0); // 342
  const lowCount = SAMPLE_PRODUCTS.filter((p) => p.stockQuantity < p.reorderLevel).length; // 8

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Inventory & Stock Control
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Real-time stock audits, threshold alerts, and supplier procurement tracking.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs text-[#F8F9FA]/70 bg-[#112240] px-3 py-1.5 rounded-lg border border-[#F8F9FA]/10">
            Total In Stock:{' '}
            <strong className="text-[#64FFDA] font-mono tabular-nums">{totalStockCount} units</strong>
          </div>
          <div className="text-xs text-[#F8F9FA]/70 bg-[#112240] px-3 py-1.5 rounded-lg border border-[#F8F9FA]/10">
            Low Alerts:{' '}
            <strong className="text-[#FFB703] font-mono tabular-nums">{lowCount} items</strong>
          </div>
        </div>
      </div>

      {/* Control Bar: Search, Category dropdown, Low stock only toggle */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by product name, SKU, or supplier..."
              className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40 hover:text-[#F8F9FA]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Category Filter */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-[#F8F9FA]/60">Category:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg px-2.5 py-1.5 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none cursor-pointer"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat} className="bg-[#112240] text-[#F8F9FA]">
                    {cat === 'all' ? 'All Categories' : cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Low stock only toggle */}
            <button
              onClick={() => setLowStockOnly(!lowStockOnly)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                lowStockOnly
                  ? 'bg-[#FFB703]/15 border-[#FFB703] text-[#FFB703]'
                  : 'bg-[#0A192F] border-[#F8F9FA]/15 text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-[#FFB703]" />
              <span>Low stock only ({lowCount})</span>
            </button>
          </div>

        </div>
      </Card>

      {/* Main Inventory Table */}
      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          {filteredProducts.length === 0 ? (
            <div className="p-8">
              <EmptyState
                title="No products match your filters"
                description="Try clearing your search query or switching category filters."
                actionLabel="Reset Inventory Filters"
                onAction={() => {
                  setSearch('');
                  setSelectedCategory('all');
                  setLowStockOnly(false);
                }}
              />
            </div>
          ) : (
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead>
                <tr className="bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                  <th
                    onClick={() => toggleSort('name')}
                    className="py-3 px-4 cursor-pointer hover:text-[#F8F9FA]"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Product & SKU</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('category')}
                    className="py-3 px-4 cursor-pointer hover:text-[#F8F9FA]"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Category</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('price')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Price</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('stockQuantity')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Stock / Reorder</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('unitsSoldMonth')}
                    className="py-3 px-4 text-right cursor-pointer hover:text-[#F8F9FA]"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Sold (Month)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                {filteredProducts.map((product) => {
                  const isLow = product.stockQuantity < product.reorderLevel;
                  const isCritical = product.stockQuantity <= 5;

                  return (
                    <tr
                      key={product.id}
                      className={`hover:bg-[#F8F9FA]/[0.02] transition-colors ${
                        isCritical ? 'bg-red-500/[0.03]' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#F8F9FA]">{product.name}</div>
                        <div className="font-mono text-[10px] text-[#F8F9FA]/40">{product.sku}</div>
                      </td>
                      <td className="py-3 px-4 text-[#F8F9FA]/70">{product.category}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]">
                        {formatCurrency(product.price)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        <span
                          className={`font-bold ${
                            isCritical
                              ? 'text-red-400'
                              : isLow
                              ? 'text-[#FFB703]'
                              : 'text-[#64FFDA]'
                          }`}
                        >
                          {product.stockQuantity}
                        </span>{' '}
                        <span className="text-[#F8F9FA]/40">/ {product.reorderLevel} min</span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-[#F8F9FA]/80">
                        {product.unitsSoldMonth} units
                      </td>
                      <td className="py-3 px-4 text-[#F8F9FA]/65 max-w-[140px] truncate">
                        {product.supplier}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge
                          variant={isCritical ? 'critical' : isLow ? 'low' : 'ok'}
                          size="sm"
                        >
                          {isCritical ? 'Critical' : isLow ? 'Low' : 'OK'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => handleOpenRestock(product)}
                          className="px-2.5 py-1 text-[11px] font-medium text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded transition-colors cursor-pointer"
                        >
                          Restock
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <div className="p-3 bg-[#0A192F]/40 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-[11px] text-[#F8F9FA]/50">
          <span>
            Displaying {filteredProducts.length} of {SAMPLE_PRODUCTS.length} total inventory items
          </span>
          <span className="font-mono">Exact sum = 342 units in stock</span>
        </div>
      </Card>

      {/* RESTOCK MODAL */}
      {restockProduct && (
        <div
          className="fixed inset-0 z-50 bg-[#0A192F]/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#112240] border border-[#FFB703]/30 rounded-xl p-6 max-w-md w-full shadow-2xl relative text-[#F8F9FA]">
            <button
              onClick={() => setRestockProduct(null)}
              className="absolute top-4 right-4 text-[#F8F9FA]/50 hover:text-[#F8F9FA] p-1 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-[#FFB703]/15 text-[#FFB703] flex items-center justify-center">
                <Package className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#F8F9FA]">Draft Restock Order</h3>
                <p className="text-xs text-[#F8F9FA]/60">{restockProduct.name}</p>
              </div>
            </div>

            <div className="space-y-3.5 text-xs bg-[#0A192F] p-4 rounded-lg border border-[#F8F9FA]/10 mb-5">
              <div className="flex justify-between">
                <span className="text-[#F8F9FA]/60">Supplier:</span>
                <span className="font-medium text-[#F8F9FA]">{restockProduct.supplier}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#F8F9FA]/60">Current Stock:</span>
                <span className="font-mono font-bold text-[#FFB703]">{restockProduct.stockQuantity} units</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#F8F9FA]/60">Minimum Safe Level:</span>
                <span className="font-mono text-[#F8F9FA]">{restockProduct.reorderLevel} units</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#F8F9FA]/60">Cost per unit:</span>
                <span className="font-mono text-[#F8F9FA]">{formatCurrency(restockProduct.costPrice)}</span>
              </div>

              <div className="pt-2 border-t border-[#F8F9FA]/10 flex items-center justify-between">
                <label htmlFor="restock-quantity" className="font-semibold text-[#F8F9FA]">
                  Order Quantity:
                </label>
                <input
                  id="restock-quantity"
                  type="number"
                  min={1}
                  max={500}
                  value={restockQty}
                  onChange={(e) => setRestockQty(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-20 bg-[#112240] border border-[#FFB703]/40 rounded px-2 py-1 text-center font-mono font-bold text-[#FFB703] text-sm"
                />
              </div>

              <div className="flex justify-between pt-1 text-[#64FFDA] font-semibold">
                <span>Estimated Cost:</span>
                <span className="font-mono">{formatCurrency(restockQty * restockProduct.costPrice)}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setRestockProduct(null)}
                className="px-3.5 py-2 text-xs font-medium text-[#F8F9FA]/70 hover:text-[#F8F9FA] rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmRestock}
                className="px-4 py-2 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors shadow-sm cursor-pointer"
              >
                Confirm Order Draft
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
