import React, { useState, useMemo } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { SAMPLE_SUPPLIERS, Supplier } from '../data/sampleData';
import {
  Truck,
  Phone,
  MapPin,
  Calendar,
  Search,
  Package,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

interface SuppliersProps {
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

type SupplierStatusFilter = 'all' | 'Delivered' | 'In Transit' | 'Delayed' | 'Scheduled';

export const Suppliers: React.FC<SuppliersProps> = ({ onShowToast }) => {
  const [statusFilter, setStatusFilter] = useState<SupplierStatusFilter>('all');
  const [search, setSearch] = useState('');

  const filteredSuppliers = useMemo(() => {
    return SAMPLE_SUPPLIERS.filter((supplier) => {
      const matchesStatus =
        statusFilter === 'all' || supplier.status === statusFilter;
      const matchesSearch =
        supplier.name.toLowerCase().includes(search.toLowerCase()) ||
        supplier.contactPerson.toLowerCase().includes(search.toLowerCase()) ||
        supplier.city.toLowerCase().includes(search.toLowerCase()) ||
        supplier.productsSupplied.toLowerCase().includes(search.toLowerCase());

      return matchesStatus && matchesSearch;
    });
  }, [statusFilter, search]);

  const handleCallSupplier = (supplier: Supplier) => {
    onShowToast(
      `Contacting ${supplier.contactPerson} (${supplier.phone}) for ${supplier.name}. (Simulated action)`,
      'info',
      'Supplier Call'
    );
  };

  const handleTrackDelivery = (supplier: Supplier) => {
    onShowToast(
      `Delivery tracking for ${supplier.name}: Status is ${supplier.status}, scheduled arrival on ${supplier.nextDeliveryDate}.`,
      'info',
      'Shipment Status'
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Suppliers & Procurement
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Karnataka vendor network, delivery schedules, and replenishment lead times.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="mint" size="md">
            6 Active Vendors
          </Badge>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by vendor, contact, city, or supplied goods..."
              className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
            />
          </div>

          {/* Status buttons */}
          <div className="flex items-center flex-wrap gap-1 p-1 bg-[#0A192F] rounded-lg border border-[#F8F9FA]/10">
            {(['all', 'Scheduled', 'In Transit', 'Delayed', 'Delivered'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                  statusFilter === st
                    ? 'bg-[#FFB703] text-[#0A192F] font-semibold'
                    : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                }`}
              >
                {st === 'all' ? 'All Status' : st}
              </button>
            ))}
          </div>

        </div>
      </Card>

      {/* Supplier Cards Grid */}
      {filteredSuppliers.length === 0 ? (
        <EmptyState
          icon={Truck}
          title="No suppliers match current filter"
          description="Try switching the delivery status filter or clearing your search keywords."
          actionLabel="Show All Suppliers"
          onAction={() => {
            setStatusFilter('all');
            setSearch('');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSuppliers.map((sup) => (
            <Card
              key={sup.id}
              className="p-5 flex flex-col justify-between hover:border-[#FFB703]/30 transition-all shadow-sm"
            >
              <div>
                {/* Header row with name and status */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <h3 className="text-base font-semibold text-[#F8F9FA] tracking-tight">
                      {sup.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-[#F8F9FA]/60 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#FFB703]" />
                      <span>{sup.city}, Karnataka</span>
                    </div>
                  </div>
                  <Badge
                    variant={
                      sup.status === 'Delivered'
                        ? 'success'
                        : sup.status === 'In Transit'
                        ? 'transit'
                        : sup.status === 'Delayed'
                        ? 'delayed'
                        : 'scheduled'
                    }
                    size="sm"
                  >
                    {sup.status}
                  </Badge>
                </div>

                {/* Products supplied */}
                <div className="p-3 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.06] mb-4 text-xs">
                  <div className="text-[10px] uppercase tracking-wider text-[#F8F9FA]/45 font-medium mb-1 flex items-center gap-1">
                    <Package className="w-3 h-3 text-[#FFB703]" />
                    <span>Supplies</span>
                  </div>
                  <div className="text-[#F8F9FA]/85 line-clamp-2">
                    {sup.productsSupplied}
                  </div>
                </div>

                {/* Delivery Dates */}
                <div className="space-y-2 text-xs mb-4">
                  <div className="flex items-center justify-between text-[#F8F9FA]/70">
                    <span className="flex items-center gap-1.5 text-[#F8F9FA]/50">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Last Delivery:</span>
                    </span>
                    <span className="font-mono">{sup.lastDeliveryDate}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-[#F8F9FA]/50">
                      <Calendar className="w-3.5 h-3.5 text-[#64FFDA]" />
                      <span>Next ETA:</span>
                    </span>
                    <span className="font-mono font-medium text-[#64FFDA]">
                      {sup.nextDeliveryDate}
                    </span>
                  </div>
                </div>
              </div>

              {/* Footer contact person & actions */}
              <div className="pt-3 border-t border-[#F8F9FA]/[0.08] flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs font-medium text-[#F8F9FA] truncate">
                    {sup.contactPerson}
                  </div>
                  <div className="text-[11px] font-mono text-[#F8F9FA]/50 truncate">
                    {sup.phone}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handleCallSupplier(sup)}
                    className="p-2 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/15 text-[#64FFDA] hover:bg-[#64FFDA]/10 transition-colors cursor-pointer"
                    title={`Call ${sup.contactPerson}`}
                    aria-label={`Call ${sup.contactPerson}`}
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleTrackDelivery(sup)}
                    className="px-2.5 py-1.5 rounded-lg bg-[#FFB703] text-[#0A192F] text-xs font-semibold hover:bg-[#E5A502] transition-colors cursor-pointer"
                  >
                    Track ETA
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Karnataka Supplier note */}
      <div className="p-4 rounded-xl bg-[#112240]/40 border border-[#F8F9FA]/[0.06] flex items-start gap-3 text-xs text-[#F8F9FA]/60">
        <Truck className="w-4 h-4 text-[#FFB703] shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          UDAAN supplier sync coordinates inventory replenishment directly with your wholesale distributors across Bengaluru, Mysuru, Mandya, Hubballi, and Shivamogga. In this demo, all actions simulate lead-time tracking.
        </p>
      </div>

    </div>
  );
};
