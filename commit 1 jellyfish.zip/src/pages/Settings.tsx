import React, { useState } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { DEFAULT_STORE_PROFILE, StoreProfile } from '../data/sampleData';
import {
  Settings as SettingsIcon,
  Store,
  User,
  Phone,
  MapPin,
  FileText,
  IndianRupee,
  Bell,
  Save,
  ShieldAlert,
  Info,
} from 'lucide-react';

interface SettingsProps {
  profile: StoreProfile;
  onUpdateProfile: (updated: StoreProfile) => void;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

export const Settings: React.FC<SettingsProps> = ({
  profile,
  onUpdateProfile,
  onShowToast,
}) => {
  const [formData, setFormData] = useState<StoreProfile>(profile);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    setTimeout(() => {
      setIsSaving(false);
      onUpdateProfile(formData);
      onShowToast(
        'Saved (demo only, nothing is stored permanently in any database).',
        'success',
        'Settings Updated'
      );
    }, 400);
  };

  const handleResetToDefault = () => {
    setFormData(DEFAULT_STORE_PROFILE);
    onUpdateProfile(DEFAULT_STORE_PROFILE);
    onShowToast('Reset to default Demo Store configuration.', 'info');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Store Profile & Preferences
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Configure your Kirana identity, alert thresholds, and communication settings.
          </p>
        </div>

        <Badge variant="gold" size="md">
          Mock settings session
        </Badge>
      </div>

      {/* Honest disclaimer notice */}
      <div className="p-4 rounded-xl bg-[#112240] border border-[#FFB703]/30 flex items-start gap-3 text-xs">
        <Info className="w-4 h-4 text-[#FFB703] shrink-0 mt-0.5" />
        <div className="text-[#F8F9FA]/80 leading-relaxed">
          <strong>Demo Notice:</strong> No persistent backend database exists in this hackathon prototype. Changes made here apply immediately to your current browser session and TopBar, but will revert when reloading.
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Business Profile Details */}
        <Card className="p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
            <Store className="w-5 h-5 text-[#FFB703]" />
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Business Profile
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Store Name */}
            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Business Name
              </label>
              <div className="relative">
                <Store className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  required
                />
              </div>
            </div>

            {/* Owner Name */}
            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Owner / Manager Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.ownerName}
                  onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  required
                />
              </div>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Contact Phone
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                />
              </div>
            </div>

            {/* City & State */}
            <div>
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                Location City & State
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={`${formData.city}, ${formData.state}`}
                  onChange={(e) => {
                    const parts = e.target.value.split(',');
                    setFormData({
                      ...formData,
                      city: parts[0]?.trim() || '',
                      state: parts[1]?.trim() || 'Karnataka',
                    });
                  }}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                />
              </div>
            </div>

            {/* GSTIN Placeholder */}
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#F8F9FA]/70 mb-1.5">
                GSTIN / Trade Registration Number
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
                <input
                  type="text"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                  className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-[#F8F9FA] focus:border-[#FFB703] focus:outline-none"
                  placeholder="29AAAAA0000A1Z5"
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Financial & Inventory Configuration */}
        <Card className="p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
            <IndianRupee className="w-5 h-5 text-[#64FFDA]" />
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Financial & Stock Thresholds
            </h3>
          </div>

          <div className="space-y-4">
            {/* Fixed Currency */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/[0.06] text-xs">
              <div>
                <div className="font-semibold text-[#F8F9FA]">Reporting Currency</div>
                <div className="text-[11px] text-[#F8F9FA]/50">
                  Fixed to Indian Rupee (₹) with Lakhs & Crores digit grouping
                </div>
              </div>
              <Badge variant="mint" size="md">
                ₹ INR (en-IN)
              </Badge>
            </div>

            {/* Low-stock threshold percentage */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-medium text-[#F8F9FA]/70">
                  Low Stock Safety Margin Alert
                </label>
                <span className="text-xs font-mono font-bold text-[#FFB703]">
                  {formData.lowStockThresholdPercent}% buffer
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="50"
                step="5"
                value={formData.lowStockThresholdPercent}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    lowStockThresholdPercent: parseInt(e.target.value),
                  })
                }
                className="w-full accent-[#FFB703] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#F8F9FA]/40 mt-1">
                <span>10% (Tight)</span>
                <span>20% (Default)</span>
                <span>50% (High safety)</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Notifications & Automation */}
        <Card className="p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-[#F8F9FA]/[0.08]">
            <Bell className="w-5 h-5 text-[#FFB703]" />
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Notifications & Alerts
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            {/* Daily summary */}
            <label className="flex items-center justify-between p-3 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/[0.06] cursor-pointer hover:border-[#F8F9FA]/15">
              <div>
                <div className="font-semibold text-[#F8F9FA]">Daily Store Closing Summary</div>
                <div className="text-[11px] text-[#F8F9FA]/50">
                  Generates 9:00 PM WhatsApp/SMS closing digest with daily sales & cash count
                </div>
              </div>
              <input
                type="checkbox"
                checked={formData.dailySummaryNotifications}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    dailySummaryNotifications: e.target.checked,
                  })
                }
                className="w-4 h-4 rounded border-[#F8F9FA]/20 bg-[#112240] text-[#FFB703] focus:ring-[#FFB703] cursor-pointer"
              />
            </label>

            {/* Instant SMS Alert for Critical Low Stock */}
            <label className="flex items-center justify-between p-3 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/[0.06] cursor-pointer hover:border-[#F8F9FA]/15">
              <div>
                <div className="font-semibold text-[#F8F9FA]">Critical Stock SMS Alerts</div>
                <div className="text-[11px] text-[#F8F9FA]/50">
                  Notify store manager immediately when any essential item drops under 5 units
                </div>
              </div>
              <input
                type="checkbox"
                checked={formData.smsAlerts}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    smsAlerts: e.target.checked,
                  })
                }
                className="w-4 h-4 rounded border-[#F8F9FA]/20 bg-[#112240] text-[#FFB703] focus:ring-[#FFB703] cursor-pointer"
              />
            </label>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-4 py-2 text-xs text-[#F8F9FA]/60 hover:text-[#F8F9FA] transition-colors cursor-pointer"
          >
            Reset to Demo Defaults
          </button>

          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <span>Saving Changes...</span>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save Store Preferences</span>
              </>
            )}
          </button>
        </div>

      </form>

    </div>
  );
};
