import React, { useState, useMemo } from 'react';
import { Card } from '../components/Card';
import { ChartCard } from '../components/ChartCard';
import { MetricCard } from '../components/MetricCard';
import { Badge } from '../components/Badge';
import {
  DAILY_SALES_30D,
  DAILY_SALES_7D,
  MONTHLY_SALES_6M,
  CATEGORY_SALES_BREAKDOWN,
  SAMPLE_PRODUCTS,
} from '../data/sampleData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  IndianRupee,
  ShoppingBag,
  TrendingUp,
  BarChart2,
  Calendar,
  PieChart as PieIcon,
  Layers,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

type DateRange = '7D' | '30D' | '6M';

export const SalesAnalytics: React.FC = () => {
  const [dateRange, setDateRange] = useState<DateRange>('30D');

  // Compute metrics based on selected dateRange
  const activeMetrics = useMemo(() => {
    if (dateRange === '7D') {
      const totalSales = DAILY_SALES_7D.reduce((acc, d) => acc + d.sales, 0); // ₹12,090
      const totalOrders = DAILY_SALES_7D.reduce((acc, d) => acc + d.orders, 0); // 30 orders
      return {
        totalSales,
        totalOrders,
        aov: Math.round(totalSales / totalOrders),
        growth: '+5.9% vs previous 7 days',
        periodLabel: 'Last 7 Days (Oct 24 - 30)',
      };
    }
    if (dateRange === '6M') {
      const totalSales = MONTHLY_SALES_6M.reduce((acc, m) => acc + m.sales, 0); // ₹2,59,350
      const totalOrders = MONTHLY_SALES_6M.reduce((acc, m) => acc + m.orders, 0); // 677 orders
      return {
        totalSales,
        totalOrders,
        aov: Math.round(totalSales / totalOrders),
        growth: '+22.1% from May to Oct',
        periodLabel: 'Last 6 Months (May - Oct 2026)',
      };
    }
    // 30D default
    return {
      totalSales: 48250,
      totalOrders: 126,
      aov: Math.round(48250 / 126),
      growth: '+8.4% vs last month',
      periodLabel: 'Current Month (October 2026)',
    };
  }, [dateRange]);

  // Chart data based on active dateRange
  const trendData = useMemo(() => {
    if (dateRange === '7D') {
      return DAILY_SALES_7D.map((d) => ({
        label: d.date,
        sales: d.sales,
        orders: d.orders,
      }));
    }
    if (dateRange === '6M') {
      return MONTHLY_SALES_6M.map((m) => ({
        label: m.month.split(' ')[0],
        sales: m.sales,
        orders: m.orders,
      }));
    }
    return DAILY_SALES_30D.map((d) => ({
      label: d.date,
      sales: d.sales,
      orders: d.orders,
    }));
  }, [dateRange]);

  // Palette colors for category breakdown (Strictly Gold, Mint, and Tints of White/Indigo)
  const CATEGORY_COLORS = [
    '#FFB703', // Warm Amber Gold
    '#64FFDA', // Mint Accent
    '#3B82F6', // Blue Accent
    '#A78BFA', // Soft Indigo tint
    '#38BDF8', // Cyan tint
    '#FBBF24', // Amber tint
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header & Date Range Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Sales & Revenue Analytics
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Historical turnover, order velocity, and category sales performance.
          </p>
        </div>

        {/* Date Range Selector that actually updates all charts */}
        <div className="flex items-center gap-1.5 p-1 bg-[#112240] rounded-xl border border-[#F8F9FA]/10 self-start sm:self-center">
          <Calendar className="w-3.5 h-3.5 text-[#FFB703] ml-2 mr-1" />
          {(['7D', '30D', '6M'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setDateRange(range)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                dateRange === range
                  ? 'bg-[#FFB703] text-[#0A192F] font-semibold shadow-sm'
                  : 'text-[#F8F9FA]/70 hover:text-[#F8F9FA]'
              }`}
            >
              {range === '7D' ? 'Last 7 Days' : range === '30D' ? 'Last 30 Days' : 'Last 6 Months'}
            </button>
          ))}
        </div>
      </div>

      {/* Dynamic Metric Cards for selected timeframe */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MetricCard
          title="Period Sales Volume"
          value={formatCurrency(activeMetrics.totalSales)}
          icon={IndianRupee}
          trendText={activeMetrics.growth}
          trendDirection="up"
          subtext={activeMetrics.periodLabel}
          accent="gold"
        />
        <MetricCard
          title="Period Orders"
          value={formatIndianNumber(activeMetrics.totalOrders)}
          icon={ShoppingBag}
          trendText="Verified transactions"
          trendDirection="neutral"
          subtext={`Avg. ${Math.round(activeMetrics.totalOrders / (dateRange === '7D' ? 7 : dateRange === '30D' ? 30 : 180))} / day`}
          accent="mint"
        />
        <MetricCard
          title="Average Order Value"
          value={formatCurrency(activeMetrics.aov)}
          icon={TrendingUp}
          trendText="+4.2% basket size"
          trendDirection="up"
          subtext="Per billing receipt"
          accent="default"
        />
      </div>

      {/* Primary Trend Line Chart */}
      <ChartCard
        title={`Sales Trend (${activeMetrics.periodLabel})`}
        subtitle="Daily billing progression and transaction receipts"
        footerNote="All dates correspond to fictional kirana billing data."
      >
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={trendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
            <XAxis
              dataKey="label"
              stroke="rgba(248, 249, 250, 0.4)"
              fontSize={11}
              tickLine={false}
              interval={dateRange === '30D' ? 4 : 0}
            />
            <YAxis
              stroke="rgba(248, 249, 250, 0.4)"
              fontSize={11}
              tickLine={false}
              tickFormatter={(v) => `₹${v}`}
            />
            <Tooltip
              contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
              labelStyle={{ color: '#F8F9FA' }}
              formatter={(val: any, _name?: any) => [
                formatCurrency(val),
                'Sales Revenue',
              ]}
            />
            <Line
              type="monotone"
              dataKey="sales"
              stroke="#FFB703"
              strokeWidth={2.5}
              dot={dateRange === '6M' || dateRange === '7D' ? { r: 4, fill: '#FFB703' } : false}
              activeDot={{ r: 6, fill: '#64FFDA' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Row 2: 6 Months Bar Chart & Category Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Monthly Comparison Bar Chart (Last 6 Months) */}
        <div className="lg:col-span-7">
          <ChartCard
            title="Monthly Revenue Comparison (Last 6 Months)"
            subtitle="Steady month-over-month growth from May (₹39,500) to October (₹48,250)"
            footerNote="Profit margin averages 25-26% across all 6 months."
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={MONTHLY_SALES_6M} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
                <XAxis dataKey="month" stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} />
                <YAxis stroke="rgba(248, 249, 250, 0.4)" fontSize={11} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                  labelStyle={{ color: '#F8F9FA' }}
                  formatter={(val: any) => [formatCurrency(val), 'Sales']}
                />
                <Bar dataKey="sales" radius={[4, 4, 0, 0]}>
                  {MONTHLY_SALES_6M.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index === MONTHLY_SALES_6M.length - 1 ? '#FFB703' : '#1B2D4F'}
                      stroke={index === MONTHLY_SALES_6M.length - 1 ? '#FFB703' : 'rgba(248,249,250,0.15)'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Category Breakdown */}
        <div className="lg:col-span-5">
          <Card className="p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-base font-semibold text-[#F8F9FA]">
                  Category Share
                </h3>
                <span className="text-xs text-[#FFB703] font-medium">October Revenue</span>
              </div>
              <p className="text-xs text-[#F8F9FA]/60 mb-4">
                Grocery & Staples contributes nearly half of all store income.
              </p>

              <div className="space-y-3">
                {CATEGORY_SALES_BREAKDOWN.map((cat, idx) => (
                  <div key={cat.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#F8F9FA]/80 flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-sm shrink-0"
                          style={{ backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length] }}
                        />
                        {cat.name}
                      </span>
                      <span className="font-mono tabular-nums text-[#F8F9FA]">
                        {formatCurrency(cat.sales)}{' '}
                        <span className="text-[#F8F9FA]/40">({cat.percentage}%)</span>
                      </span>
                    </div>
                    {/* Visual bar progress */}
                    <div className="h-1.5 w-full bg-[#0A192F] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${cat.percentage}%`,
                          backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length],
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-[#F8F9FA]/[0.08] flex items-center justify-between text-[11px] text-[#F8F9FA]/50">
              <span>Total 6 Categories</span>
              <span className="font-mono text-[#FFB703]">₹48,250 Total</span>
            </div>
          </Card>
        </div>

      </div>

      {/* Top Products Table */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-semibold text-[#F8F9FA]">
              Product Revenue & Margin Breakdown
            </h3>
            <p className="text-xs text-[#F8F9FA]/60 mt-0.5">
              Ranked by total monthly turnover and margin contribution
            </p>
          </div>
          <Badge variant="mint" size="sm">
            12 Active SKUs
          </Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead>
              <tr className="border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                <th className="py-2.5 px-3">Product Name</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Selling Price</th>
                <th className="py-2.5 px-3 text-right">Units Sold</th>
                <th className="py-2.5 px-3 text-right">Monthly Revenue</th>
                <th className="py-2.5 px-3 text-right">Est. Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
              {[...SAMPLE_PRODUCTS]
                .sort((a, b) => b.revenueMonth - a.revenueMonth)
                .map((product) => {
                  const marginPercent = Math.round(
                    ((product.price - product.costPrice) / product.price) * 100
                  );
                  return (
                    <tr key={product.id} className="hover:bg-[#F8F9FA]/[0.02]">
                      <td className="py-2.5 px-3 font-medium text-[#F8F9FA]">{product.name}</td>
                      <td className="py-2.5 px-3 text-[#F8F9FA]/60">{product.category}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#F8F9FA]/80">
                        {formatCurrency(product.price)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#64FFDA] font-semibold">
                        {product.unitsSoldMonth} units
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#FFB703] font-bold">
                        {formatCurrency(product.revenueMonth)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-[#F8F9FA]/80">
                        {marginPercent}%
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Card>

    </div>
  );
};
