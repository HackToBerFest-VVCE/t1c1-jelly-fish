import React, { useState } from 'react';
import { Logo } from '../components/Logo';
import { Eye, EyeOff, Lock, Mail, ArrowRight, ShieldCheck, Sparkles, X, Info } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [identifier, setIdentifier] = useState('demo@udaan.app');
  const [password, setPassword] = useState('UdaanDemo123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Modals for demo placeholders
  const [modalType, setModalType] = useState<'forgot' | 'signup' | null>(null);

  const handleSignIn = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage('');

    const trimmedId = identifier.trim();
    if (!trimmedId) {
      setErrorMessage('Please enter your business email or username.');
      return;
    }

    if (trimmedId.includes('@')) {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(trimmedId)) {
        setErrorMessage('Please enter a valid email address (e.g. demo@udaan.app).');
        return;
      }
    }

    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      // Check credentials against demo account
      if (
        (trimmedId.toLowerCase() === 'demo@udaan.app' || trimmedId.toLowerCase() === 'demo') &&
        password === 'UdaanDemo123'
      ) {
        setIsLoading(false);
        onLoginSuccess();
      } else {
        setIsLoading(false);
        setErrorMessage(
          "Those details don't match the demo account. Try demo@udaan.app / UdaanDemo123 or click 'Explore Demo Dashboard' below."
        );
      }
    }, 700);
  };

  const handleDirectDemoAccess = () => {
    setIsLoading(true);
    setErrorMessage('');
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
    }, 400);
  };

  const handleFillCredentials = () => {
    setIdentifier('demo@udaan.app');
    setPassword('UdaanDemo123');
    setErrorMessage('');
  };

  return (
    <div className="min-h-screen bg-[#0A192F] flex flex-col justify-center px-4 sm:px-6 lg:px-8 py-10 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#112240] rounded-full blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-[#FFB703]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10">
        
        {/* LEFT COLUMN: Brand identity, tagline, abstract soaring visual */}
        <div className="lg:col-span-6 flex flex-col justify-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#112240] border border-[#F8F9FA]/10 text-xs text-[#64FFDA] w-fit mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-[#64FFDA]" />
            <span>Prototype / Demo Experience</span>
          </div>

          <Logo size={46} showWordmark={true} className="mb-6" />

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-[#F8F9FA] tracking-tight leading-[1.15] mb-4">
            Give Your Business <br />
            <span className="text-[#FFB703] italic">Freedom.</span>
          </h1>

          <p className="text-sm sm:text-base text-[#F8F9FA]/70 leading-relaxed max-w-lg mb-8">
            UDAAN empowers Kirana and small enterprise owners to understand sales trends, prevent inventory stockouts, and manage suppliers with plain-language intelligence.
          </p>

          {/* Abstract SVG visual: faint rising bars, growth curve and ascending wing line */}
          <div className="relative w-full max-w-md h-44 rounded-xl bg-[#112240]/40 border border-[#F8F9FA]/[0.08] p-4 overflow-hidden hidden sm:block">
            <svg
              className="w-full h-full"
              viewBox="0 0 380 140"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              {/* Subtle background grid lines */}
              <line x1="20" y1="30" x2="360" y2="30" stroke="rgba(248,249,250,0.04)" strokeDasharray="4 4" />
              <line x1="20" y1="70" x2="360" y2="70" stroke="rgba(248,249,250,0.04)" strokeDasharray="4 4" />
              <line x1="20" y1="110" x2="360" y2="110" stroke="rgba(248,249,250,0.04)" />

              {/* Faint rising bars */}
              <rect x="40" y="80" width="16" height="30" rx="3" fill="#112240" stroke="rgba(248,249,250,0.1)" />
              <rect x="75" y="65" width="16" height="45" rx="3" fill="#112240" stroke="rgba(248,249,250,0.1)" />
              <rect x="110" y="72" width="16" height="38" rx="3" fill="#112240" stroke="rgba(248,249,250,0.1)" />
              <rect x="145" y="52" width="16" height="58" rx="3" fill="#112240" stroke="rgba(248,249,250,0.12)" />
              <rect x="180" y="44" width="16" height="66" rx="3" fill="#112240" stroke="rgba(248,249,250,0.15)" />
              <rect x="215" y="32" width="16" height="78" rx="3" fill="#112240" stroke="rgba(255,183,3,0.15)" />
              <rect x="250" y="24" width="16" height="86" rx="3" fill="#112240" stroke="rgba(255,183,3,0.25)" />

              {/* Sweeping growth wave / wing curve */}
              <path
                d="M30 105 Q 90 95, 140 65 T 260 30 T 350 15"
                stroke="rgba(248,249,250,0.2)"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Thin gold accent soaring trajectory */}
              <path
                d="M130 75 Q 200 60, 260 28 T 350 12"
                stroke="#FFB703"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Soaring wing tip glyph at peak */}
              <polygon points="350,12 342,16 345,10" fill="#FFB703" />
              <circle cx="350" cy="12" r="3" fill="#64FFDA" />
            </svg>
            <div className="absolute bottom-2.5 right-3 text-[10px] text-[#F8F9FA]/40 font-mono">
              FINANCIAL FREEDOM TRAJECTORY
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Clean Login Card */}
        <div className="lg:col-span-6">
          <div className="bg-[#112240] border border-[#F8F9FA]/[0.1] rounded-2xl p-6 sm:p-8 shadow-2xl relative">
            
            <div className="mb-6">
              <h2 className="text-2xl font-bold font-display text-[#F8F9FA] tracking-tight">
                Welcome Back
              </h2>
              <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
                Your business journey continues here.
              </p>
            </div>

            {/* Error banner */}
            {errorMessage && (
              <div
                role="alert"
                className="mb-5 p-3.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 leading-relaxed flex items-start gap-2.5"
              >
                <Info className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                <div className="flex-1">
                  <span>{errorMessage}</span>
                  {errorMessage.includes('demo@udaan.app') && (
                    <button
                      type="button"
                      onClick={handleFillCredentials}
                      className="block mt-1.5 font-semibold text-[#FFB703] underline hover:no-underline cursor-pointer"
                    >
                      Autofill demo credentials now
                    </button>
                  )}
                </div>
              </div>
            )}

            <form onSubmit={handleSignIn} className="space-y-4">
              {/* Email / Username */}
              <div>
                <label
                  htmlFor="business-identifier"
                  className="block text-xs font-medium text-[#F8F9FA]/80 mb-1.5"
                >
                  Business email or username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#F8F9FA]/40">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="business-identifier"
                    type="text"
                    autoComplete="username"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="demo@udaan.app"
                    className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-10 pr-4 py-2.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/30 focus:border-[#FFB703] focus:ring-1 focus:ring-[#FFB703] transition-colors"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="business-password"
                    className="block text-xs font-medium text-[#F8F9FA]/80"
                  >
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setModalType('forgot')}
                    className="text-xs text-[#FFB703] hover:text-[#E5A502] transition-colors cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#F8F9FA]/40">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="business-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-[#0A192F] border border-[#F8F9FA]/15 rounded-lg pl-10 pr-11 py-2.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/30 focus:border-[#FFB703] focus:ring-1 focus:ring-[#FFB703] transition-colors font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#F8F9FA]/50 hover:text-[#F8F9FA] transition-colors cursor-pointer"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember me */}
              <div className="flex items-center">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-[#F8F9FA]/20 bg-[#0A192F] text-[#FFB703] focus:ring-[#FFB703] focus:ring-offset-0 cursor-pointer"
                />
                <label
                  htmlFor="remember-me"
                  className="ml-2 text-xs text-[#F8F9FA]/70 cursor-pointer select-none"
                >
                  Remember this device for 30 days
                </label>
              </div>

              {/* Sign In button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-sm transition-all duration-150 flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-70 disabled:cursor-wait"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-[#0A192F]" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span>Signing into Demo Store...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Secondary button: Explore Demo Dashboard */}
              <button
                type="button"
                onClick={handleDirectDemoAccess}
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-lg bg-transparent border border-[#F8F9FA]/20 hover:border-[#FFB703]/60 hover:bg-[#F8F9FA]/[0.03] text-[#F8F9FA] text-xs sm:text-sm font-medium transition-all duration-150 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#FFB703]" />
                <span>Explore Demo Dashboard Directly</span>
              </button>
            </form>

            {/* Demo credentials panel */}
            <div className="mt-6 p-3.5 rounded-lg bg-[#0A192F]/80 border border-[#F8F9FA]/[0.08] text-xs">
              <div className="flex items-center justify-between text-[#FFB703] font-medium mb-1.5">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#64FFDA]" />
                  <span>Demo Credentials</span>
                </span>
                <button
                  type="button"
                  onClick={handleFillCredentials}
                  className="text-[11px] text-[#64FFDA] hover:underline cursor-pointer"
                >
                  Use credentials
                </button>
              </div>
              <div className="text-[#F8F9FA]/75 space-y-0.5 font-mono text-[11px]">
                <div>Email: <strong className="text-[#F8F9FA]">demo@udaan.app</strong></div>
                <div>Password: <strong className="text-[#F8F9FA]">UdaanDemo123</strong></div>
              </div>
              <p className="text-[11px] text-[#F8F9FA]/50 mt-2">
                Demo account — explore UDAAN using sample business data.
              </p>
            </div>

            {/* Create account link & security disclosure */}
            <div className="mt-5 text-center space-y-2">
              <button
                type="button"
                onClick={() => setModalType('signup')}
                className="text-xs text-[#F8F9FA]/70 hover:text-[#FFB703] transition-colors cursor-pointer"
              >
                New to UDAAN? <span className="underline font-medium text-[#F8F9FA]">Create an account</span>
              </button>

              <div className="text-[11px] text-[#F8F9FA]/45 border-t border-[#F8F9FA]/[0.06] pt-3">
                Demonstration login only. Not real authentication. No user data or passwords are transmitted or stored.
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* MODAL: Forgot password or Sign up informative notice */}
      {modalType && (
        <div
          className="fixed inset-0 z-50 bg-[#0A192F]/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#112240] border border-[#FFB703]/30 rounded-xl p-6 max-w-md w-full shadow-2xl relative text-[#F8F9FA]">
            <button
              onClick={() => setModalType(null)}
              className="absolute top-4 right-4 text-[#F8F9FA]/50 hover:text-[#F8F9FA] p-1 rounded-lg"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-10 h-10 rounded-lg bg-[#FFB703]/10 text-[#FFB703] flex items-center justify-center mb-4">
              <Info className="w-5 h-5" />
            </div>

            <h3 className="text-lg font-bold font-display text-[#F8F9FA] mb-2">
              {modalType === 'forgot' ? 'Password Reset Unavailable' : 'Sign Up Disabled in Demo'}
            </h3>

            <p className="text-xs sm:text-sm text-[#F8F9FA]/70 leading-relaxed mb-6">
              {modalType === 'forgot'
                ? "This is a hackathon prototype running on static sample data. Password reset services are not connected. Please use the pre-configured demo credentials: demo@udaan.app / UdaanDemo123."
                : "New business onboarding is disabled in this hackathon demo. You can experience the complete application by logging in with the preloaded 'Demo Store' credentials."}
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setModalType(null)}
                className="px-4 py-2 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors cursor-pointer"
              >
                Understood, Return to Demo
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
