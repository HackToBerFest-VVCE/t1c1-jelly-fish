import React, { useState } from 'react';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import {
  PREDEFINED_QUESTIONS,
  UdaanAnswer,
  DAILY_SALES_30D,
  SAMPLE_PRODUCTS,
} from '../data/sampleData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import {
  Sparkles,
  Send,
  Mic,
  Trash2,
  HelpCircle,
  TrendingUp,
  Package,
  ShoppingBag,
  ArrowRight,
  AlertCircle,
  Clock,
  Bot,
  User,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';

interface ChatMessage {
  id: string;
  sender: 'user' | 'udaan';
  text: string;
  timestamp: string;
  data?: UdaanAnswer;
  isFallback?: boolean;
}

interface AskUdaanProps {
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning', title?: string) => void;
}

const SUGGESTED_CHIPS = [
  'Which product sold the most?',
  "Show me this month's sales.",
  'Which products are running low?',
  'Compare sales this week and last week.',
  'Which products should I reorder?',
];

export const AskUdaan: React.FC<AskUdaanProps> = ({ onShowToast }) => {
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  // Function to match user query to one of the 5 predefined answers
  const findMatchingAnswerKey = (query: string): string | null => {
    const q = query.toLowerCase().trim();

    if (
      q.includes('most') ||
      q.includes('sold the most') ||
      q.includes('best seller') ||
      q.includes('top selling') ||
      q.includes('top product')
    ) {
      return 'most_sold';
    }

    if (
      q.includes('month') ||
      q.includes("this month's sales") ||
      q.includes('total sales') ||
      q.includes('monthly revenue') ||
      q.includes('october')
    ) {
      return 'month_sales';
    }

    if (
      q.includes('low') ||
      q.includes('running low') ||
      q.includes('out of stock') ||
      q.includes('low stock') ||
      q.includes('alerts')
    ) {
      return 'low_stock';
    }

    if (
      q.includes('week') ||
      q.includes('compare') ||
      q.includes('last week') ||
      q.includes('weekly')
    ) {
      return 'week_comparison';
    }

    if (
      q.includes('reorder') ||
      q.includes('should i reorder') ||
      q.includes('purchase') ||
      q.includes('order again')
    ) {
      return 'reorder_products';
    }

    return null;
  };

  const handleAsk = (queryToAsk: string) => {
    const query = queryToAsk.trim();
    if (!query || isThinking) return;

    // Add user message to history
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatHistory((prev) => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);

    const matchKey = findMatchingAnswerKey(query);

    setTimeout(() => {
      setIsThinking(false);

      if (matchKey && PREDEFINED_QUESTIONS[matchKey]) {
        const answer = PREDEFINED_QUESTIONS[matchKey];
        const udaanMsg: ChatMessage = {
          id: `udaan-${Date.now()}`,
          sender: 'udaan',
          text: answer.summaryText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          data: answer,
        };
        setChatHistory((prev) => [...prev, udaanMsg]);
      } else {
        // Fallback response: strictly polite, doesn't hallucinate
        const fallbackMsg: ChatMessage = {
          id: `udaan-${Date.now()}`,
          sender: 'udaan',
          text: 'In this hackathon demo, I can only answer the 5 predefined sample questions grounded in our Kirana store data. Try clicking any of the suggestions below:',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isFallback: true,
        };
        setChatHistory((prev) => [...prev, fallbackMsg]);
      }
    }, 800);
  };

  const handleChipClick = (chip: string) => {
    setInputText(chip);
    handleAsk(chip);
  };

  const handleClear = () => {
    setChatHistory([]);
    setInputText('');
  };

  const handleMicClick = () => {
    onShowToast('Voice input is coming soon in the next release.', 'info', 'Microphone Placeholder');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F8F9FA]/[0.08]">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#FFB703]/10 text-[#FFB703] text-xs font-medium mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Plain Language Business Q&A</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            What would you like to know about your business?
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Ask about your sales, stock replenishment, top-selling goods, or weekly trends.
          </p>
        </div>

        {chatHistory.length > 0 && (
          <button
            onClick={handleClear}
            className="self-start sm:self-center inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#F8F9FA]/15 text-xs text-[#F8F9FA]/70 hover:text-red-300 hover:border-red-400/40 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear conversation</span>
          </button>
        )}
      </div>

      {/* Suggested Question Chips (Always accessible) */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-[#F8F9FA]/60 flex items-center gap-1.5">
          <HelpCircle className="w-3.5 h-3.5 text-[#FFB703]" />
          <span>Suggested queries for Demo Store:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_CHIPS.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleChipClick(chip)}
              disabled={isThinking}
              className="text-xs px-3 py-2 rounded-lg bg-[#112240] border border-[#F8F9FA]/10 hover:border-[#FFB703]/60 hover:text-[#FFB703] text-[#F8F9FA]/80 transition-all duration-150 text-left shadow-sm cursor-pointer disabled:opacity-50"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Primary Input Container */}
      <Card className="p-3 sm:p-4 border-[#FFB703]/30 shadow-lg">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleAsk(inputText);
          }}
          className="space-y-3"
        >
          <div className="relative">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleAsk(inputText);
                }
              }}
              rows={3}
              placeholder="Type your question (e.g. Which product sold the most? or Show me this month's sales)..."
              className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-xl p-3.5 text-sm text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:ring-1 focus:ring-[#FFB703] focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="flex items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={handleMicClick}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0A192F] border border-[#F8F9FA]/15 text-xs text-[#F8F9FA]/70 hover:text-[#64FFDA] hover:border-[#64FFDA]/40 transition-colors cursor-pointer"
              title="Voice recognition is coming in future updates"
              aria-label="Microphone voice input"
            >
              <Mic className="w-4 h-4 text-[#64FFDA]" />
              <span className="hidden sm:inline">Voice Input</span>
            </button>

            <button
              type="submit"
              disabled={!inputText.trim() || isThinking}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#FFB703] hover:bg-[#E5A502] text-[#0A192F] font-semibold text-xs sm:text-sm transition-all duration-150 shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isThinking ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-[#0A192F]" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Thinking...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Ask UDAAN</span>
                </>
              )}
            </button>
          </div>
        </form>
      </Card>

      {/* Chat Conversation History */}
      <div className="space-y-5 pt-2">
        {chatHistory.length === 0 ? (
          <EmptyState
            icon={Bot}
            title="Ask your first business question"
            description="Select any prompt above or type in plain language to analyze sales, discover top earners, check low stock, or compare weekly revenue."
            className="py-12"
          />
        ) : (
          chatHistory.map((msg) => {
            const isUser = msg.sender === 'user';

            if (isUser) {
              return (
                <div key={msg.id} className="flex justify-end gap-3">
                  <div className="max-w-xl bg-[#1B2D4F] border border-[#F8F9FA]/10 text-[#F8F9FA] rounded-2xl rounded-tr-sm p-4 text-sm shadow-sm">
                    <div className="flex items-center justify-between gap-3 text-[11px] text-[#F8F9FA]/50 mb-1">
                      <span className="font-medium text-[#FFB703]">You</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <div>{msg.text}</div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-[#1B2D4F] border border-[#FFB703]/30 text-[#FFB703] flex items-center justify-center shrink-0 text-xs font-semibold">
                    <User className="w-4 h-4" />
                  </div>
                </div>
              );
            }

            // UDAAN Response Card
            return (
              <div key={msg.id} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-[#FFB703] text-[#0A192F] flex items-center justify-center shrink-0 text-xs font-bold shadow-md">
                  <Bot className="w-4 h-4" />
                </div>

                <div className="flex-1 bg-[#112240] border border-[#FFB703]/25 rounded-2xl rounded-tl-sm p-5 space-y-4 shadow-xl">
                  {/* Top bar of answer */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F8F9FA]/[0.08] pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-display font-semibold text-sm text-[#F8F9FA]">
                        UDAAN Assistant
                      </span>
                      <span className="text-[10px] text-[#F8F9FA]/40 font-mono">
                        {msg.timestamp}
                      </span>
                    </div>

                    <Badge variant="gold" size="sm">
                      Demo answer (sample data, no live AI)
                    </Badge>
                  </div>

                  {/* Plain Language Summary */}
                  <p className="text-sm text-[#F8F9FA] leading-relaxed">
                    {msg.text}
                  </p>

                  {/* Fallback chip suggestions if user typed unknown query */}
                  {msg.isFallback && (
                    <div className="pt-2 flex flex-wrap gap-2">
                      {SUGGESTED_CHIPS.map((chip, i) => (
                        <button
                          key={i}
                          onClick={() => handleChipClick(chip)}
                          className="text-xs px-2.5 py-1.5 rounded bg-[#0A192F] border border-[#FFB703]/40 text-[#FFB703] hover:bg-[#FFB703]/10 transition-colors cursor-pointer"
                        >
                          {chip}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Key Metric Highlight if available */}
                  {msg.data?.keyMetricLabel && msg.data?.keyMetricValue && (
                    <div className="p-3.5 rounded-lg bg-[#0A192F] border border-[#64FFDA]/25 flex items-center justify-between gap-3">
                      <span className="text-xs text-[#F8F9FA]/70">
                        {msg.data.keyMetricLabel}
                      </span>
                      <span className="text-sm sm:text-base font-bold font-display text-[#64FFDA] tabular-nums">
                        {msg.data.keyMetricValue}
                      </span>
                    </div>
                  )}

                  {/* Visual Chart / Table for answers */}
                  {msg.data && (
                    <div className="pt-2">
                      {/* Bar chart for top product */}
                      {msg.data.chartType === 'bar' && msg.data.chartData && (
                        <div className="bg-[#0A192F] p-4 rounded-xl border border-[#F8F9FA]/[0.06]">
                          <div className="text-xs font-medium text-[#F8F9FA]/70 mb-3">
                            Volume Comparison by Product (Units Sold)
                          </div>
                          <ResponsiveContainer width="100%" height={200}>
                            <BarChart data={msg.data.chartData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                              <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
                              <XAxis dataKey="name" stroke="rgba(248, 249, 250, 0.4)" fontSize={10} tickLine={false} />
                              <YAxis stroke="rgba(248, 249, 250, 0.4)" fontSize={10} tickLine={false} />
                              <Tooltip
                                contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                                labelStyle={{ color: '#F8F9FA' }}
                                formatter={(val: any, name: any) => [
                                  name === 'units' ? `${val} units` : formatCurrency(val),
                                  name === 'units' ? 'Units' : 'Revenue',
                                ]}
                              />
                              <Bar dataKey="units" fill="#FFB703" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      )}

                      {/* Line chart for this month's sales */}
                      {msg.data.chartType === 'line' && msg.data.chartData && (
                        <div className="bg-[#0A192F] p-4 rounded-xl border border-[#F8F9FA]/[0.06]">
                          <div className="text-xs font-medium text-[#F8F9FA]/70 mb-3 flex items-center justify-between">
                            <span>Daily Sales Curve (30-Day Total: ₹48,250)</span>
                            <span className="text-[#64FFDA]">126 Orders</span>
                          </div>
                          <ResponsiveContainer width="100%" height={200}>
                            <LineChart data={msg.data.chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                              <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
                              <XAxis dataKey="date" stroke="rgba(248, 249, 250, 0.4)" fontSize={10} interval={4} tickLine={false} />
                              <YAxis stroke="rgba(248, 249, 250, 0.4)" fontSize={10} tickLine={false} tickFormatter={(v) => `₹${v}`} />
                              <Tooltip
                                contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                                labelStyle={{ color: '#F8F9FA' }}
                                formatter={(val: any) => [formatCurrency(val), 'Sales']}
                              />
                              <Line type="monotone" dataKey="sales" stroke="#64FFDA" strokeWidth={2} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      )}

                      {/* Grouped bar chart for week-on-week comparison */}
                      {msg.data.chartType === 'grouped-bar' && msg.data.chartData && (
                        <div className="bg-[#0A192F] p-4 rounded-xl border border-[#F8F9FA]/[0.06]">
                          <div className="text-xs font-medium text-[#F8F9FA]/70 mb-3 flex items-center justify-between">
                            <span>Day-by-Day Comparison (This Week vs Last Week)</span>
                            <span className="text-[#64FFDA]">+5.9% Net Growth</span>
                          </div>
                          <ResponsiveContainer width="100%" height={200}>
                            <BarChart data={msg.data.chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                              <CartesianGrid stroke="rgba(248, 249, 250, 0.05)" vertical={false} />
                              <XAxis dataKey="day" stroke="rgba(248, 249, 250, 0.4)" fontSize={10} tickLine={false} />
                              <YAxis stroke="rgba(248, 249, 250, 0.4)" fontSize={10} tickLine={false} tickFormatter={(v) => `₹${v}`} />
                              <Tooltip
                                contentStyle={{ backgroundColor: '#112240', borderColor: '#FFB703', borderRadius: 8 }}
                                labelStyle={{ color: '#F8F9FA' }}
                                formatter={(val: any) => [formatCurrency(val), 'Sales']}
                              />
                              <Legend wrapperStyle={{ fontSize: 11 }} />
                              <Bar name="This Week (₹12,090)" dataKey="thisWeek" fill="#FFB703" radius={[3, 3, 0, 0]} />
                              <Bar name="Last Week (₹11,420)" dataKey="lastWeek" fill="rgba(248, 249, 250, 0.3)" radius={[3, 3, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      )}

                      {/* Table for Low stock or Reorder */}
                      {msg.data.chartType === 'table' && msg.data.tableData && (
                        <div className="bg-[#0A192F] rounded-xl border border-[#F8F9FA]/[0.06] overflow-x-auto">
                          <table className="w-full text-left text-xs whitespace-nowrap">
                            <thead>
                              <tr className="border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 text-[10px] uppercase">
                                <th className="p-2.5">Product</th>
                                <th className="p-2.5">Stock Status</th>
                                <th className="p-2.5">Supplier</th>
                                {msg.data.tableData[0]?.suggestOrder && <th className="p-2.5 text-right">Suggested Order</th>}
                                {msg.data.tableData[0]?.estCost && <th className="p-2.5 text-right">Est. Cost</th>}
                                {msg.data.tableData[0]?.urgency && <th className="p-2.5 text-right">Urgency</th>}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                              {msg.data.tableData.map((row: any, rIdx: number) => (
                                <tr key={rIdx} className="hover:bg-[#F8F9FA]/[0.02]">
                                  <td className="p-2.5 font-medium text-[#F8F9FA]">{row.name}</td>
                                  <td className="p-2.5 font-mono tabular-nums">
                                    <span className="text-[#FFB703] font-bold">
                                      {row.stock ?? row.current}
                                    </span>{' '}
                                    <span className="text-[#F8F9FA]/40">/ {row.reorderLevel} min</span>
                                  </td>
                                  <td className="p-2.5 text-[#F8F9FA]/60">{row.supplier}</td>
                                  {row.suggestOrder && (
                                    <td className="p-2.5 text-right font-bold text-[#64FFDA] tabular-nums">
                                      +{row.suggestOrder} units
                                    </td>
                                  )}
                                  {row.estCost && (
                                    <td className="p-2.5 text-right font-medium text-[#FFB703] tabular-nums">
                                      {formatCurrency(row.estCost)}
                                    </td>
                                  )}
                                  {row.urgency && (
                                    <td className="p-2.5 text-right">
                                      <Badge variant={row.urgency === 'Critical' ? 'critical' : 'low'} size="sm">
                                        {row.urgency}
                                      </Badge>
                                    </td>
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="pt-2 text-[10px] text-[#F8F9FA]/40">
                    * Calculated from 30-day recorded transactions and current inventory counts.
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* Live thinking bubble */}
        {isThinking && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#FFB703] text-[#0A192F] flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-[#112240] border border-[#FFB703]/30 rounded-2xl rounded-tl-sm p-4 text-xs text-[#FFB703] flex items-center gap-2">
              <span className="animate-pulse">Analyzing Kirana store sample dataset...</span>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
