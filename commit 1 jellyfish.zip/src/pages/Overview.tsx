import React, { useState, useMemo } from 'react';
import {
  STORE_HEADLINE_METRICS,
  DAILY_SALES_30D,
  DAILY_SALES_7D,
  SAMPLE_PRODUCTS,
  RECENT_TRANSACTIONS,
  SAMPLE_AI_INSIGHTS,
  Transaction,
} from '../data/sampleData';
import { formatCurrency, formatIndianNumber } from '../utils/formatCurrency';
import { MetricCard } from '../components/MetricCard';
import { ChartCard } from '../components/ChartCard';
import { Card } from '../components/Card';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';
import { AppPage } from '../components/Sidebar';
import {
  IndianRupee,
  ShoppingBag,
  Package,
  AlertTriangle,
  ArrowRight,
  Search,
  Filter,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

interface OverviewProps {
  onNavigate: (page: AppPage) => void;
}

export const Overview: React.FC<OverviewProps> = ({ onNavigate }) => {
  // Chart timeframe toggle: 7D vs 30D
  const [salesTimeframe, setSalesTimeframe] = useState<'7D' | '30D'>('30D');

  // Transaction filters
  const [txnSearch, setTxnSearch] = useState('');
  const [txnStatusFilter, setTxnStatusFilter] = useState<'all' | 'Completed' | 'Pending' | 'Refunded'>('all');

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return RECENT_TRANSACTIONS.filter((txn) => {
      const matchesSearch =
        txn.customerName.toLowerCase().includes(txnSearch.toLowerCase()) ||
        txn.id.toLowerCase().includes(txnSearch.toLowerCase()) ||
        txn.itemsSummary.toLowerCase().includes(txnSearch.toLowerCase());
      const matchesStatus = txnStatusFilter === 'all' || txn.status === txnStatusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [txnSearch, txnStatusFilter]);

  // Low stock products (the 8 low stock items)
  const lowStockProducts = useMemo(() => {
    return SAMPLE_PRODUCTS.filter((p) => p.stockQuantity < p.reorderLevel);
  }, []);

  // Top selling products by volume
  const topProductsByUnits = useMemo(() => {
    return [...SAMPLE_PRODUCTS]
      .sort((a, b) => b.unitsSoldMonth - a.unitsSoldMonth)
      .slice(0, 5)
      .map((p) => ({
        name: p.name.length > 16 ? p.name.slice(0, 14) + '...' : p.name,
        fullName: p.name,
        units: p.unitsSoldMonth,
        revenue: p.revenueMonth,
      }));
  }, []);

  // Sales data depending on 7D vs 30D
  const chartSalesData = salesTimeframe === '7D' ? DAILY_SALES_7D : DAILY_SALES_30D;
  const periodTotalSales = chartSalesData.reduce((acc, curr) => acc + curr.sales, 0);
  const periodTotalOrders = chartSalesData.reduce((acc, curr) => acc + curr.orders, 0);

  // Custom chart tooltip
  const CustomSalesTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#0A192F] border border-[#FFB703]/30 p-2.5 rounded-lg shadow-xl text-xs">
          <div className="font-semibold text-[#F8F9FA] mb-1">{label}</div>
          <div className="text-[#FFB703] font-medium">
            Sales: {formatCurrency(payload[0].value)}
          </div>
          {payload[1] && (
            <div className="text-[#64FFDA] mt-0.5">
              Orders: {payload[1].value}
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const CustomBarTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#0A192F] border border-[#FFB703]/30 p-2.5 rounded-lg shadow-xl text-xs">
          <div className="font-semibold text-[#F8F9FA] mb-1">{data.fullName}</div>
          <div className="text-[#64FFDA]">Volume: {data.units} units sold</div>
          <div className="text-[#FFB703] mt-0.5">Revenue: {formatCurrency(data.revenue)}</div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header section with page title & quick ask prompt */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#F8F9FA]/[0.06]">
        <div>
          <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F8F9FA] tracking-tight">
            Your Business at a Glance
          </h2>
          <p className="text-xs sm:text-sm text-[#F8F9FA]/65 mt-1">
            Clear insights. Smarter decisions. More freedom.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('ask-udaan')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask Business Question</span>
          </button>
        </div>
      </div>

      {/* FOUR HEADLINE METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Sales"
          value={formatCurrency(STORE_HEADLINE_METRICS.totalSales)}
          icon={IndianRupee}
          trendText="+8.4%"
          trendDirection="up"
          subtext="vs last month"
          accent="gold"
          onClick={() => onNavigate('sales-analytics')}
        />
        <MetricCard
          title="Orders"
          value={formatIndianNumber(STORE_HEADLINE_METRICS.totalOrders)}
          icon={ShoppingBag}
          trendText="+12 orders"
          trendDirection="up"
          subtext="30-day volume"
          accent="mint"
          onClick={() => onNavigate('sales-analytics')}
        />
        <MetricCard
          title="Products in Stock"
          value={formatIndianNumber(STORE_HEADLINE_METRICS.productsInStock)}
          icon={Package}
          trendText="12 SKUs"
          trendDirection="neutral"
          subtext="across 6 categories"
          accent="default"
          onClick={() => onNavigate('inventory')}
        />
        <MetricCard
          title="Low Stock Alerts"
          value={`${STORE_HEADLINE_METRICS.lowStockAlerts} Items`}
          icon={AlertTriangle}
          trendText="Attention required"
          trendDirection="warning"
          subtext="below reorder level"
          accent="gold"
          onClick={() => onNavigate('inventory')}
        />
      </div>

      {/* ROW 2: Sales Over Time (Line Chart) + Top Selling Products (Bar Chart) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sales Over Time Chart */}
        <div className="lg:col-span-7">
          <ChartCard
            title="Sales Over Time"
            subtitle={`Showing ${salesTimeframe === '7D' ? 'last 7 days' : 'last 30 days'} · Total: ${formatCurrency(periodTotalSales)} (${periodTotalOrders} orders)`}
            actionSlot={
              <div className="flex items-center gap-1 bg-[#0A192F] p-1 rounded-lg border border-[#F8F9FA]/10">
                <button
                  onClick={() => setSalesTimeframe('7D')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                    salesTimeframe === '7D'
                      ? 'bg-[#FFB703] text-[#0A192F] font-semibold'
                      : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                  }`}
                >
                  7D
                </button>
                <button
                  onClick={() => setSalesTimeframe('30D')}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                    salesTimeframe === '30D'
                      ? 'bg-[#FFB703] text-[#0A192F] font-semibold'
                      : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                  }`}
                >
                  30D
                </button>
              </div>
            }
            footerNote="Data synchronized with October transaction ledger."
          >
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={chartSalesData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid stroke="rgba(248, 249, 250, 0.06)" vertical={false} />
                <XAxis
                  dataKey="date"
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  interval={salesTimeframe === '7D' ? 0 : 4}
                />
                <YAxis
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `₹${val}`}
                />
                <Tooltip content={<CustomSalesTooltip />} />
                <Line
                  type="monotone"
                  dataKey="sales"
                  stroke="#FFB703"
                  strokeWidth={2.5}
                  dot={salesTimeframe === '7D' ? { r: 3.5, fill: '#FFB703' } : false}
                  activeDot={{ r: 5, fill: '#64FFDA' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Top Selling Products */}
        <div className="lg:col-span-5">
          <ChartCard
            title="Top Selling Products"
            subtitle="Ranked by volume of units sold this month"
            actionSlot={
              <button
                onClick={() => onNavigate('sales-analytics')}
                className="text-xs text-[#FFB703] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Full breakdown</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            }
            footerNote="Parle-G leads by volume (75 units); Rice leads by revenue."
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart
                data={topProductsByUnits}
                layout="vertical"
                margin={{ top: 5, right: 10, left: 15, bottom: 5 }}
              >
                <CartesianGrid stroke="rgba(248, 249, 250, 0.06)" horizontal={false} />
                <XAxis
                  type="number"
                  stroke="rgba(248, 249, 250, 0.4)"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(v) => `${v}u`}
                />
                <YAxis
                  dataKey="name"
                  type="category"
                  stroke="rgba(248, 249, 250, 0.7)"
                  fontSize={11}
                  tickLine={false}
                  width={90}
                />
                <Tooltip content={<CustomBarTooltip />} />
                <Bar dataKey="units" fill="#64FFDA" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </div>

      {/* ROW 3: AI Business Insights Panel */}
      <Card className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-[#FFB703]/15 text-[#FFB703] flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[#F8F9FA] tracking-tight">
                AI Business Insights
              </h3>
              <p className="text-xs text-[#F8F9FA]/60">
                Illustrative examples. Live AI analysis is coming later.
              </p>
            </div>
          </div>
          <Badge variant="gold" size="sm">
            Sample insights
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {SAMPLE_AI_INSIGHTS.map((insight) => (
            <div
              key={insight.id}
              className="p-4 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.08] hover:border-[#FFB703]/30 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-[#FFB703]">
                    {insight.category}
                  </span>
                  <Badge
                    variant={insight.impact === 'High' ? 'critical' : insight.impact === 'Growth' ? 'mint' : 'low'}
                    size="sm"
                  >
                    {insight.impact}
                  </Badge>
                </div>
                <h4 className="text-xs font-semibold text-[#F8F9FA] mb-1.5 leading-snug">
                  {insight.title}
                </h4>
                <p className="text-[11px] text-[#F8F9FA]/65 leading-relaxed">
                  {insight.description}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#64FFDA] flex items-center gap-1 font-medium">
                <span>Action:</span>
                <span className="text-[#F8F9FA]/80 truncate">{insight.suggestedAction}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* ROW 4: Low Stock Alerts (The 8 items) & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Low Stock Alerts Panel */}
        <div className="lg:col-span-5">
          <Card className="p-5 h-full flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#FFB703]" />
                <h3 className="text-base font-semibold text-[#F8F9FA]">
                  Low Stock Alerts ({lowStockProducts.length})
                </h3>
              </div>
              <button
                onClick={() => onNavigate('inventory')}
                className="text-xs text-[#FFB703] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Restock all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <p className="text-xs text-[#F8F9FA]/60 mb-3">
              Items currently at or below minimum threshold. Restock recommended.
            </p>

            <div className="space-y-2 flex-1 overflow-y-auto max-h-[380px] pr-1">
              {lowStockProducts.map((product) => {
                const isCritical = product.stockQuantity <= 5;
                return (
                  <div
                    key={product.id}
                    className="p-3 rounded-lg bg-[#0A192F]/60 border border-[#F8F9FA]/[0.06] flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-[#F8F9FA] truncate">
                        {product.name}
                      </div>
                      <div className="text-[11px] text-[#F8F9FA]/50 truncate mt-0.5">
                        Supplier: {product.supplier}
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono tabular-nums text-[#F8F9FA]">
                        <strong className={isCritical ? 'text-red-400' : 'text-[#FFB703]'}>
                          {product.stockQuantity}
                        </strong>{' '}
                        / {product.reorderLevel} min
                      </div>
                      <div className="mt-1">
                        <Badge variant={isCritical ? 'critical' : 'low'} size="sm">
                          {isCritical ? 'Critical' : 'Low'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 pt-3 border-t border-[#F8F9FA]/[0.08] flex items-center justify-between text-xs text-[#F8F9FA]/50">
              <span>8 of 12 items alert triggered</span>
              <button
                onClick={() => onNavigate('inventory')}
                className="text-[#64FFDA] hover:underline cursor-pointer"
              >
                Go to Inventory →
              </button>
            </div>
          </Card>
        </div>

        {/* Recent Transactions Table */}
        <div className="lg:col-span-7">
          <Card className="p-5 flex flex-col h-full">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-semibold text-[#F8F9FA]">
                  Recent Transactions
                </h3>
                <p className="text-xs text-[#F8F9FA]/60 mt-0.5">
                  Latest customer billing across cash, UPI, and card
                </p>
              </div>

              {/* Status filter buttons */}
              <div className="flex items-center gap-1 p-1 bg-[#0A192F] rounded-lg border border-[#F8F9FA]/10">
                {(['all', 'Completed', 'Pending', 'Refunded'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => setTxnStatusFilter(status)}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                      txnStatusFilter === status
                        ? 'bg-[#FFB703] text-[#0A192F] font-semibold'
                        : 'text-[#F8F9FA]/60 hover:text-[#F8F9FA]'
                    }`}
                  >
                    {status === 'all' ? 'All' : status}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Input */}
            <div className="mb-3 relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#F8F9FA]/40" />
              <input
                type="text"
                value={txnSearch}
                onChange={(e) => setTxnSearch(e.target.value)}
                placeholder="Search transaction ID, customer, or items..."
                className="w-full bg-[#0A192F] border border-[#F8F9FA]/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#F8F9FA] placeholder-[#F8F9FA]/40 focus:border-[#FFB703] focus:outline-none"
              />
            </div>

            {/* Table with horizontal scroll */}
            <div className="overflow-x-auto flex-1 min-h-[260px]">
              {filteredTransactions.length === 0 ? (
                <EmptyState
                  title="No transactions found"
                  description="No records match your active search and status filter."
                  actionLabel="Clear Filters"
                  onAction={() => {
                    setTxnSearch('');
                    setTxnStatusFilter('all');
                  }}
                  className="py-8"
                />
              ) : (
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead>
                    <tr className="border-b border-[#F8F9FA]/[0.08] text-[#F8F9FA]/50 uppercase tracking-wider text-[10px]">
                      <th className="py-2.5 px-3">Txn ID</th>
                      <th className="py-2.5 px-3">Customer</th>
                      <th className="py-2.5 px-3">Items Summary</th>
                      <th className="py-2.5 px-3">Payment</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                      <th className="py-2.5 px-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F8F9FA]/[0.04]">
                    {filteredTransactions.map((txn) => (
                      <tr key={txn.id} className="hover:bg-[#F8F9FA]/[0.02] transition-colors">
                        <td className="py-2.5 px-3 font-mono text-[#F8F9FA]/70">{txn.id}</td>
                        <td className="py-2.5 px-3 font-medium text-[#F8F9FA]">{txn.customerName}</td>
                        <td className="py-2.5 px-3 text-[#F8F9FA]/70 max-w-[180px] truncate" title={txn.itemsSummary}>
                          {txn.itemsSummary}
                        </td>
                        <td className="py-2.5 px-3 text-[#F8F9FA]/60">{txn.paymentMethod}</td>
                        <td className="py-2.5 px-3 text-right font-medium tabular-nums text-[#FFB703]">
                          {formatCurrency(txn.amount)}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <Badge
                            variant={
                              txn.status === 'Completed'
                                ? 'success'
                                : txn.status === 'Pending'
                                ? 'pending'
                                : 'refunded'
                            }
                            size="sm"
                          >
                            {txn.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="mt-3 pt-3 border-t border-[#F8F9FA]/[0.06] flex items-center justify-between text-[11px] text-[#F8F9FA]/40">
              <span>Showing {filteredTransactions.length} of {RECENT_TRANSACTIONS.length} transactions</span>
              <span className="font-mono">Demo kirana billing feed</span>
            </div>
          </Card>
        </div>

      </div>

    </div>
  );
};
