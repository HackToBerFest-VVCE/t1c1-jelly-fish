/**
 * UDAAN Sample Business Data
 * Fictional Kirana & Stationery Store: "Demo Store"
 * Note: All figures shown are fictional sample data for hackathon prototype evaluation.
 */

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: 'Grocery & Staples' | 'Dairy & Fats' | 'Beverages' | 'Packaged Foods' | 'Household' | 'Stationery';
  price: number; // in ₹
  costPrice: number; // in ₹
  stockQuantity: number;
  reorderLevel: number;
  supplier: string;
  unitsSoldMonth: number;
  revenueMonth: number;
}

export interface DailySalesRecord {
  dayIndex: number;
  date: string; // "Oct 01"
  fullDate: string; // "2026-10-01"
  sales: number; // in ₹
  orders: number;
}

export interface Transaction {
  id: string;
  customerName: string;
  itemsSummary: string;
  itemCount: number;
  amount: number; // in ₹
  paymentMethod: 'UPI' | 'Cash' | 'Card';
  status: 'Completed' | 'Pending' | 'Refunded';
  time: string;
  date: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  city: string; // Karnataka cities
  productsSupplied: string;
  lastDeliveryDate: string;
  nextDeliveryDate: string;
  status: 'Delivered' | 'In Transit' | 'Delayed' | 'Scheduled';
  rating: number;
}

export interface BusinessInsight {
  id: string;
  title: string;
  description: string;
  impact: 'High' | 'Medium' | 'Growth';
  category: 'Stock' | 'Pricing' | 'Demand';
  suggestedAction: string;
}

export interface StoreProfile {
  name: string;
  ownerName: string;
  email: string;
  phone: string;
  city: string;
  state: string;
  gstin: string;
  currency: string;
  lowStockThresholdPercent: number;
  dailySummaryNotifications: boolean;
  smsAlerts: boolean;
}

// ----------------------------------------------------
// HEADLINE METRICS
// ----------------------------------------------------
export const STORE_HEADLINE_METRICS = {
  totalSales: 48250,
  totalOrders: 126,
  productsInStock: 342,
  lowStockAlerts: 8,
  averageOrderValue: Math.round(48250 / 126), // ₹383
  growthPercent: 8.4,
  salesTrend: '+8.4% vs last month',
  ordersTrend: '+12 orders vs last month',
  inventoryHealth: '8 items need restocking',
};

// ----------------------------------------------------
// DAILY SALES (Sum = ₹48,250 and Orders = 126)
// ----------------------------------------------------
export const DAILY_SALES_30D: DailySalesRecord[] = [
  { dayIndex: 1, date: 'Oct 01', fullDate: '2026-10-01', sales: 1450, orders: 4 },
  { dayIndex: 2, date: 'Oct 02', fullDate: '2026-10-02', sales: 1200, orders: 3 },
  { dayIndex: 3, date: 'Oct 03', fullDate: '2026-10-03', sales: 1680, orders: 4 },
  { dayIndex: 4, date: 'Oct 04', fullDate: '2026-10-04', sales: 950, orders: 3 },
  { dayIndex: 5, date: 'Oct 05', fullDate: '2026-10-05', sales: 1820, orders: 5 },
  { dayIndex: 6, date: 'Oct 06', fullDate: '2026-10-06', sales: 2100, orders: 6 },
  { dayIndex: 7, date: 'Oct 07', fullDate: '2026-10-07', sales: 1540, orders: 4 },
  { dayIndex: 8, date: 'Oct 08', fullDate: '2026-10-08', sales: 1350, orders: 4 },
  { dayIndex: 9, date: 'Oct 09', fullDate: '2026-10-09', sales: 1100, orders: 3 },
  { dayIndex: 10, date: 'Oct 10', fullDate: '2026-10-10', sales: 1600, orders: 4 },
  { dayIndex: 11, date: 'Oct 11', fullDate: '2026-10-11', sales: 1420, orders: 4 },
  { dayIndex: 12, date: 'Oct 12', fullDate: '2026-10-12', sales: 1950, orders: 5 },
  { dayIndex: 13, date: 'Oct 13', fullDate: '2026-10-13', sales: 2250, orders: 6 },
  { dayIndex: 14, date: 'Oct 14', fullDate: '2026-10-14', sales: 1780, orders: 5 },
  { dayIndex: 15, date: 'Oct 15', fullDate: '2026-10-15', sales: 1300, orders: 3 },
  { dayIndex: 16, date: 'Oct 16', fullDate: '2026-10-16', sales: 1250, orders: 3 },
  { dayIndex: 17, date: 'Oct 17', fullDate: '2026-10-17', sales: 1480, orders: 4 },
  { dayIndex: 18, date: 'Oct 18', fullDate: '2026-10-18', sales: 1620, orders: 4 },
  { dayIndex: 19, date: 'Oct 19', fullDate: '2026-10-19', sales: 1900, orders: 5 },
  { dayIndex: 20, date: 'Oct 20', fullDate: '2026-10-20', sales: 2150, orders: 6 },
  { dayIndex: 21, date: 'Oct 21', fullDate: '2026-10-21', sales: 1520, orders: 4 },
  { dayIndex: 22, date: 'Oct 22', fullDate: '2026-10-22', sales: 1400, orders: 4 },
  { dayIndex: 23, date: 'Oct 23', fullDate: '2026-10-23', sales: 1350, orders: 3 },
  { dayIndex: 24, date: 'Oct 24', fullDate: '2026-10-24', sales: 1580, orders: 4 },
  { dayIndex: 25, date: 'Oct 25', fullDate: '2026-10-25', sales: 1420, orders: 4 },
  { dayIndex: 26, date: 'Oct 26', fullDate: '2026-10-26', sales: 1850, orders: 5 },
  { dayIndex: 27, date: 'Oct 27', fullDate: '2026-10-27', sales: 2350, orders: 6 },
  { dayIndex: 28, date: 'Oct 28', fullDate: '2026-10-28', sales: 1640, orders: 4 },
  { dayIndex: 29, date: 'Oct 29', fullDate: '2026-10-29', sales: 1550, orders: 4 },
  { dayIndex: 30, date: 'Oct 30', fullDate: '2026-10-30', sales: 1700, orders: 3 },
];

// Last 7 days slice (Days 24-30): Sum = ₹12,090, Orders = 30
export const DAILY_SALES_7D = DAILY_SALES_30D.slice(-7);

// 6 Months Historical Overview
export const MONTHLY_SALES_6M = [
  { month: 'May 2026', sales: 39500, orders: 104, profit: 9800 },
  { month: 'Jun 2026', sales: 41200, orders: 110, profit: 10400 },
  { month: 'Jul 2026', sales: 43800, orders: 115, profit: 11200 },
  { month: 'Aug 2026', sales: 42100, orders: 108, profit: 10600 },
  { month: 'Sep 2026', sales: 44500, orders: 114, profit: 11500 },
  { month: 'Oct 2026 (Current)', sales: 48250, orders: 126, profit: 12650 },
];

// ----------------------------------------------------
// PRODUCTS (12 Products, exactly 8 below reorder level)
// Sum of stockQuantity = 342
// ----------------------------------------------------
export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'prod-01',
    sku: 'GR-RIC-001',
    name: 'Basmati Rice 5kg',
    category: 'Grocery & Staples',
    price: 450,
    costPrice: 380,
    stockQuantity: 4,
    reorderLevel: 10,
    supplier: 'Sri Lakshmi Traders',
    unitsSoldMonth: 24,
    revenueMonth: 10800,
  },
  {
    id: 'prod-02',
    sku: 'GR-DAL-002',
    name: 'Toor Dal 1kg',
    category: 'Grocery & Staples',
    price: 160,
    costPrice: 130,
    stockQuantity: 6,
    reorderLevel: 15,
    supplier: 'Mysuru Agro Foods',
    unitsSoldMonth: 32,
    revenueMonth: 5120,
  },
  {
    id: 'prod-03',
    sku: 'GR-OIL-003',
    name: 'Sunflower Oil 1L',
    category: 'Grocery & Staples',
    price: 140,
    costPrice: 115,
    stockQuantity: 5,
    reorderLevel: 12,
    supplier: 'Kaveri Dairy & Provisions',
    unitsSoldMonth: 38,
    revenueMonth: 5320,
  },
  {
    id: 'prod-04',
    sku: 'BV-TEA-004',
    name: 'Tata Tea Gold 500g',
    category: 'Beverages',
    price: 280,
    costPrice: 235,
    stockQuantity: 7,
    reorderLevel: 12,
    supplier: 'Malnad Spices & Commodities',
    unitsSoldMonth: 22,
    revenueMonth: 6160,
  },
  {
    id: 'prod-05',
    sku: 'PF-BIS-005',
    name: 'Parle-G Biscuits (pack)',
    category: 'Packaged Foods',
    price: 30,
    costPrice: 24,
    stockQuantity: 18,
    reorderLevel: 40,
    supplier: 'Sri Lakshmi Traders',
    unitsSoldMonth: 75,
    revenueMonth: 2250,
  },
  {
    id: 'prod-06',
    sku: 'DF-BUT-006',
    name: 'Amul Butter 500g',
    category: 'Dairy & Fats',
    price: 275,
    costPrice: 240,
    stockQuantity: 3,
    reorderLevel: 8,
    supplier: 'Kaveri Dairy & Provisions',
    unitsSoldMonth: 16,
    revenueMonth: 4400,
  },
  {
    id: 'prod-07',
    sku: 'ST-NOT-007',
    name: 'Notebook A4 (pack of 6)',
    category: 'Stationery',
    price: 240,
    costPrice: 180,
    stockQuantity: 5,
    reorderLevel: 15,
    supplier: 'Vidya Stationery Mart',
    unitsSoldMonth: 14,
    revenueMonth: 3360,
  },
  {
    id: 'prod-08',
    sku: 'ST-PEN-008',
    name: 'Ball Pens (box of 10)',
    category: 'Stationery',
    price: 100,
    costPrice: 70,
    stockQuantity: 8,
    reorderLevel: 20,
    supplier: 'Vidya Stationery Mart',
    unitsSoldMonth: 25,
    revenueMonth: 2500,
  },
  {
    id: 'prod-09',
    sku: 'HH-DET-009',
    name: 'Detergent Powder 2kg',
    category: 'Household',
    price: 220,
    costPrice: 175,
    stockQuantity: 45,
    reorderLevel: 15,
    supplier: 'Chamundi FMCG Distributors',
    unitsSoldMonth: 10,
    revenueMonth: 2200,
  },
  {
    id: 'prod-10',
    sku: 'HH-SOP-010',
    name: 'Bathing Soap (pack of 4)',
    category: 'Household',
    price: 150,
    costPrice: 120,
    stockQuantity: 60,
    reorderLevel: 20,
    supplier: 'Chamundi FMCG Distributors',
    unitsSoldMonth: 15,
    revenueMonth: 2250,
  },
  {
    id: 'prod-11',
    sku: 'PF-NOD-011',
    name: 'Maggi Noodles (pack of 12)',
    category: 'Packaged Foods',
    price: 168,
    costPrice: 140,
    stockQuantity: 82,
    reorderLevel: 30,
    supplier: 'Sri Lakshmi Traders',
    unitsSoldMonth: 15,
    revenueMonth: 2520,
  },
  {
    id: 'prod-12',
    sku: 'GR-SUG-012',
    name: 'Sugar 1kg',
    category: 'Grocery & Staples',
    price: 48,
    costPrice: 38,
    stockQuantity: 99,
    reorderLevel: 35,
    supplier: 'Mysuru Agro Foods',
    unitsSoldMonth: 28,
    revenueMonth: 1344,
  },
];

// ----------------------------------------------------
// CATEGORY BREAKDOWN
// ----------------------------------------------------
export const CATEGORY_SALES_BREAKDOWN = [
  { name: 'Grocery & Staples', sales: 22584, percentage: 46.8 },
  { name: 'Beverages', sales: 6160, percentage: 12.8 },
  { name: 'Stationery', sales: 5860, percentage: 12.1 },
  { name: 'Packaged Foods', sales: 4770, percentage: 9.9 },
  { name: 'Household', sales: 4450, percentage: 9.2 },
  { name: 'Dairy & Fats', sales: 4400, percentage: 9.1 },
];

// ----------------------------------------------------
// RECENT TRANSACTIONS (11 realistic transactions)
// ----------------------------------------------------
export const RECENT_TRANSACTIONS: Transaction[] = [
  {
    id: 'TXN-9041',
    customerName: 'Aarav',
    itemsSummary: 'Basmati Rice 5kg, Sugar 1kg',
    itemCount: 2,
    amount: 498,
    paymentMethod: 'UPI',
    status: 'Completed',
    time: '11:42 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9040',
    customerName: 'Priya',
    itemsSummary: 'Sunflower Oil 1L, Parle-G (2)',
    itemCount: 3,
    amount: 200,
    paymentMethod: 'UPI',
    status: 'Completed',
    time: '11:15 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9039',
    customerName: 'Rohan',
    itemsSummary: 'Notebook A4 (pack of 6), Ball Pens',
    itemCount: 2,
    amount: 340,
    paymentMethod: 'Cash',
    status: 'Completed',
    time: '10:50 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9038',
    customerName: 'Ananya',
    itemsSummary: 'Tata Tea Gold 500g, Amul Butter',
    itemCount: 2,
    amount: 555,
    paymentMethod: 'Card',
    status: 'Completed',
    time: '10:20 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9037',
    customerName: 'Vikram',
    itemsSummary: 'Detergent Powder 2kg',
    itemCount: 1,
    amount: 220,
    paymentMethod: 'UPI',
    status: 'Completed',
    time: '09:45 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9036',
    customerName: 'Sneha',
    itemsSummary: 'Maggi Noodles (pack of 12)',
    itemCount: 1,
    amount: 168,
    paymentMethod: 'UPI',
    status: 'Pending',
    time: '09:12 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9035',
    customerName: 'Rajesh',
    itemsSummary: 'Toor Dal 1kg, Sugar 1kg (2)',
    itemCount: 3,
    amount: 256,
    paymentMethod: 'Cash',
    status: 'Completed',
    time: '08:50 AM',
    date: 'Today',
  },
  {
    id: 'TXN-9034',
    customerName: 'Kavita',
    itemsSummary: 'Bathing Soap (pack of 4)',
    itemCount: 1,
    amount: 150,
    paymentMethod: 'UPI',
    status: 'Completed',
    time: 'Yesterday',
    date: 'Oct 24',
  },
  {
    id: 'TXN-9033',
    customerName: 'Deepak',
    itemsSummary: 'Basmati Rice 5kg, Tata Tea Gold',
    itemCount: 2,
    amount: 730,
    paymentMethod: 'Card',
    status: 'Completed',
    time: 'Yesterday',
    date: 'Oct 24',
  },
  {
    id: 'TXN-9032',
    customerName: 'Pooja',
    itemsSummary: 'Parle-G Biscuits (4 packs)',
    itemCount: 4,
    amount: 120,
    paymentMethod: 'Cash',
    status: 'Refunded',
    time: 'Yesterday',
    date: 'Oct 24',
  },
  {
    id: 'TXN-9031',
    customerName: 'Meera',
    itemsSummary: 'Sunflower Oil 1L, Toor Dal 1kg',
    itemCount: 2,
    amount: 300,
    paymentMethod: 'UPI',
    status: 'Completed',
    time: 'Yesterday',
    date: 'Oct 24',
  },
];

// ----------------------------------------------------
// SUPPLIERS (6 Karnataka-based suppliers)
// ----------------------------------------------------
export const SAMPLE_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-01',
    name: 'Sri Lakshmi Traders',
    contactPerson: 'Ramesh Gowda',
    phone: '+91 98450 23110',
    city: 'Bengaluru',
    productsSupplied: 'Basmati Rice, Parle-G, Maggi Noodles',
    lastDeliveryDate: '20 Oct 2026',
    nextDeliveryDate: '28 Oct 2026',
    status: 'Scheduled',
    rating: 4.8,
  },
  {
    id: 'sup-02',
    name: 'Mysuru Agro Foods',
    contactPerson: 'Suresh Hegde',
    phone: '+91 94481 87340',
    city: 'Mysuru',
    productsSupplied: 'Toor Dal, Sugar, Pulses',
    lastDeliveryDate: '15 Oct 2026',
    nextDeliveryDate: '26 Oct 2026',
    status: 'In Transit',
    rating: 4.6,
  },
  {
    id: 'sup-03',
    name: 'Kaveri Dairy & Provisions',
    contactPerson: 'Manjunath K',
    phone: '+91 97412 55901',
    city: 'Mandya',
    productsSupplied: 'Amul Butter, Sunflower Oil, Ghee',
    lastDeliveryDate: '23 Oct 2026',
    nextDeliveryDate: '29 Oct 2026',
    status: 'Delivered',
    rating: 4.9,
  },
  {
    id: 'sup-04',
    name: 'Chamundi FMCG Distributors',
    contactPerson: 'Anita Patil',
    phone: '+91 93420 11988',
    city: 'Hubballi',
    productsSupplied: 'Detergents, Soaps, Household Cleaning',
    lastDeliveryDate: '12 Oct 2026',
    nextDeliveryDate: '27 Oct 2026',
    status: 'Delayed',
    rating: 4.2,
  },
  {
    id: 'sup-05',
    name: 'Vidya Stationery Mart',
    contactPerson: 'Venkatesh Murthy',
    phone: '+91 98801 44321',
    city: 'Bengaluru',
    productsSupplied: 'Notebooks, Pens, General Stationery',
    lastDeliveryDate: '18 Oct 2026',
    nextDeliveryDate: '30 Oct 2026',
    status: 'Scheduled',
    rating: 4.7,
  },
  {
    id: 'sup-06',
    name: 'Malnad Spices & Commodities',
    contactPerson: 'Raghavendra Rao',
    phone: '+91 94812 66750',
    city: 'Shivamogga',
    productsSupplied: 'Tata Tea Gold, Spices, Filter Coffee',
    lastDeliveryDate: '22 Oct 2026',
    nextDeliveryDate: '31 Oct 2026',
    status: 'Delivered',
    rating: 4.9,
  },
];

// ----------------------------------------------------
// AI BUSINESS INSIGHTS (sample recommendations)
// ----------------------------------------------------
export const SAMPLE_AI_INSIGHTS: BusinessInsight[] = [
  {
    id: 'ins-01',
    title: 'Critical Stock: Basmati Rice & Amul Butter',
    description: 'Basmati Rice has 4 packs left (avg sales 6/week). You risk stockout within 48 hours before the weekend rush.',
    impact: 'High',
    category: 'Stock',
    suggestedAction: 'Order 15 packs from Sri Lakshmi Traders today.',
  },
  {
    id: 'ins-02',
    title: 'Top Revenue Driver: Basmati Rice 5kg',
    description: 'Generated ₹10,800 (22.4% of total store revenue) this month. Consider featuring it near checkout.',
    impact: 'Growth',
    category: 'Demand',
    suggestedAction: 'Create a combo offer with Toor Dal to boost basket size.',
  },
  {
    id: 'ins-03',
    title: 'Stationery Demand Surge Detected',
    description: 'Notebooks and Ball Pens reached 39 units sold. Notebook stock has dropped to 5 packs against reorder level 15.',
    impact: 'Medium',
    category: 'Stock',
    suggestedAction: 'Place reorder with Vidya Stationery Mart before exams rush.',
  },
  {
    id: 'ins-04',
    title: 'Delayed Shipment Alert: Chamundi FMCG',
    description: 'Scheduled delivery for household soaps & detergents is marked delayed by 2 days.',
    impact: 'Medium',
    category: 'Pricing',
    suggestedAction: 'Follow up with Anita Patil (+91 93420 11988) for revised transit ETA.',
  },
];

// ----------------------------------------------------
// DEFAULT STORE PROFILE
// ----------------------------------------------------
export const DEFAULT_STORE_PROFILE: StoreProfile = {
  name: 'Demo Store',
  ownerName: 'Suresh Kumar',
  email: 'demo@udaan.app',
  phone: '+91 98450 12345',
  city: 'Bengaluru',
  state: 'Karnataka',
  gstin: '29AAAAA0000A1Z5',
  currency: 'INR (₹)',
  lowStockThresholdPercent: 20,
  dailySummaryNotifications: true,
  smsAlerts: false,
};

// ----------------------------------------------------
// PRE-DEFINED QUESTIONS & STRUCTURED ANSWERS FOR ASK UDAAN
// ----------------------------------------------------
export interface UdaanAnswer {
  question: string;
  summaryText: string;
  keyMetricLabel?: string;
  keyMetricValue?: string;
  chartType?: 'bar' | 'line' | 'grouped-bar' | 'table';
  chartData?: any;
  tableData?: any;
}

export const PREDEFINED_QUESTIONS: Record<string, UdaanAnswer> = {
  most_sold: {
    question: 'Which product sold the most?',
    summaryText: 'Parle-G Biscuits (pack) is your top product by sales volume with 75 units sold this month. In terms of overall revenue, Basmati Rice 5kg generated the highest turnover at ₹10,800 across 24 units.',
    keyMetricLabel: 'Top Volume Product',
    keyMetricValue: 'Parle-G Biscuits (75 units)',
    chartType: 'bar',
    chartData: [
      { name: 'Parle-G Biscuits', units: 75, revenue: 2250 },
      { name: 'Sunflower Oil 1L', units: 38, revenue: 5320 },
      { name: 'Toor Dal 1kg', units: 32, revenue: 5120 },
      { name: 'Sugar 1kg', units: 28, revenue: 1344 },
      { name: 'Ball Pens (box)', units: 25, revenue: 2500 },
      { name: 'Basmati Rice 5kg', units: 24, revenue: 10800 },
    ],
  },
  month_sales: {
    question: "Show me this month's sales.",
    summaryText: 'Total sales for this month (October 2026) stand at ₹48,250 across 126 completed customer orders. Average order value is ₹383, representing an 8.4% increase over September sales (₹44,500).',
    keyMetricLabel: 'Total October Sales',
    keyMetricValue: '₹48,250 (126 Orders)',
    chartType: 'line',
    chartData: DAILY_SALES_30D.map((d) => ({
      date: d.date,
      sales: d.sales,
      orders: d.orders,
    })),
  },
  low_stock: {
    question: 'Which products are running low?',
    summaryText: 'You have exactly 8 products below their safe reorder levels. Amul Butter (3 units left) and Basmati Rice (4 units left) are at critical emergency levels and should be reordered immediately.',
    keyMetricLabel: 'Low Stock Alerts',
    keyMetricValue: '8 Products Below Safe Level',
    chartType: 'table',
    tableData: SAMPLE_PRODUCTS.filter((p) => p.stockQuantity < p.reorderLevel).map((p) => ({
      name: p.name,
      stock: p.stockQuantity,
      reorderLevel: p.reorderLevel,
      shortfall: p.reorderLevel - p.stockQuantity,
      supplier: p.supplier,
      urgency: p.stockQuantity <= 5 ? 'Critical' : 'Low',
    })),
  },
  week_comparison: {
    question: 'Compare sales this week and last week.',
    summaryText: 'This week (Days 24–30) your store clocked ₹12,090 across 30 orders, compared to ₹11,420 across 30 orders in the previous week (Days 17–23). That is a solid growth of +₹670 (+5.9%) with identical order volume, reflecting higher basket value.',
    keyMetricLabel: 'Week-on-Week Growth',
    keyMetricValue: '+5.9% (+₹670)',
    chartType: 'grouped-bar',
    chartData: [
      { day: 'Day 1', thisWeek: 1580, lastWeek: 1480 },
      { day: 'Day 2', thisWeek: 1420, lastWeek: 1620 },
      { day: 'Day 3', thisWeek: 1850, lastWeek: 1900 },
      { day: 'Day 4', thisWeek: 2350, lastWeek: 2150 },
      { day: 'Day 5', thisWeek: 1640, lastWeek: 1520 },
      { day: 'Day 6', thisWeek: 1550, lastWeek: 1400 },
      { day: 'Day 7', thisWeek: 1700, lastWeek: 1350 },
    ],
  },
  reorder_products: {
    question: 'Which products should I reorder?',
    summaryText: 'Based on your sales velocity and supplier lead times, here is your suggested reorder plan for the 8 low-stock items. Total estimated reorder cost is ₹14,240 across 4 suppliers.',
    keyMetricLabel: 'Suggested Reorder Units',
    keyMetricValue: '113 Units (Est. ₹14,240)',
    chartType: 'table',
    tableData: [
      { name: 'Basmati Rice 5kg', current: 4, reorderLevel: 10, suggestOrder: 15, supplier: 'Sri Lakshmi Traders', estCost: 5700 },
      { name: 'Toor Dal 1kg', current: 6, reorderLevel: 15, suggestOrder: 20, supplier: 'Mysuru Agro Foods', estCost: 2600 },
      { name: 'Sunflower Oil 1L', current: 5, reorderLevel: 12, suggestOrder: 15, supplier: 'Kaveri Dairy & Provisions', estCost: 1725 },
      { name: 'Tata Tea Gold 500g', current: 7, reorderLevel: 12, suggestOrder: 10, supplier: 'Malnad Spices & Commodities', estCost: 2350 },
      { name: 'Parle-G Biscuits (pack)', current: 18, reorderLevel: 40, suggestOrder: 35, supplier: 'Sri Lakshmi Traders', estCost: 840 },
      { name: 'Amul Butter 500g', current: 3, reorderLevel: 8, suggestOrder: 8, supplier: 'Kaveri Dairy & Provisions', estCost: 1920 },
      { name: 'Notebook A4 (pack of 6)', current: 5, reorderLevel: 15, suggestOrder: 15, supplier: 'Vidya Stationery Mart', estCost: 2700 },
      { name: 'Ball Pens (box of 10)', current: 8, reorderLevel: 20, suggestOrder: 20, supplier: 'Vidya Stationery Mart', estCost: 1400 },
    ],
  },
};
