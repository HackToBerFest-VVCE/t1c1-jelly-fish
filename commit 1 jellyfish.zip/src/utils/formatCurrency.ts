/**
 * Formats a number as Indian Currency (INR) with the standard Indian digit grouping:
 * e.g. 48250 -> ₹48,250 and 124500 -> ₹1,24,500
 */
export function formatCurrency(amount: number): string {
  if (isNaN(amount)) return '₹0';
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

/**
 * Formats a number with Indian digit grouping without the currency sign:
 * e.g. 124500 -> 1,24,500
 */
export function formatIndianNumber(num: number): string {
  if (isNaN(num)) return '0';
  return num.toLocaleString('en-IN');
}

/**
 * Formats percentage change with sign:
 * e.g. 12.4 -> +12.4%
 */
export function formatPercentChange(change: number): string {
  const sign = change > 0 ? '+' : '';
  return `${sign}${change.toFixed(1)}%`;
}
