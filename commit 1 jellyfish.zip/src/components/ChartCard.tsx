import React from 'react';
import { Card } from './Card';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  actionSlot?: React.ReactNode;
  children: React.ReactNode;
  footerNote?: string;
  className?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  title,
  subtitle,
  actionSlot,
  children,
  footerNote,
  className = '',
}) => {
  return (
    <Card className={`p-5 flex flex-col ${className}`}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-semibold text-[#F8F9FA] tracking-tight">
            {title}
          </h3>
          {subtitle && (
            <p className="text-xs text-[#F8F9FA]/60 mt-0.5">{subtitle}</p>
          )}
        </div>
        {actionSlot && <div className="shrink-0">{actionSlot}</div>}
      </div>

      <div className="w-full flex-1 min-h-[220px]">{children}</div>

      {footerNote && (
        <div className="mt-3 pt-3 border-t border-[#F8F9FA]/[0.06] text-[11px] text-[#F8F9FA]/40 flex items-center justify-between">
          <span>{footerNote}</span>
          <span className="text-[#FFB703]/80">Demo / Sample Data</span>
        </div>
      )}
    </Card>
  );
};
