import React from 'react';
import { LucideIcon, Search, PackageOpen } from 'lucide-react';

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = PackageOpen,
  title,
  description,
  actionLabel,
  onAction,
  className = '',
}) => {
  return (
    <div
      className={`p-8 sm:p-12 text-center flex flex-col items-center justify-center bg-[#112240]/50 rounded-xl border border-dashed border-[#F8F9FA]/10 ${className}`}
    >
      <div className="w-12 h-12 rounded-full bg-[#F8F9FA]/5 flex items-center justify-center text-[#FFB703] mb-4">
        <Icon className="w-6 h-6" />
      </div>
      <h4 className="text-base font-semibold text-[#F8F9FA]">{title}</h4>
      <p className="text-xs sm:text-sm text-[#F8F9FA]/60 max-w-sm mt-1.5 mb-5 leading-relaxed">
        {description}
      </p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-4 py-2 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors cursor-pointer"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
};
