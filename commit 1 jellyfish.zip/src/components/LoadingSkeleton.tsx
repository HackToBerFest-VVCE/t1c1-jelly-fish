import React from 'react';

interface LoadingSkeletonProps {
  type?: 'card' | 'table' | 'chart' | 'lines';
  count?: number;
  className?: string;
}

export const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({
  type = 'card',
  count = 1,
  className = '',
}) => {
  const items = Array.from({ length: count });

  if (type === 'lines') {
    return (
      <div className={`space-y-3 animate-pulse ${className}`} role="status" aria-label="Loading content">
        <div className="h-4 bg-[#F8F9FA]/10 rounded w-3/4" />
        <div className="h-3 bg-[#F8F9FA]/5 rounded w-full" />
        <div className="h-3 bg-[#F8F9FA]/5 rounded w-5/6" />
      </div>
    );
  }

  if (type === 'table') {
    return (
      <div className={`animate-pulse space-y-3 ${className}`} role="status" aria-label="Loading table">
        <div className="h-9 bg-[#112240] rounded-lg border border-[#F8F9FA]/5" />
        {items.map((_, i) => (
          <div key={i} className="h-12 bg-[#112240]/60 rounded-lg border border-[#F8F9FA]/5 flex items-center px-4 gap-4">
            <div className="w-1/4 h-3.5 bg-[#F8F9FA]/10 rounded" />
            <div className="w-1/6 h-3 bg-[#F8F9FA]/5 rounded" />
            <div className="w-1/6 h-3 bg-[#F8F9FA]/5 rounded" />
            <div className="w-1/4 h-3 bg-[#F8F9FA]/5 rounded ml-auto" />
          </div>
        ))}
      </div>
    );
  }

  if (type === 'chart') {
    return (
      <div className={`h-64 bg-[#112240] rounded-xl border border-[#F8F9FA]/5 p-5 animate-pulse flex flex-col justify-between ${className}`} role="status" aria-label="Loading chart">
        <div className="h-4 bg-[#F8F9FA]/10 rounded w-48" />
        <div className="h-36 bg-[#F8F9FA]/5 rounded-lg w-full" />
        <div className="h-3 bg-[#F8F9FA]/5 rounded w-32" />
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 ${className}`} role="status" aria-label="Loading metric cards">
      {items.map((_, i) => (
        <div key={i} className="h-32 bg-[#112240] rounded-xl border border-[#F8F9FA]/5 p-5 animate-pulse flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <div className="h-3 bg-[#F8F9FA]/10 rounded w-24" />
            <div className="w-8 h-8 rounded-lg bg-[#F8F9FA]/10" />
          </div>
          <div className="h-7 bg-[#F8F9FA]/15 rounded w-32" />
          <div className="h-2.5 bg-[#F8F9FA]/5 rounded w-20" />
        </div>
      ))}
    </div>
  );
};
