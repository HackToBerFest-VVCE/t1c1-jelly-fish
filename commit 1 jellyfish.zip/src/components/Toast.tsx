import React from 'react';
import { Info, CheckCircle2, AlertCircle, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type?: 'info' | 'success' | 'warning';
  title?: string;
  message: string;
}

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none"
      role="region"
      aria-label="Notifications"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-start gap-3 p-3.5 rounded-lg bg-[#112240] border border-[#FFB703]/30 text-[#F8F9FA] shadow-xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 duration-200"
          role="status"
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-[#64FFDA] shrink-0 mt-0.5" />
          ) : toast.type === 'warning' ? (
            <AlertCircle className="w-4 h-4 text-[#FFB703] shrink-0 mt-0.5" />
          ) : (
            <Info className="w-4 h-4 text-[#64FFDA] shrink-0 mt-0.5" />
          )}

          <div className="flex-1 text-xs">
            {toast.title && <div className="font-semibold text-[#F8F9FA] mb-0.5">{toast.title}</div>}
            <div className="text-[#F8F9FA]/80 leading-relaxed">{toast.message}</div>
          </div>

          <button
            onClick={() => onDismiss(toast.id)}
            className="text-[#F8F9FA]/40 hover:text-[#F8F9FA] p-0.5 rounded cursor-pointer"
            aria-label="Close notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
