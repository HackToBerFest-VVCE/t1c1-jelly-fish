import React from 'react';
import { Logo } from './Logo';
import {
  LayoutDashboard,
  MessageSquareText,
  TrendingUp,
  Package,
  Truck,
  Settings,
  LogOut,
  X,
  Store,
} from 'lucide-react';

export type AppPage =
  | 'overview'
  | 'ask-udaan'
  | 'sales-analytics'
  | 'inventory'
  | 'suppliers'
  | 'settings';

interface SidebarProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  onLogout: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  onLogout,
  mobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    { id: 'overview' as AppPage, label: 'Overview', icon: LayoutDashboard },
    { id: 'ask-udaan' as AppPage, label: 'Ask UDAAN', icon: MessageSquareText, highlight: true },
    { id: 'sales-analytics' as AppPage, label: 'Sales Analytics', icon: TrendingUp },
    { id: 'inventory' as AppPage, label: 'Inventory', icon: Package },
    { id: 'suppliers' as AppPage, label: 'Suppliers', icon: Truck },
    { id: 'settings' as AppPage, label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (page: AppPage) => {
    onNavigate(page);
    onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-[#112240] border-r border-[#F8F9FA]/[0.08] text-[#F8F9FA]">
      {/* Brand header */}
      <div className="p-5 flex items-center justify-between border-b border-[#F8F9FA]/[0.08]">
        <Logo size="md" showWordmark={true} tagline={true} />
        <button
          onClick={onCloseMobile}
          className="lg:hidden text-[#F8F9FA]/60 hover:text-[#F8F9FA] p-1.5 rounded-lg focus-visible:outline-none"
          aria-label="Close navigation sidebar"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Store context identifier */}
      <div className="px-5 py-3.5 bg-[#0A192F]/60 border-b border-[#F8F9FA]/[0.06] flex items-center gap-3">
        <div className="w-7 h-7 rounded-md bg-[#FFB703]/10 text-[#FFB703] flex items-center justify-center shrink-0">
          <Store className="w-4 h-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-xs font-semibold text-[#F8F9FA] truncate">Demo Store</div>
          <div className="text-[11px] text-[#F8F9FA]/50 truncate">Kirana & Stationery</div>
        </div>
        <span className="text-[10px] font-mono tracking-wider px-1.5 py-0.5 rounded bg-[#64FFDA]/15 text-[#64FFDA] border border-[#64FFDA]/30">
          DEMO
        </span>
      </div>

      {/* Nav links */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto" aria-label="Main Navigation">
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 cursor-pointer text-left ${
                isActive
                  ? 'bg-[#FFB703] text-[#0A192F] font-semibold shadow-sm'
                  : 'text-[#F8F9FA]/75 hover:text-[#F8F9FA] hover:bg-[#F8F9FA]/[0.05]'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-[#0A192F]' : item.highlight ? 'text-[#FFB703]' : 'text-[#F8F9FA]/70'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.highlight && !isActive && (
                <span className="text-[10px] font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#FFB703]/20 text-[#FFB703]">
                  AI
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer area & logout */}
      <div className="p-4 border-t border-[#F8F9FA]/[0.08] space-y-3">
        <div className="p-3 rounded-lg bg-[#0A192F]/80 border border-[#F8F9FA]/[0.06] text-[11px] text-[#F8F9FA]/60 leading-relaxed">
          <div className="font-semibold text-[#F8F9FA]/80 flex items-center justify-between mb-1">
            <span>Prototype Version</span>
            <span className="text-[#FFB703]">v1.0-demo</span>
          </div>
          All figures shown are fictional sample data for Kirana store demonstration.
        </div>

        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3.5 py-2 text-xs font-medium text-[#F8F9FA]/65 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4 text-[#F8F9FA]/50" />
          <span>Exit Demo & Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop permanent sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 fixed inset-y-0 left-0 z-30">
        {content}
      </aside>

      {/* Mobile drawer backdrop & slideover */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-[#0A192F]/80 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
