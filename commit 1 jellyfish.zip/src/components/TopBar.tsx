import React from 'react';
import { Menu, MessageSquareText, Search } from 'lucide-react';
import { AppPage } from './Sidebar';

interface TopBarProps {
  storeName: string;
  ownerName: string;
  onOpenMobileSidebar: () => void;
  onNavigate: (page: AppPage) => void;
  currentPage: AppPage;
}

export const TopBar: React.FC<TopBarProps> = ({
  storeName,
  ownerName,
  onOpenMobileSidebar,
  onNavigate,
  currentPage,
}) => {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="sticky top-0 z-20 bg-[#0A192F]/90 backdrop-blur-md border-b border-[#F8F9FA]/[0.08] px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
      {/* Left: Mobile menu toggle + Store Greeting */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 text-[#F8F9FA]/70 hover:text-[#F8F9FA] hover:bg-[#112240] rounded-lg transition-colors cursor-pointer"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm sm:text-base font-semibold text-[#F8F9FA] tracking-tight">
              Good morning, {ownerName ? ownerName.split(' ')[0] : 'Business Owner'}
            </h1>
            <span className="hidden sm:inline-block text-[#F8F9FA]/30">|</span>
            <span className="hidden sm:inline-block text-xs text-[#FFB703] font-medium">
              {storeName}
            </span>
          </div>
          <div className="text-[11px] text-[#F8F9FA]/55 flex items-center gap-2 mt-0.5">
            <span>Bengaluru Retail Hub</span>
            <span aria-hidden="true">·</span>
            <span>All metrics live for October</span>
          </div>
        </div>
      </div>

      {/* Right: Quick Ask UDAAN prompt, Demo mode indicator, User avatar */}
      <div className="flex items-center gap-3 sm:gap-4">
        {currentPage !== 'ask-udaan' && (
          <button
            onClick={() => onNavigate('ask-udaan')}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-[#0A192F] bg-[#FFB703] hover:bg-[#E5A502] rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            <MessageSquareText className="w-3.5 h-3.5" />
            <span>Ask UDAAN</span>
          </button>
        )}

        {/* Demo mode status dot */}
        <div
          className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#112240] border border-[#64FFDA]/30"
          title="Running in hackathon prototype demo mode with sample data"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#64FFDA] opacity-60"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#64FFDA]"></span>
          </span>
          <span className="text-[11px] font-medium text-[#64FFDA] whitespace-nowrap">
            Demo mode
          </span>
        </div>

        {/* User initials avatar */}
        <div
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-[#112240] border border-[#FFB703]/40 text-[#FFB703] font-display font-semibold text-xs sm:text-sm flex items-center justify-center shrink-0 cursor-default"
          title={`${ownerName} (${storeName})`}
        >
          {getInitials(ownerName || 'Suresh Kumar')}
        </div>
      </div>
    </header>
  );
};
