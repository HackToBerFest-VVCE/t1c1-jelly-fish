import React from 'react';
import { Card } from './Card';
import { LucideIcon, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trendText?: string;
  trendDirection?: 'up' | 'down' | 'warning' | 'neutral';
  subtext?: string;
  accent?: 'gold' | 'mint' | 'default';
  onClick?: () => void;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  icon: Icon,
  trendText,
  trendDirection = 'neutral',
  subtext,
  accent = 'default',
  onClick,
}) => {
  return (
    <Card
      onClick={onClick}
      hoverEffect={!!onClick}
      className="p-5 flex flex-col justify-between relative overflow-hidden"
    >
      <div className="flex items-start justify-between gap-3">
        <span className="text-xs font-medium uppercase tracking-wider text-[#F8F9FA]/65">
          {title}
        </span>
        <div
          className={`p-2 rounded-lg shrink-0 ${
            accent === 'gold'
              ? 'bg-[#FFB703]/10 text-[#FFB703]'
              : accent === 'mint'
              ? 'bg-[#64FFDA]/10 text-[#64FFDA]'
              : 'bg-[#F8F9FA]/5 text-[#F8F9FA]/80'
          }`}
          aria-hidden="true"
        >
          <Icon className="w-5 h-5" />
        </div>
      </div>

      <div className="mt-4">
        <div className="text-2xl sm:text-3xl font-bold font-display tracking-tight text-[#F8F9FA] tabular-nums">
          {value}
        </div>

        {(trendText || subtext) && (
          <div className="flex items-center flex-wrap gap-2 mt-2 text-xs">
            {trendText && (
              <span
                className={`inline-flex items-center gap-1 font-medium tabular-nums ${
                  trendDirection === 'up'
                    ? 'text-[#64FFDA]'
                    : trendDirection === 'down'
                    ? 'text-red-400'
                    : trendDirection === 'warning'
                    ? 'text-[#FFB703]'
                    : 'text-[#F8F9FA]/60'
                }`}
              >
                {trendDirection === 'up' && <TrendingUp className="w-3.5 h-3.5" />}
                {trendDirection === 'down' && <TrendingDown className="w-3.5 h-3.5" />}
                {trendDirection === 'warning' && <AlertCircle className="w-3.5 h-3.5" />}
                {trendText}
              </span>
            )}
            {subtext && (
              <span className="text-[#F8F9FA]/50 truncate">{subtext}</span>
            )}
          </div>
        )}
      </div>
    </Card>
  );
};
