import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | number;
  showWordmark?: boolean;
  className?: string;
  tagline?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showWordmark = true,
  className = '',
  tagline = false,
}) => {
  let dimension = 36;
  if (typeof size === 'number') {
    dimension = size;
  } else if (size === 'sm') {
    dimension = 26;
  } else if (size === 'lg') {
    dimension = 48;
  }

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Abstract upward-sweeping wing / soaring bird SVG */}
      <svg
        width={dimension}
        height={dimension}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-200 hover:scale-105"
        aria-hidden="true"
      >
        {/* Subtle geometric backdrop disc */}
        <circle cx="24" cy="24" r="23" fill="#112240" stroke="rgba(248, 249, 250, 0.12)" strokeWidth="1" />
        
        {/* Lower sweep feather (Crisp White / Secondary Mint subtle tint) */}
        <path
          d="M11 31C16 31 23 27 27 21C29 18 31 14 34 11C28 17 21 21 16 23C13 24.2 11 27 11 31Z"
          fill="#F8F9FA"
          opacity="0.85"
        />

        {/* Primary soaring wing stroke (Upward arc) */}
        <path
          d="M14 34C19 33 26 27 32 19C36 14 38 9 39 8C35 12 30 18 24 23C19 27 16 30 14 34Z"
          fill="#F8F9FA"
        />

        {/* Warm Amber Gold dynamic ascending tip accent */}
        <path
          d="M26 15C30 11 35 8.5 40 7C38.5 11 35 15.5 32 18C30.5 19.2 29 17.5 26 15Z"
          fill="#FFB703"
        />

        {/* Mint subtle energy pulse dot/glide */}
        <circle cx="39" cy="7.5" r="1.5" fill="#64FFDA" />
      </svg>

      {showWordmark && (
        <div className="flex flex-col">
          <div className="flex items-center tracking-[0.22em] font-bold font-display text-[#F8F9FA] text-lg sm:text-xl leading-none">
            <span>UDAAN</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#FFB703] ml-1.5 mb-1" />
          </div>
          {tagline && (
            <span className="text-[10px] uppercase tracking-wider text-[#F8F9FA]/60 mt-1 font-sans">
              Give Your Business Freedom
            </span>
          )}
        </div>
      )}
    </div>
  );
};
