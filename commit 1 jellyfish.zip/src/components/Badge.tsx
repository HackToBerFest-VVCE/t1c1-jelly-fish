import React from 'react';

export type BadgeVariant =
  | 'critical'
  | 'low'
  | 'ok'
  | 'success'
  | 'pending'
  | 'refunded'
  | 'scheduled'
  | 'transit'
  | 'delayed'
  | 'neutral'
  | 'gold'
  | 'mint';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  className = '',
  size = 'md',
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'critical':
      case 'delayed':
      case 'refunded':
        return 'bg-red-500/10 text-red-300 border border-red-500/20';
      case 'low':
      case 'pending':
        return 'bg-[#FFB703]/10 text-[#FFB703] border border-[#FFB703]/25';
      case 'ok':
      case 'success':
      case 'mint':
        return 'bg-[#64FFDA]/10 text-[#64FFDA] border border-[#64FFDA]/25';
      case 'transit':
      case 'scheduled':
        return 'bg-sky-500/10 text-sky-300 border border-sky-500/20';
      case 'gold':
        return 'bg-[#FFB703]/15 text-[#FFB703] border border-[#FFB703]/30 font-medium';
      case 'neutral':
      default:
        return 'bg-[#F8F9FA]/5 text-[#F8F9FA]/80 border border-[#F8F9FA]/10';
    }
  };

  const sizeStyles = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-md tracking-wide leading-none whitespace-nowrap ${sizeStyles} ${getVariantStyles()} ${className}`}
    >
      {children}
    </span>
  );
};
