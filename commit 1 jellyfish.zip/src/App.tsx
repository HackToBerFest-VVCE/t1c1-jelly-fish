/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Login } from './pages/Login';
import { Overview } from './pages/Overview';
import { AskUdaan } from './pages/AskUdaan';
import { SalesAnalytics } from './pages/SalesAnalytics';
import { Inventory } from './pages/Inventory';
import { Suppliers } from './pages/Suppliers';
import { Settings } from './pages/Settings';
import { Sidebar, AppPage } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { ToastContainer, ToastMessage } from './components/Toast';
import { DEFAULT_STORE_PROFILE, StoreProfile } from './data/sampleData';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<AppPage>('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [storeProfile, setStoreProfile] = useState<StoreProfile>(DEFAULT_STORE_PROFILE);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Toast notification helper with auto-removal
  const showToast = (
    message: string,
    type: 'info' | 'success' | 'warning' = 'info',
    title?: string
  ) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    const newToast: ToastMessage = { id, type, title, message };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
    setCurrentPage('overview');
    showToast(
      'Signed into Demo Store. All figures shown are sample data.',
      'success',
      'Welcome to UDAAN'
    );
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage('overview');
    setMobileSidebarOpen(false);
    showToast('Signed out of demonstration account.', 'info');
  };

  // If not authenticated, render Login Page
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0A192F] text-[#F8F9FA] selection:bg-[#FFB703]/30 selection:text-[#FFB703]">
        <Login onLoginSuccess={handleLoginSuccess} />
        <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
      </div>
    );
  }

  // Dashboard Shell
  return (
    <div className="min-h-screen bg-[#0A192F] text-[#F8F9FA] flex selection:bg-[#FFB703]/30 selection:text-[#FFB703]">
      {/* Sidebar (Desktop fixed & Mobile Drawer) */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <TopBar
          storeName={storeProfile.name}
          ownerName={storeProfile.ownerName}
          onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
          onNavigate={setCurrentPage}
          currentPage={currentPage}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {currentPage === 'overview' && <Overview onNavigate={setCurrentPage} />}
          {currentPage === 'ask-udaan' && <AskUdaan onShowToast={showToast} />}
          {currentPage === 'sales-analytics' && <SalesAnalytics />}
          {currentPage === 'inventory' && <Inventory onShowToast={showToast} />}
          {currentPage === 'suppliers' && <Suppliers onShowToast={showToast} />}
          {currentPage === 'settings' && (
            <Settings
              profile={storeProfile}
              onUpdateProfile={setStoreProfile}
              onShowToast={showToast}
            />
          )}
        </main>

        {/* Global Footer */}
        <footer className="border-t border-[#F8F9FA]/[0.06] py-4 px-6 text-center text-xs text-[#F8F9FA]/40 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-[#F8F9FA]/60">UDAAN</span>
            <span aria-hidden="true">·</span>
            <span>Give Your Business Freedom.</span>
          </div>
          <div>
            All figures shown are fictional sample data. Hackathon Prototype.
          </div>
        </footer>
      </div>

      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}
